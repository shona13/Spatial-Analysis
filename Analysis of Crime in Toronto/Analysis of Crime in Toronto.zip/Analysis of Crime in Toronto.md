# Analysis of crime data in Toronto


```python
# Optional step - Installing required packages
!pip install geopandas pysal libpysal 
```

### Loading data
> First, I have accessed the [Robbery API](https://data.torontopolice.on.ca/datasets/TorontoPS::robbery-1/explore?location=19.913172%2C-39.955912%2C4.42) from [Toronto Police](https://data.torontopolice.on.ca/search?tags=crime) website.  Then I have filtered out the robberies that happened from December 2021 to May 2022 i.e 6 months. 
>
> The API URL with filter queries is [Filtered Data](https://services.arcgis.com/S9th0jAJ7bqgIRjw/arcgis/rest/services/Robbery/FeatureServer/0/query?where=reporteddate%20BETWEEN%20%272021-12-01%27%20AND%20%272022-06-30%27&outFields=*&f=geojson). This can be opened in a browser to check for output as HTML document but the data is in geojson.
>



```python
# Importing the required packages
import requests     
import pandas as pd      
import geopandas as gpd
import sklearn as sk
from shapely.geometry import Point

# To display all the columns whenever .head() is used which can be used to pre-process data.
pd.options.display.max_columns = None
```

> To make it readable and clean, we will put the query part in a params variable with all the filters.
>
> Using the [requests](https://requests.readthedocs.io/en/latest/api/) library, we will pass the URL and its params to get the response. 200 OK is the response we will need to proces data.
>
> The type of response is  *requests.models.Response*. 
>Firstly, I checked if the response is 200 and then converted the output in json dict.


```python
# Set API endpoint
url = "https://services.arcgis.com/S9th0jAJ7bqgIRjw/arcgis/rest/services/Major_Crime_Indicators/FeatureServer/0/query"

# Using params variable for the filtered queries
params = {
    "where": "occurrencedate BETWEEN '2021-01-01' AND '2022-06-01'",
    "outFields": "*",
    "f": "json"
}

# Send GET request to API to get the response
response = requests.get(url, params=params)
```


```python
# Check if request was successful and print the data for verification
if response.status_code == 200:
    # Retrieve crime data from response
    data = response.json()    
else:
    print("Error: Request failed with status code", response.status_code)
```

### Pre-processing the data

> The data needs to be in Pandas DataFrame format that can be read and create kernel density maps. I preprocessed the data and selected only the columns of my interest.
> I dropped the columns which were not useful for analysis.


```python
# Using list comprehension to filter attributes 
crime_data = [attr['attributes'] for attr in data['features']]

# Converting the list into dataFrame
crime_data = pd.json_normalize(crime_data)
```


```python
# Dropping the columns which are not required.
crime_data.drop(['Index_','event_unique_id', 'Division','ucr_ext','ucr_code','reporteddayofyear', 'occurrencedayofyear', 'ObjectId'], axis=1, inplace=True)
```

## Part A

#### **1. Are the crimes clustered? Is there Central Tendency? Create a density map showing the local density (quadrat or kernel method may be used) and describe the results (< 100 words).**
> I am using Seaborn for data visualization and matplotlib for  creating highly customizable plots.


```python
import seaborn as sns       # For data visualization 
import matplotlib.pyplot as plt   # For plotting
import folium     # For mapping crime on the map
from folium.plugins import HeatMap, MarkerCluster  # For visually appealing map
```

> To make it easier to plot, I have converted the "mci_category" column in the "crime_data" dataframe into a categorical data type, which can be useful for certain types of analysis.
>
>I have then grouped the crime_data dataframe by neighborhood and counts the number of occurrences of each type of crime in each neighborhood using the "count" method. The resulting dataframe is then sorted in ascending order based on the number of crimes in each neighborhood using the "sort_values" method.
>
> I have selected the "Neighbourhood", "Latitude", and "Longitude" columns from the "crime_data" dataframe and dropped any duplicate neighborhood names(if any) using the "drop_duplicates" method. The resulting dataframe is then indexed by neighborhood and joined with the previously computed count of crimes by neighborhood.
>
> Finally, I have sorted the dataframe in descending order based on the count of crimes in each neighborhood and selected the top 10 neighborhoods with the most crimes using the "head" method. This step displays the table. *This step is optional.*



```python
# To make mci_category column as category type
crime_data["mci_category"] = crime_data["mci_category"].astype('category')

# Top Criminal Neighbourhoods in Toronto 
top = crime_data.groupby('Neighbourhood')[['mci_category']].count().sort_values(by=['mci_category'])

# Coordinates Criminal Neighbourhoods
map_data = crime_data[['Neighbourhood', 'Latitude', 'Longitude']].drop_duplicates('Neighbourhood').set_index('Neighbourhood').join(top, how='inner')

# Displays the top 10 neighbourhoods table
map_data.sort_values(by=['mci_category'], ascending=False).head(10)
```





  <div id="df-9cc9b4cd-8bb3-43a4-b011-a051a0425d4a">
    <div class="colab-df-container">
      <div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Latitude</th>
      <th>Longitude</th>
      <th>mci_category</th>
    </tr>
    <tr>
      <th>Neighbourhood</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Church-Yonge Corridor</th>
      <td>43.649262</td>
      <td>-79.374106</td>
      <td>45</td>
    </tr>
    <tr>
      <th>Waterfront Communities-The Island</th>
      <td>43.648812</td>
      <td>-79.388886</td>
      <td>36</td>
    </tr>
    <tr>
      <th>West Humber-Clairville</th>
      <td>43.731907</td>
      <td>-79.596004</td>
      <td>25</td>
    </tr>
    <tr>
      <th>Moss Park</th>
      <td>43.649450</td>
      <td>-79.371425</td>
      <td>24</td>
    </tr>
    <tr>
      <th>Woburn</th>
      <td>43.772141</td>
      <td>-79.251457</td>
      <td>23</td>
    </tr>
    <tr>
      <th>Bay Street Corridor</th>
      <td>43.655716</td>
      <td>-79.383726</td>
      <td>23</td>
    </tr>
    <tr>
      <th>Willowdale East</th>
      <td>43.770993</td>
      <td>-79.413275</td>
      <td>22</td>
    </tr>
    <tr>
      <th>Rosedale-Moore Park</th>
      <td>43.672874</td>
      <td>-79.387826</td>
      <td>19</td>
    </tr>
    <tr>
      <th>Downsview-Roding-CFB</th>
      <td>43.720916</td>
      <td>-79.508595</td>
      <td>19</td>
    </tr>
    <tr>
      <th>West Hill</th>
      <td>43.767583</td>
      <td>-79.183234</td>
      <td>15</td>
    </tr>
  </tbody>
</table>
</div>
      <button class="colab-df-convert" onclick="convertToInteractive('df-9cc9b4cd-8bb3-43a4-b011-a051a0425d4a')"
              title="Convert this dataframe to an interactive table."
              style="display:none;">

  <svg xmlns="http://www.w3.org/2000/svg" height="24px"viewBox="0 0 24 24"
       width="24px">
    <path d="M0 0h24v24H0V0z" fill="none"/>
    <path d="M18.56 5.44l.94 2.06.94-2.06 2.06-.94-2.06-.94-.94-2.06-.94 2.06-2.06.94zm-11 1L8.5 8.5l.94-2.06 2.06-.94-2.06-.94L8.5 2.5l-.94 2.06-2.06.94zm10 10l.94 2.06.94-2.06 2.06-.94-2.06-.94-.94-2.06-.94 2.06-2.06.94z"/><path d="M17.41 7.96l-1.37-1.37c-.4-.4-.92-.59-1.43-.59-.52 0-1.04.2-1.43.59L10.3 9.45l-7.72 7.72c-.78.78-.78 2.05 0 2.83L4 21.41c.39.39.9.59 1.41.59.51 0 1.02-.2 1.41-.59l7.78-7.78 2.81-2.81c.8-.78.8-2.07 0-2.86zM5.41 20L4 18.59l7.72-7.72 1.47 1.35L5.41 20z"/>
  </svg>
      </button>

  <style>
    .colab-df-container {
      display:flex;
      flex-wrap:wrap;
      gap: 12px;
    }

    .colab-df-convert {
      background-color: #E8F0FE;
      border: none;
      border-radius: 50%;
      cursor: pointer;
      display: none;
      fill: #1967D2;
      height: 32px;
      padding: 0 0 0 0;
      width: 32px;
    }

    .colab-df-convert:hover {
      background-color: #E2EBFA;
      box-shadow: 0px 1px 2px rgba(60, 64, 67, 0.3), 0px 1px 3px 1px rgba(60, 64, 67, 0.15);
      fill: #174EA6;
    }

    [theme=dark] .colab-df-convert {
      background-color: #3B4455;
      fill: #D2E3FC;
    }

    [theme=dark] .colab-df-convert:hover {
      background-color: #434B5C;
      box-shadow: 0px 1px 3px 1px rgba(0, 0, 0, 0.15);
      filter: drop-shadow(0px 1px 2px rgba(0, 0, 0, 0.3));
      fill: #FFFFFF;
    }
  </style>

      <script>
        const buttonEl =
          document.querySelector('#df-9cc9b4cd-8bb3-43a4-b011-a051a0425d4a button.colab-df-convert');
        buttonEl.style.display =
          google.colab.kernel.accessAllowed ? 'block' : 'none';

        async function convertToInteractive(key) {
          const element = document.querySelector('#df-9cc9b4cd-8bb3-43a4-b011-a051a0425d4a');
          const dataTable =
            await google.colab.kernel.invokeFunction('convertToInteractive',
                                                     [key], {});
          if (!dataTable) return;

          const docLinkHtml = 'Like what you see? Visit the ' +
            '<a target="_blank" href=https://colab.research.google.com/notebooks/data_table.ipynb>data table notebook</a>'
            + ' to learn more about interactive tables.';
          element.innerHTML = '';
          dataTable['output_type'] = 'display_data';
          await google.colab.output.renderOutput(dataTable, element);
          const docLink = document.createElement('div');
          docLink.innerHTML = docLinkHtml;
          element.appendChild(docLink);
        }
      </script>
    </div>
  </div>




> The resulting dataframe will be used to create visualizations such as a choropleth map to display the crime rates across different neighborhoods. 
>
> I am using Folium's HeatMap because it is useful when you want to create interactive density maps on top of a map background. It is easy to use and allows for customization of the heatmap appearance, such as the color scheme, opacity, and radius of the heatmap points. Folium HeatMap also supports clustering and zooming in and out of the map.
> But, there are other ways to plot a density map depending on the requirements like:
* Seaborn's kdeplot 
* Plotly's Density Maps 
* Basemap 
* Geopandas
* Scikit-learn's KDE
> 
> Using [Toronto Crime](https://www.jiristodulka.com/post/toronto-crime/) as reference, I have created a Folium map which overlays a heat map layer on top of it to display the density of crimes in Toronto. 
>
> * The code initializes a new Folium map centered at the coordinates [43.702270, -79.366074] with a zoom level of 11.
> * Then a MarkerCluster object is created to group together the individual crime locations on the map.
> * Creating & adding Marker for every row by iterating over the rows of the map_data DataFrame.
> * The maximum number of crimes in any neighborhood is computed from the map_data DataFrame, which is used as a reference for the darkest shade in the heat map layer.
> Lastly, the HeatMap object is added as a layer on top of the Folium map using the add_to() method. This displays the density of crimes in each neighborhood as a heat map layer on the map.


```python
# Mapping Criminal Neighbourhoods
heat_map = folium.Map(
    location=[43.702270, -79.366074],
    zoom_start=11,
)

#Step 1: Clusters
cluster = MarkerCluster().add_to(heat_map)

#Step 2: Clusters breaking into Markers
#for x in map_data.iterrows():
  #  folium.Marker([x[1].Latitude, x[1].Longitude]).add_to(cluster)

for x in map_data.iterrows():
    folium.Marker(
        [x[1].Latitude, x[1].Longitude], 
        popup=x[0]#.Neighbourhood
    ).add_to(cluster)

#Step 3: Heat
max_crime = map_data['mci_category'].max() # max value as reference for the darkets shade
heat = HeatMap(map_data.values,
                min_opacity=0.2,
                radius=30, blur=20, 
                max_zoom=15
                )

heat.add_to(heat_map)

heat_map
```




<div style="width:100%;"><div style="position:relative;width:100%;height:0;padding-bottom:60%;"><span style="color:#565656">Make this Notebook Trusted to load map: File -> Trust Notebook</span><iframe srcdoc="&lt;!DOCTYPE html&gt;
&lt;html&gt;
&lt;head&gt;

    &lt;meta http-equiv=&quot;content-type&quot; content=&quot;text/html; charset=UTF-8&quot; /&gt;

        &lt;script&gt;
            L_NO_TOUCH = false;
            L_DISABLE_3D = false;
        &lt;/script&gt;

    &lt;style&gt;html, body {width: 100%;height: 100%;margin: 0;padding: 0;}&lt;/style&gt;
    &lt;style&gt;#map {position:absolute;top:0;bottom:0;right:0;left:0;}&lt;/style&gt;
    &lt;script src=&quot;https://cdn.jsdelivr.net/npm/leaflet@1.6.0/dist/leaflet.js&quot;&gt;&lt;/script&gt;
    &lt;script src=&quot;https://code.jquery.com/jquery-1.12.4.min.js&quot;&gt;&lt;/script&gt;
    &lt;script src=&quot;https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js&quot;&gt;&lt;/script&gt;
    &lt;script src=&quot;https://cdnjs.cloudflare.com/ajax/libs/Leaflet.awesome-markers/2.0.2/leaflet.awesome-markers.js&quot;&gt;&lt;/script&gt;
    &lt;link rel=&quot;stylesheet&quot; href=&quot;https://cdn.jsdelivr.net/npm/leaflet@1.6.0/dist/leaflet.css&quot;/&gt;
    &lt;link rel=&quot;stylesheet&quot; href=&quot;https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css&quot;/&gt;
    &lt;link rel=&quot;stylesheet&quot; href=&quot;https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap-theme.min.css&quot;/&gt;
    &lt;link rel=&quot;stylesheet&quot; href=&quot;https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css&quot;/&gt;
    &lt;link rel=&quot;stylesheet&quot; href=&quot;https://cdnjs.cloudflare.com/ajax/libs/Leaflet.awesome-markers/2.0.2/leaflet.awesome-markers.css&quot;/&gt;
    &lt;link rel=&quot;stylesheet&quot; href=&quot;https://cdn.jsdelivr.net/gh/python-visualization/folium/folium/templates/leaflet.awesome.rotate.min.css&quot;/&gt;

            &lt;meta name=&quot;viewport&quot; content=&quot;width=device-width,
                initial-scale=1.0, maximum-scale=1.0, user-scalable=no&quot; /&gt;
            &lt;style&gt;
                #map_f8e9f8c831a93fb452c7426f10c07a3b {
                    position: relative;
                    width: 100.0%;
                    height: 100.0%;
                    left: 0.0%;
                    top: 0.0%;
                }
            &lt;/style&gt;

    &lt;script src=&quot;https://cdnjs.cloudflare.com/ajax/libs/leaflet.markercluster/1.1.0/leaflet.markercluster.js&quot;&gt;&lt;/script&gt;
    &lt;link rel=&quot;stylesheet&quot; href=&quot;https://cdnjs.cloudflare.com/ajax/libs/leaflet.markercluster/1.1.0/MarkerCluster.css&quot;/&gt;
    &lt;link rel=&quot;stylesheet&quot; href=&quot;https://cdnjs.cloudflare.com/ajax/libs/leaflet.markercluster/1.1.0/MarkerCluster.Default.css&quot;/&gt;
    &lt;script src=&quot;https://cdn.jsdelivr.net/gh/python-visualization/folium@master/folium/templates/leaflet_heat.min.js&quot;&gt;&lt;/script&gt;
&lt;/head&gt;
&lt;body&gt;


            &lt;div class=&quot;folium-map&quot; id=&quot;map_f8e9f8c831a93fb452c7426f10c07a3b&quot; &gt;&lt;/div&gt;

&lt;/body&gt;
&lt;script&gt;


            var map_f8e9f8c831a93fb452c7426f10c07a3b = L.map(
                &quot;map_f8e9f8c831a93fb452c7426f10c07a3b&quot;,
                {
                    center: [43.70227, -79.366074],
                    crs: L.CRS.EPSG3857,
                    zoom: 11,
                    zoomControl: true,
                    preferCanvas: false,
                }
            );





            var tile_layer_11b1e54f2270b4c109cc31ce6ec6fc2b = L.tileLayer(
                &quot;https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png&quot;,
                {&quot;attribution&quot;: &quot;Data by \u0026copy; \u003ca href=\&quot;http://openstreetmap.org\&quot;\u003eOpenStreetMap\u003c/a\u003e, under \u003ca href=\&quot;http://www.openstreetmap.org/copyright\&quot;\u003eODbL\u003c/a\u003e.&quot;, &quot;detectRetina&quot;: false, &quot;maxNativeZoom&quot;: 18, &quot;maxZoom&quot;: 18, &quot;minZoom&quot;: 0, &quot;noWrap&quot;: false, &quot;opacity&quot;: 1, &quot;subdomains&quot;: &quot;abc&quot;, &quot;tms&quot;: false}
            ).addTo(map_f8e9f8c831a93fb452c7426f10c07a3b);


            var marker_cluster_bee2ede4db751c0f106987df10836fd4 = L.markerClusterGroup(
                {}
            );
            map_f8e9f8c831a93fb452c7426f10c07a3b.addLayer(marker_cluster_bee2ede4db751c0f106987df10836fd4);


            var marker_5de3173c5aad0341a6861bf3c1f8e53f = L.marker(
                [43.66672554, -79.44642226],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_b732fbf9ea90483e254c47f8f3974e88 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_b483a0a219af31808bdb376cf4164513 = $(`&lt;div id=&quot;html_b483a0a219af31808bdb376cf4164513&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Dovercourt-Wallace Emerson-Junction&lt;/div&gt;`)[0];
            popup_b732fbf9ea90483e254c47f8f3974e88.setContent(html_b483a0a219af31808bdb376cf4164513);


        marker_5de3173c5aad0341a6861bf3c1f8e53f.bindPopup(popup_b732fbf9ea90483e254c47f8f3974e88)
        ;




            var marker_2c5bd8711350555f5245b442bf0ec4d0 = L.marker(
                [43.63294904, -79.43438482],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_b10d61d3f20385a09a058e42e9ec9b98 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_55153e391f1dbe01bc99e8b81fa24fa9 = $(`&lt;div id=&quot;html_55153e391f1dbe01bc99e8b81fa24fa9&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;South Parkdale&lt;/div&gt;`)[0];
            popup_b10d61d3f20385a09a058e42e9ec9b98.setContent(html_55153e391f1dbe01bc99e8b81fa24fa9);


        marker_2c5bd8711350555f5245b442bf0ec4d0.bindPopup(popup_b10d61d3f20385a09a058e42e9ec9b98)
        ;




            var marker_ca9aaaaa6ec2bfc046ccaf20cc213aeb = L.marker(
                [43.65227394, -79.40110737],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_90b9dd6b744fc28ca4f3ebde9d3f2b49 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_7cc8a61eafa0d665c9b5dfb28887d103 = $(`&lt;div id=&quot;html_7cc8a61eafa0d665c9b5dfb28887d103&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Kensington-Chinatown&lt;/div&gt;`)[0];
            popup_90b9dd6b744fc28ca4f3ebde9d3f2b49.setContent(html_7cc8a61eafa0d665c9b5dfb28887d103);


        marker_ca9aaaaa6ec2bfc046ccaf20cc213aeb.bindPopup(popup_90b9dd6b744fc28ca4f3ebde9d3f2b49)
        ;




            var marker_61f61b66e1292db75aad1ea7069a11f7 = L.marker(
                [43.74848196, -79.55006743],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_bb7f996a498967f36bad22f30096934f = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_4e841a146cc2b2f7388b367cc913e72c = $(`&lt;div id=&quot;html_4e841a146cc2b2f7388b367cc913e72c&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Humbermede&lt;/div&gt;`)[0];
            popup_bb7f996a498967f36bad22f30096934f.setContent(html_4e841a146cc2b2f7388b367cc913e72c);


        marker_61f61b66e1292db75aad1ea7069a11f7.bindPopup(popup_bb7f996a498967f36bad22f30096934f)
        ;




            var marker_2a5d084aeab4d2954ce3e901aba42f43 = L.marker(
                [43.65571598, -79.38372586],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_f5e8e98e75b7f8a8f8e20c947f883874 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_7c36abf1a00c6cfae014da6098e2b32a = $(`&lt;div id=&quot;html_7c36abf1a00c6cfae014da6098e2b32a&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Bay Street Corridor&lt;/div&gt;`)[0];
            popup_f5e8e98e75b7f8a8f8e20c947f883874.setContent(html_7c36abf1a00c6cfae014da6098e2b32a);


        marker_2a5d084aeab4d2954ce3e901aba42f43.bindPopup(popup_f5e8e98e75b7f8a8f8e20c947f883874)
        ;




            var marker_f29197aeb5b20c0de1eae3c38ced27b9 = L.marker(
                [43.70321193, -79.34658826],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_aa0137b372dc6459b8980973b6e36618 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_ba379d150dce7eb2cbb87516e77f7955 = $(`&lt;div id=&quot;html_ba379d150dce7eb2cbb87516e77f7955&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Thorncliffe Park&lt;/div&gt;`)[0];
            popup_aa0137b372dc6459b8980973b6e36618.setContent(html_ba379d150dce7eb2cbb87516e77f7955);


        marker_f29197aeb5b20c0de1eae3c38ced27b9.bindPopup(popup_aa0137b372dc6459b8980973b6e36618)
        ;




            var marker_5a74dfd61ab9c1b5a256cf929e2d5b79 = L.marker(
                [43.7870825, -79.32992957],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_bf1387649d72f730299b7a3386c18983 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_998e7b91472642de2fbceef9df9850c0 = $(`&lt;div id=&quot;html_998e7b91472642de2fbceef9df9850c0&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Pleasant View&lt;/div&gt;`)[0];
            popup_bf1387649d72f730299b7a3386c18983.setContent(html_998e7b91472642de2fbceef9df9850c0);


        marker_5a74dfd61ab9c1b5a256cf929e2d5b79.bindPopup(popup_bf1387649d72f730299b7a3386c18983)
        ;




            var marker_cb5c9112a74547b462da53929fa99a97 = L.marker(
                [43.72091645, -79.50859475],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_c56deaf51d1ed389f51a9f5f69921b50 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_52c428eaf7400440c378fd423105a407 = $(`&lt;div id=&quot;html_52c428eaf7400440c378fd423105a407&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Downsview-Roding-CFB&lt;/div&gt;`)[0];
            popup_c56deaf51d1ed389f51a9f5f69921b50.setContent(html_52c428eaf7400440c378fd423105a407);


        marker_cb5c9112a74547b462da53929fa99a97.bindPopup(popup_c56deaf51d1ed389f51a9f5f69921b50)
        ;




            var marker_25f8bb4eef610e502cd902efdbeedf16 = L.marker(
                [43.69425151, -79.55861018],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_b00124e8d93a9d9a1e617217d852653c = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_7369e4a25b69b5349b69d5a42bac1172 = $(`&lt;div id=&quot;html_7369e4a25b69b5349b69d5a42bac1172&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Kingsview Village-The Westway&lt;/div&gt;`)[0];
            popup_b00124e8d93a9d9a1e617217d852653c.setContent(html_7369e4a25b69b5349b69d5a42bac1172);


        marker_25f8bb4eef610e502cd902efdbeedf16.bindPopup(popup_b00124e8d93a9d9a1e617217d852653c)
        ;




            var marker_934dac2d3ec95537990d752c5aed8446 = L.marker(
                [43.72577689, -79.27383346],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_862d5e62f2911b82cbf044090e145b26 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_6d6be59da9aaf095bd834215f2996243 = $(`&lt;div id=&quot;html_6d6be59da9aaf095bd834215f2996243&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Ionview&lt;/div&gt;`)[0];
            popup_862d5e62f2911b82cbf044090e145b26.setContent(html_6d6be59da9aaf095bd834215f2996243);


        marker_934dac2d3ec95537990d752c5aed8446.bindPopup(popup_862d5e62f2911b82cbf044090e145b26)
        ;




            var marker_021b199cc604faf1cc109d27f0df4398 = L.marker(
                [43.70917038, -79.40102123],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_4e415ccf75e369ebe51989c3ea7b26f2 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_f7d5d2eb5bfd7410a37e609c052c90e4 = $(`&lt;div id=&quot;html_f7d5d2eb5bfd7410a37e609c052c90e4&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Yonge-Eglinton&lt;/div&gt;`)[0];
            popup_4e415ccf75e369ebe51989c3ea7b26f2.setContent(html_f7d5d2eb5bfd7410a37e609c052c90e4);


        marker_021b199cc604faf1cc109d27f0df4398.bindPopup(popup_4e415ccf75e369ebe51989c3ea7b26f2)
        ;




            var marker_44a89a71783c0dc2087cff47dfe0e4d4 = L.marker(
                [43.69625936, -79.44764573],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_300c6f9214427d52a0fa257b87be3060 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_876442b2216b06e91c8c892f2a88c7ea = $(`&lt;div id=&quot;html_876442b2216b06e91c8c892f2a88c7ea&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Oakwood Village&lt;/div&gt;`)[0];
            popup_300c6f9214427d52a0fa257b87be3060.setContent(html_876442b2216b06e91c8c892f2a88c7ea);


        marker_44a89a71783c0dc2087cff47dfe0e4d4.bindPopup(popup_300c6f9214427d52a0fa257b87be3060)
        ;




            var marker_67347af44be9a4af290e8d8549c0525a = L.marker(
                [43.77099307, -79.41327513],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_31dc2d579740bda3ad84a54a020a7a36 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_54911a28da1599c505ad2cd57c9a0dd8 = $(`&lt;div id=&quot;html_54911a28da1599c505ad2cd57c9a0dd8&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Willowdale East&lt;/div&gt;`)[0];
            popup_31dc2d579740bda3ad84a54a020a7a36.setContent(html_54911a28da1599c505ad2cd57c9a0dd8);


        marker_67347af44be9a4af290e8d8549c0525a.bindPopup(popup_31dc2d579740bda3ad84a54a020a7a36)
        ;




            var marker_db069fb00832ea35b102e942f1207b46 = L.marker(
                [43.8225461, -79.27141938],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_0562724ab89fe0348dc09eb81d27bdc8 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_db3385f3db116d86dd1c2ab998922141 = $(`&lt;div id=&quot;html_db3385f3db116d86dd1c2ab998922141&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Milliken&lt;/div&gt;`)[0];
            popup_0562724ab89fe0348dc09eb81d27bdc8.setContent(html_db3385f3db116d86dd1c2ab998922141);


        marker_db069fb00832ea35b102e942f1207b46.bindPopup(popup_0562724ab89fe0348dc09eb81d27bdc8)
        ;




            var marker_59a2881dfa05285a1be84ae28f180cf1 = L.marker(
                [43.68475127, -79.31005511],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_b21a267ddd70584ce374feffbd509dfe = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_21b635e16b8b8fadb9617d4f45ba3b8f = $(`&lt;div id=&quot;html_21b635e16b8b8fadb9617d4f45ba3b8f&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;East End-Danforth&lt;/div&gt;`)[0];
            popup_b21a267ddd70584ce374feffbd509dfe.setContent(html_21b635e16b8b8fadb9617d4f45ba3b8f);


        marker_59a2881dfa05285a1be84ae28f180cf1.bindPopup(popup_b21a267ddd70584ce374feffbd509dfe)
        ;




            var marker_15435b18801ef1ed7cb27f8bffa25b2f = L.marker(
                [43.67363686, -79.42340096],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_a0f075fff70a3d8d49267a51c6bc0c8c = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_6d52586ec54dc569f54648ed826be3cb = $(`&lt;div id=&quot;html_6d52586ec54dc569f54648ed826be3cb&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Wychwood&lt;/div&gt;`)[0];
            popup_a0f075fff70a3d8d49267a51c6bc0c8c.setContent(html_6d52586ec54dc569f54648ed826be3cb);


        marker_15435b18801ef1ed7cb27f8bffa25b2f.bindPopup(popup_a0f075fff70a3d8d49267a51c6bc0c8c)
        ;




            var marker_7b1c3632cf6f80d20d4b67665176a044 = L.marker(
                [43.64926232, -79.37410556],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_1eb78f31e2b4dcc263ed6fbd08f959b0 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_c6bdfee1c672cc17afd28e003e992018 = $(`&lt;div id=&quot;html_c6bdfee1c672cc17afd28e003e992018&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Church-Yonge Corridor&lt;/div&gt;`)[0];
            popup_1eb78f31e2b4dcc263ed6fbd08f959b0.setContent(html_c6bdfee1c672cc17afd28e003e992018);


        marker_7b1c3632cf6f80d20d4b67665176a044.bindPopup(popup_1eb78f31e2b4dcc263ed6fbd08f959b0)
        ;




            var marker_e6001d612cabbec7d3d5a93300fb5880 = L.marker(
                [43.64509634, -79.57350939],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_a668f8f26e9b5e6acf196462be22dba1 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_8de4f6c8989f7dae1e8e3a79b73c8aae = $(`&lt;div id=&quot;html_8de4f6c8989f7dae1e8e3a79b73c8aae&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Etobicoke West Mall&lt;/div&gt;`)[0];
            popup_a668f8f26e9b5e6acf196462be22dba1.setContent(html_8de4f6c8989f7dae1e8e3a79b73c8aae);


        marker_e6001d612cabbec7d3d5a93300fb5880.bindPopup(popup_a668f8f26e9b5e6acf196462be22dba1)
        ;




            var marker_b97e00725c97a5973bd018a197e90726 = L.marker(
                [43.75937098, -79.33874208],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_28ebdb8e0356fffbe0a2577b45f16ad9 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_c1592a5282abbebbd107eb5b1a75ed4a = $(`&lt;div id=&quot;html_c1592a5282abbebbd107eb5b1a75ed4a&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Parkwoods-Donalda&lt;/div&gt;`)[0];
            popup_28ebdb8e0356fffbe0a2577b45f16ad9.setContent(html_c1592a5282abbebbd107eb5b1a75ed4a);


        marker_b97e00725c97a5973bd018a197e90726.bindPopup(popup_28ebdb8e0356fffbe0a2577b45f16ad9)
        ;




            var marker_422b52218a9b4a577ba2965386ca97c9 = L.marker(
                [43.68889241, -79.5039677],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_f043ab989e3b19b5029f7493532e148c = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_67538d64bfdfbd3d5596e6684427b7a0 = $(`&lt;div id=&quot;html_67538d64bfdfbd3d5596e6684427b7a0&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Mount Dennis&lt;/div&gt;`)[0];
            popup_f043ab989e3b19b5029f7493532e148c.setContent(html_67538d64bfdfbd3d5596e6684427b7a0);


        marker_422b52218a9b4a577ba2965386ca97c9.bindPopup(popup_f043ab989e3b19b5029f7493532e148c)
        ;




            var marker_16a5d702f2457e790f5d87b3ababdd85 = L.marker(
                [43.66874022, -79.45797855],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_93350cc4870f6c4d72d79ccb258f5475 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_da67430da716d663d45e1b46520712a4 = $(`&lt;div id=&quot;html_da67430da716d663d45e1b46520712a4&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Weston-Pellam Park&lt;/div&gt;`)[0];
            popup_93350cc4870f6c4d72d79ccb258f5475.setContent(html_da67430da716d663d45e1b46520712a4);


        marker_16a5d702f2457e790f5d87b3ababdd85.bindPopup(popup_93350cc4870f6c4d72d79ccb258f5475)
        ;




            var marker_d78e2aa5b0ae15449242e4caab2cb273 = L.marker(
                [43.64881159, -79.38888568],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_3c846c16753c88e43f83e649dfc8e91d = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_1ab5762cc0e93fc14c2236861aa66b3d = $(`&lt;div id=&quot;html_1ab5762cc0e93fc14c2236861aa66b3d&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Waterfront Communities-The Island&lt;/div&gt;`)[0];
            popup_3c846c16753c88e43f83e649dfc8e91d.setContent(html_1ab5762cc0e93fc14c2236861aa66b3d);


        marker_d78e2aa5b0ae15449242e4caab2cb273.bindPopup(popup_3c846c16753c88e43f83e649dfc8e91d)
        ;




            var marker_678fa50d0a15e6cf5ebf6a06e486d6af = L.marker(
                [43.66716143, -79.40149998],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_9c06b51fea232e1e91b9424d2553bc7f = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_64d02f9ecddf7043c4e1a45286d76224 = $(`&lt;div id=&quot;html_64d02f9ecddf7043c4e1a45286d76224&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Annex&lt;/div&gt;`)[0];
            popup_9c06b51fea232e1e91b9424d2553bc7f.setContent(html_64d02f9ecddf7043c4e1a45286d76224);


        marker_678fa50d0a15e6cf5ebf6a06e486d6af.bindPopup(popup_9c06b51fea232e1e91b9424d2553bc7f)
        ;




            var marker_6e07786710e8615b855cfca83ca91a76 = L.marker(
                [43.67967885, -79.34511536],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_805ef5aac57b3d156c295aefe1f4fa96 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_584167999ee5e549629a4a1b4e5cfd86 = $(`&lt;div id=&quot;html_584167999ee5e549629a4a1b4e5cfd86&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Danforth&lt;/div&gt;`)[0];
            popup_805ef5aac57b3d156c295aefe1f4fa96.setContent(html_584167999ee5e549629a4a1b4e5cfd86);


        marker_6e07786710e8615b855cfca83ca91a76.bindPopup(popup_805ef5aac57b3d156c295aefe1f4fa96)
        ;




            var marker_72e7ea417a3d6985104aa2915f56d4ab = L.marker(
                [43.71204501, -79.28096318],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_7be7a4385f86c07e993d50595ea90ef0 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_7c5a81d3eae6644c626baddb2ec4c3af = $(`&lt;div id=&quot;html_7c5a81d3eae6644c626baddb2ec4c3af&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Clairlea-Birchmount&lt;/div&gt;`)[0];
            popup_7be7a4385f86c07e993d50595ea90ef0.setContent(html_7c5a81d3eae6644c626baddb2ec4c3af);


        marker_72e7ea417a3d6985104aa2915f56d4ab.bindPopup(popup_7be7a4385f86c07e993d50595ea90ef0)
        ;




            var marker_354f1a0492724ba6d5bd491a5e3a0b37 = L.marker(
                [43.66228154, -79.34055684],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_ccaced00c9d60ba5c714f2eb64981189 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_58cb396cb99ea0aced3a2d0eb42a2b35 = $(`&lt;div id=&quot;html_58cb396cb99ea0aced3a2d0eb42a2b35&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;South Riverdale&lt;/div&gt;`)[0];
            popup_ccaced00c9d60ba5c714f2eb64981189.setContent(html_58cb396cb99ea0aced3a2d0eb42a2b35);


        marker_354f1a0492724ba6d5bd491a5e3a0b37.bindPopup(popup_ccaced00c9d60ba5c714f2eb64981189)
        ;




            var marker_9bff86f39b5164e9d6f3241d99c0e12d = L.marker(
                [43.64944981, -79.37142509],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_ef7ac1cb6450a656f907d5f74ef7f355 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_6bfc53cdd1f76afed325a27633c874ab = $(`&lt;div id=&quot;html_6bfc53cdd1f76afed325a27633c874ab&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Moss Park&lt;/div&gt;`)[0];
            popup_ef7ac1cb6450a656f907d5f74ef7f355.setContent(html_6bfc53cdd1f76afed325a27633c874ab);


        marker_9bff86f39b5164e9d6f3241d99c0e12d.bindPopup(popup_ef7ac1cb6450a656f907d5f74ef7f355)
        ;




            var marker_2e065f1517c7576f0e342ace5ddf1119 = L.marker(
                [43.64204126, -79.41193075],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_e2d6ab783824238876d96f1713786327 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_786b237c5e51b2f7bb01d01813084b3a = $(`&lt;div id=&quot;html_786b237c5e51b2f7bb01d01813084b3a&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Niagara&lt;/div&gt;`)[0];
            popup_e2d6ab783824238876d96f1713786327.setContent(html_786b237c5e51b2f7bb01d01813084b3a);


        marker_2e065f1517c7576f0e342ace5ddf1119.bindPopup(popup_e2d6ab783824238876d96f1713786327)
        ;




            var marker_22182d5cf7edba836dbe910736b04eae = L.marker(
                [43.76842365, -79.26876189],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_e5ad028af1e48f110ed5104bc0d071c8 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_d59d3cee5e53a7cf869148a6f63a7987 = $(`&lt;div id=&quot;html_d59d3cee5e53a7cf869148a6f63a7987&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Bendale&lt;/div&gt;`)[0];
            popup_e5ad028af1e48f110ed5104bc0d071c8.setContent(html_d59d3cee5e53a7cf869148a6f63a7987);


        marker_22182d5cf7edba836dbe910736b04eae.bindPopup(popup_e5ad028af1e48f110ed5104bc0d071c8)
        ;




            var marker_5356fcd3689f106a324611bf5a6f35f8 = L.marker(
                [43.81421617, -79.23709431],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_78997cc73e3f5b7f77941e2aaff0d560 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_a0aade197a0d233bca0d97711d5d8843 = $(`&lt;div id=&quot;html_a0aade197a0d233bca0d97711d5d8843&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Malvern&lt;/div&gt;`)[0];
            popup_78997cc73e3f5b7f77941e2aaff0d560.setContent(html_a0aade197a0d233bca0d97711d5d8843);


        marker_5356fcd3689f106a324611bf5a6f35f8.bindPopup(popup_78997cc73e3f5b7f77941e2aaff0d560)
        ;




            var marker_4ddedc2c278437c0b3c524a71fdf4135 = L.marker(
                [43.64220797, -79.42860473],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_5cb5c11bd7e29202a9cb1ec2689b71b9 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_8f3375c8cf21b3b2cdbdfcdc4d30b80d = $(`&lt;div id=&quot;html_8f3375c8cf21b3b2cdbdfcdc4d30b80d&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Roncesvalles&lt;/div&gt;`)[0];
            popup_5cb5c11bd7e29202a9cb1ec2689b71b9.setContent(html_8f3375c8cf21b3b2cdbdfcdc4d30b80d);


        marker_4ddedc2c278437c0b3c524a71fdf4135.bindPopup(popup_5cb5c11bd7e29202a9cb1ec2689b71b9)
        ;




            var marker_cfac55c10106b2fb30011eb255e860f6 = L.marker(
                [43.67007127, -79.29978601],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_f53f335faac4c9971f4759c05fe2f5fe = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_750ba050b3ebb69302c88c12830fd392 = $(`&lt;div id=&quot;html_750ba050b3ebb69302c88c12830fd392&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;The Beaches&lt;/div&gt;`)[0];
            popup_f53f335faac4c9971f4759c05fe2f5fe.setContent(html_750ba050b3ebb69302c88c12830fd392);


        marker_cfac55c10106b2fb30011eb255e860f6.bindPopup(popup_f53f335faac4c9971f4759c05fe2f5fe)
        ;




            var marker_a6876b21fbba271bcc74c59a877a3047 = L.marker(
                [43.7319067, -79.59600355],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_1a5f51abbb97151dc7bba034b6285d15 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_fe8ce268bffa49c8699981bb5f36fff2 = $(`&lt;div id=&quot;html_fe8ce268bffa49c8699981bb5f36fff2&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;West Humber-Clairville&lt;/div&gt;`)[0];
            popup_1a5f51abbb97151dc7bba034b6285d15.setContent(html_fe8ce268bffa49c8699981bb5f36fff2);


        marker_a6876b21fbba271bcc74c59a877a3047.bindPopup(popup_1a5f51abbb97151dc7bba034b6285d15)
        ;




            var marker_1a58545ecb7d3199b83228f9029dd187 = L.marker(
                [43.64788722, -79.52685653],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_a8055eea04b2c3b5297d288d6f1feadd = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_c960922ec1f3c413b3b8acd9104e3e4d = $(`&lt;div id=&quot;html_c960922ec1f3c413b3b8acd9104e3e4d&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Islington-City Centre West&lt;/div&gt;`)[0];
            popup_a8055eea04b2c3b5297d288d6f1feadd.setContent(html_c960922ec1f3c413b3b8acd9104e3e4d);


        marker_1a58545ecb7d3199b83228f9029dd187.bindPopup(popup_a8055eea04b2c3b5297d288d6f1feadd)
        ;




            var marker_79607cc1a6867c24d782c46839efcb53 = L.marker(
                [43.76525072, -79.50372563],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_d10f142897924dbf96ab0c9861247d15 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_d61ed32d7ce32464d064e6f7bdd8932b = $(`&lt;div id=&quot;html_d61ed32d7ce32464d064e6f7bdd8932b&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;York University Heights&lt;/div&gt;`)[0];
            popup_d10f142897924dbf96ab0c9861247d15.setContent(html_d61ed32d7ce32464d064e6f7bdd8932b);


        marker_79607cc1a6867c24d782c46839efcb53.bindPopup(popup_d10f142897924dbf96ab0c9861247d15)
        ;




            var marker_2c3662f916a25afa5a783ed125e633e9 = L.marker(
                [43.76834039, -79.37043936],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_9c9b74ec8e706a83d8054f8862a9b9b5 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_a699e7602dc60f04937406e502286451 = $(`&lt;div id=&quot;html_a699e7602dc60f04937406e502286451&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Bayview Village&lt;/div&gt;`)[0];
            popup_9c9b74ec8e706a83d8054f8862a9b9b5.setContent(html_a699e7602dc60f04937406e502286451);


        marker_2c3662f916a25afa5a783ed125e633e9.bindPopup(popup_9c9b74ec8e706a83d8054f8862a9b9b5)
        ;




            var marker_123bcb2613d2d5d0a06fef49eded1df7 = L.marker(
                [43.74873834, -79.23556927],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_bdd4e5ccb5b219ab1981f5e4e2cf5adb = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_748de048c73e1f3b8525b5f143227f20 = $(`&lt;div id=&quot;html_748de048c73e1f3b8525b5f143227f20&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Eglinton East&lt;/div&gt;`)[0];
            popup_bdd4e5ccb5b219ab1981f5e4e2cf5adb.setContent(html_748de048c73e1f3b8525b5f143227f20);


        marker_123bcb2613d2d5d0a06fef49eded1df7.bindPopup(popup_bdd4e5ccb5b219ab1981f5e4e2cf5adb)
        ;




            var marker_82fcfb5d423bf567c2441698f8cc6195 = L.marker(
                [43.83402039, -79.22699861],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_cec9ab1ef9a86290bb8ef9923dee587c = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_f9a232e65a96421e51e9dcf435a6af5b = $(`&lt;div id=&quot;html_f9a232e65a96421e51e9dcf435a6af5b&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Rouge&lt;/div&gt;`)[0];
            popup_cec9ab1ef9a86290bb8ef9923dee587c.setContent(html_f9a232e65a96421e51e9dcf435a6af5b);


        marker_82fcfb5d423bf567c2441698f8cc6195.bindPopup(popup_cec9ab1ef9a86290bb8ef9923dee587c)
        ;




            var marker_13545a857286b586b4afc8a209c821cf = L.marker(
                [43.69702545, -79.49503182],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_eb65d04495ffbe3a867e9529a5fd97bd = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_a5a89c07625c5b1e8f3c1e6198318350 = $(`&lt;div id=&quot;html_a5a89c07625c5b1e8f3c1e6198318350&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Brookhaven-Amesbury&lt;/div&gt;`)[0];
            popup_eb65d04495ffbe3a867e9529a5fd97bd.setContent(html_a5a89c07625c5b1e8f3c1e6198318350);


        marker_13545a857286b586b4afc8a209c821cf.bindPopup(popup_eb65d04495ffbe3a867e9529a5fd97bd)
        ;




            var marker_50f4d3ac1c3fb9582a49448df8b41b36 = L.marker(
                [43.66094505, -79.43038141],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_c5977c133dbfb0fd7f85972f325105d8 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_3887261a91adb71a57b55553db6bbe09 = $(`&lt;div id=&quot;html_3887261a91adb71a57b55553db6bbe09&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Dufferin Grove&lt;/div&gt;`)[0];
            popup_c5977c133dbfb0fd7f85972f325105d8.setContent(html_3887261a91adb71a57b55553db6bbe09);


        marker_50f4d3ac1c3fb9582a49448df8b41b36.bindPopup(popup_c5977c133dbfb0fd7f85972f325105d8)
        ;




            var marker_43a53f25aa1fdacb4fa54e15b07831fe = L.marker(
                [43.69437813, -79.30056835],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_063a7f8e8f52d1c0b4c48eb7e77f2104 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_f36fb5b30ffd6d92e0bca6cd20ffa170 = $(`&lt;div id=&quot;html_f36fb5b30ffd6d92e0bca6cd20ffa170&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Taylor-Massey&lt;/div&gt;`)[0];
            popup_063a7f8e8f52d1c0b4c48eb7e77f2104.setContent(html_f36fb5b30ffd6d92e0bca6cd20ffa170);


        marker_43a53f25aa1fdacb4fa54e15b07831fe.bindPopup(popup_063a7f8e8f52d1c0b4c48eb7e77f2104)
        ;




            var marker_c798af39e59932a3f61571407d420053 = L.marker(
                [43.66399224, -79.36926698],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_222473cf8a64bdf480920598f859eb3a = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_1acdade94441a9152e2605a1b0939c62 = $(`&lt;div id=&quot;html_1acdade94441a9152e2605a1b0939c62&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Cabbagetown-South St.James Town&lt;/div&gt;`)[0];
            popup_222473cf8a64bdf480920598f859eb3a.setContent(html_1acdade94441a9152e2605a1b0939c62);


        marker_c798af39e59932a3f61571407d420053.bindPopup(popup_222473cf8a64bdf480920598f859eb3a)
        ;




            var marker_5fd1e2d2bfe1c0bd0e414e1c276921a6 = L.marker(
                [43.64938527, -79.42274326],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_83ff935f7fb9054d56d711765b8b4160 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_f8b57fd1807265caff80b0100ab3d5c2 = $(`&lt;div id=&quot;html_f8b57fd1807265caff80b0100ab3d5c2&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Trinity-Bellwoods&lt;/div&gt;`)[0];
            popup_83ff935f7fb9054d56d711765b8b4160.setContent(html_f8b57fd1807265caff80b0100ab3d5c2);


        marker_5fd1e2d2bfe1c0bd0e414e1c276921a6.bindPopup(popup_83ff935f7fb9054d56d711765b8b4160)
        ;




            var marker_ed99789cc6a57ffe66d85fb1f31ef112 = L.marker(
                [43.78420347, -79.39961562],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_a7ed79749e0a166911104c40d9d56521 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_068ebf9d8c869b9d041983b3b7fe08b1 = $(`&lt;div id=&quot;html_068ebf9d8c869b9d041983b3b7fe08b1&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Newtonbrook East&lt;/div&gt;`)[0];
            popup_a7ed79749e0a166911104c40d9d56521.setContent(html_068ebf9d8c869b9d041983b3b7fe08b1);


        marker_ed99789cc6a57ffe66d85fb1f31ef112.bindPopup(popup_a7ed79749e0a166911104c40d9d56521)
        ;




            var marker_7fa3691e7e9b4c560554d4549bf8be4f = L.marker(
                [43.68712374, -79.36076592],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_7ef293d3267c8b326af21df8ad0ec18d = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_9318f36114da45711359e4618d3cb633 = $(`&lt;div id=&quot;html_9318f36114da45711359e4618d3cb633&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Broadview North&lt;/div&gt;`)[0];
            popup_7ef293d3267c8b326af21df8ad0ec18d.setContent(html_9318f36114da45711359e4618d3cb633);


        marker_7fa3691e7e9b4c560554d4549bf8be4f.bindPopup(popup_7ef293d3267c8b326af21df8ad0ec18d)
        ;




            var marker_0160c722a7df0f32fc4c8cabe5518738 = L.marker(
                [43.70321772, -79.27947672],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_cac5c9274048ecb353ba461aea0302c4 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_5feab4f7bdb3881d2d9638a68cb62699 = $(`&lt;div id=&quot;html_5feab4f7bdb3881d2d9638a68cb62699&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Oakridge&lt;/div&gt;`)[0];
            popup_cac5c9274048ecb353ba461aea0302c4.setContent(html_5feab4f7bdb3881d2d9638a68cb62699);


        marker_0160c722a7df0f32fc4c8cabe5518738.bindPopup(popup_cac5c9274048ecb353ba461aea0302c4)
        ;




            var marker_211e9b397ab577deef7898e1fcf06fac = L.marker(
                [43.67201015, -79.44557624],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_768c033fdb938bf21f47573eb0fcdc67 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_821d564778908cb910b95a633e409d26 = $(`&lt;div id=&quot;html_821d564778908cb910b95a633e409d26&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Corso Italia-Davenport&lt;/div&gt;`)[0];
            popup_768c033fdb938bf21f47573eb0fcdc67.setContent(html_821d564778908cb910b95a633e409d26);


        marker_211e9b397ab577deef7898e1fcf06fac.bindPopup(popup_768c033fdb938bf21f47573eb0fcdc67)
        ;




            var marker_721b08d6bac1a4fbded3887c7beaf751 = L.marker(
                [43.61649591, -79.5210248],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_f4c996ca982261350878c8475d43d1b8 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_3afb00182fd312aa10b08903fd3d3ce5 = $(`&lt;div id=&quot;html_3afb00182fd312aa10b08903fd3d3ce5&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Mimico&lt;/div&gt;`)[0];
            popup_f4c996ca982261350878c8475d43d1b8.setContent(html_3afb00182fd312aa10b08903fd3d3ce5);


        marker_721b08d6bac1a4fbded3887c7beaf751.bindPopup(popup_f4c996ca982261350878c8475d43d1b8)
        ;




            var marker_84a40d7bd2dd77e2099db752f2f98a80 = L.marker(
                [43.77214083, -79.25145731],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_da40adf3f3ec78a2c59d01bc10fc18af = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_aae66aff9a8e9706bcf319b005bfffd9 = $(`&lt;div id=&quot;html_aae66aff9a8e9706bcf319b005bfffd9&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Woburn&lt;/div&gt;`)[0];
            popup_da40adf3f3ec78a2c59d01bc10fc18af.setContent(html_aae66aff9a8e9706bcf319b005bfffd9);


        marker_84a40d7bd2dd77e2099db752f2f98a80.bindPopup(popup_da40adf3f3ec78a2c59d01bc10fc18af)
        ;




            var marker_b0f8aef9956ee573789a176d61816d18 = L.marker(
                [43.72351294, -79.45978516],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_7ea17408ca15ec7b9100442e3e6aaedd = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_e1e34c2a795e14aa802ac22642deaa6b = $(`&lt;div id=&quot;html_e1e34c2a795e14aa802ac22642deaa6b&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Yorkdale-Glen Park&lt;/div&gt;`)[0];
            popup_7ea17408ca15ec7b9100442e3e6aaedd.setContent(html_e1e34c2a795e14aa802ac22642deaa6b);


        marker_b0f8aef9956ee573789a176d61816d18.bindPopup(popup_7ea17408ca15ec7b9100442e3e6aaedd)
        ;




            var marker_0a3e90975c1785e6cb86ade4bfab6615 = L.marker(
                [43.78469811, -79.17484165],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_a6e39857b0570685e6d2d788e0ade8eb = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_388b60dd047ffaee7f687d0a2e8947b8 = $(`&lt;div id=&quot;html_388b60dd047ffaee7f687d0a2e8947b8&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Highland Creek&lt;/div&gt;`)[0];
            popup_a6e39857b0570685e6d2d788e0ade8eb.setContent(html_388b60dd047ffaee7f687d0a2e8947b8);


        marker_0a3e90975c1785e6cb86ade4bfab6615.bindPopup(popup_a6e39857b0570685e6d2d788e0ade8eb)
        ;




            var marker_ca7e4770e27d367b3c3b890d686aed2a = L.marker(
                [0.0, 0.0],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_319293ebab226cbd85c6011afdb51db9 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_9e8b1cad47d4a1b0d65645db451c61c5 = $(`&lt;div id=&quot;html_9e8b1cad47d4a1b0d65645db451c61c5&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Victoria Village&lt;/div&gt;`)[0];
            popup_319293ebab226cbd85c6011afdb51db9.setContent(html_9e8b1cad47d4a1b0d65645db451c61c5);


        marker_ca7e4770e27d367b3c3b890d686aed2a.bindPopup(popup_319293ebab226cbd85c6011afdb51db9)
        ;




            var marker_9438668a462e27933e58b201bac94a46 = L.marker(
                [43.76758275, -79.18323393],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_060a4a35cf3745fa5b965f5b764c828f = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_ac91dec4ccb105bf2aec51576340cfa5 = $(`&lt;div id=&quot;html_ac91dec4ccb105bf2aec51576340cfa5&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;West Hill&lt;/div&gt;`)[0];
            popup_060a4a35cf3745fa5b965f5b764c828f.setContent(html_ac91dec4ccb105bf2aec51576340cfa5);


        marker_9438668a462e27933e58b201bac94a46.bindPopup(popup_060a4a35cf3745fa5b965f5b764c828f)
        ;




            var marker_054248051e0bd14bd31916f197b00bff = L.marker(
                [43.65680676, -79.36252926],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_64872e457456f934f0918a8079a30bef = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_f042cb81705de988efbdc38796f07504 = $(`&lt;div id=&quot;html_f042cb81705de988efbdc38796f07504&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Regent Park&lt;/div&gt;`)[0];
            popup_64872e457456f934f0918a8079a30bef.setContent(html_f042cb81705de988efbdc38796f07504);


        marker_054248051e0bd14bd31916f197b00bff.bindPopup(popup_64872e457456f934f0918a8079a30bef)
        ;




            var marker_5cfd8bf7ecd6e0f022d107626cdb4f8c = L.marker(
                [43.74375996, -79.30216238],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_438f22e5d04723374782b0be57ea9683 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_8eb47382de111b58360c2e3e1f31f438 = $(`&lt;div id=&quot;html_8eb47382de111b58360c2e3e1f31f438&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Wexford/Maryvale&lt;/div&gt;`)[0];
            popup_438f22e5d04723374782b0be57ea9683.setContent(html_8eb47382de111b58360c2e3e1f31f438);


        marker_5cfd8bf7ecd6e0f022d107626cdb4f8c.bindPopup(popup_438f22e5d04723374782b0be57ea9683)
        ;




            var marker_097f2abb1404dddb74974843c9e6c5c2 = L.marker(
                [43.67866925, -79.346226],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_6d28db2880b228237e49850586a9543d = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_f02b3a4602a73163913fe2943dd41558 = $(`&lt;div id=&quot;html_f02b3a4602a73163913fe2943dd41558&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Playter Estates-Danforth&lt;/div&gt;`)[0];
            popup_6d28db2880b228237e49850586a9543d.setContent(html_f02b3a4602a73163913fe2943dd41558);


        marker_097f2abb1404dddb74974843c9e6c5c2.bindPopup(popup_6d28db2880b228237e49850586a9543d)
        ;




            var marker_86206eab617d9089b15b03b5cbbe6e1f = L.marker(
                [43.6728738, -79.38782632],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_cff38ccaceedf9be672525d3f51fdc4f = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_58c1b05e5be3b04736408f0326564ed9 = $(`&lt;div id=&quot;html_58c1b05e5be3b04736408f0326564ed9&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Rosedale-Moore Park&lt;/div&gt;`)[0];
            popup_cff38ccaceedf9be672525d3f51fdc4f.setContent(html_58c1b05e5be3b04736408f0326564ed9);


        marker_86206eab617d9089b15b03b5cbbe6e1f.bindPopup(popup_cff38ccaceedf9be672525d3f51fdc4f)
        ;




            var marker_3125fdefb2596ddd1beb916a459c1347 = L.marker(
                [43.7694265, -79.34434334],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_e00fce643f8eb1cc0421d355656e25b3 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_e7f2b5fdffe497d88eed3b89f10d11c6 = $(`&lt;div id=&quot;html_e7f2b5fdffe497d88eed3b89f10d11c6&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Henry Farm&lt;/div&gt;`)[0];
            popup_e00fce643f8eb1cc0421d355656e25b3.setContent(html_e7f2b5fdffe497d88eed3b89f10d11c6);


        marker_3125fdefb2596ddd1beb916a459c1347.bindPopup(popup_e00fce643f8eb1cc0421d355656e25b3)
        ;




            var marker_61c858202bb946b984fa36364700748b = L.marker(
                [43.69676539, -79.44527396],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_98d79655652aed32495a67aa8ca0089d = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_f6272f0d19630f00f8c05bc9b5e08327 = $(`&lt;div id=&quot;html_f6272f0d19630f00f8c05bc9b5e08327&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Briar Hill-Belgravia&lt;/div&gt;`)[0];
            popup_98d79655652aed32495a67aa8ca0089d.setContent(html_f6272f0d19630f00f8c05bc9b5e08327);


        marker_61c858202bb946b984fa36364700748b.bindPopup(popup_98d79655652aed32495a67aa8ca0089d)
        ;




            var marker_9bce5fb03f4b1c9396d67b933f170418 = L.marker(
                [43.79206024, -79.25977154],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_c7ac239ace14725556a424f26c258f64 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_036630085e42e52f63dc82dfe7762381 = $(`&lt;div id=&quot;html_036630085e42e52f63dc82dfe7762381&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Agincourt South-Malvern West&lt;/div&gt;`)[0];
            popup_c7ac239ace14725556a424f26c258f64.setContent(html_036630085e42e52f63dc82dfe7762381);


        marker_9bce5fb03f4b1c9396d67b933f170418.bindPopup(popup_c7ac239ace14725556a424f26c258f64)
        ;




            var marker_7dfe16ff6b0d634b3745f74c6e5059c0 = L.marker(
                [43.64912973, -79.43790302],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_ec09366e0b7b57f3fd9d5478ecce2ee9 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_2171989ec8ab797c37e362584e8d18f1 = $(`&lt;div id=&quot;html_2171989ec8ab797c37e362584e8d18f1&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Little Portugal&lt;/div&gt;`)[0];
            popup_ec09366e0b7b57f3fd9d5478ecce2ee9.setContent(html_2171989ec8ab797c37e362584e8d18f1);


        marker_7dfe16ff6b0d634b3745f74c6e5059c0.bindPopup(popup_ec09366e0b7b57f3fd9d5478ecce2ee9)
        ;




            var marker_15d756b7ba9ef0c94cc7f46d3b3f2a90 = L.marker(
                [43.69144722, -79.32062053],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_1943a302b5c701d6240c7f214338db38 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_7b4794a3ed4b6a9a521622031b420b03 = $(`&lt;div id=&quot;html_7b4794a3ed4b6a9a521622031b420b03&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Danforth East York&lt;/div&gt;`)[0];
            popup_1943a302b5c701d6240c7f214338db38.setContent(html_7b4794a3ed4b6a9a521622031b420b03);


        marker_15d756b7ba9ef0c94cc7f46d3b3f2a90.bindPopup(popup_1943a302b5c701d6240c7f214338db38)
        ;




            var marker_50d852aef22abfe31df42814ee1564a7 = L.marker(
                [43.71492666, -79.33414521],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_694f01a8550a7e8b3ac57ae2e2e575fa = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_3f366851ba7de9b2346a413cbb6da1a1 = $(`&lt;div id=&quot;html_3f366851ba7de9b2346a413cbb6da1a1&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Flemingdon Park&lt;/div&gt;`)[0];
            popup_694f01a8550a7e8b3ac57ae2e2e575fa.setContent(html_3f366851ba7de9b2346a413cbb6da1a1);


        marker_50d852aef22abfe31df42814ee1564a7.bindPopup(popup_694f01a8550a7e8b3ac57ae2e2e575fa)
        ;




            var marker_9e886f5b6994121d9036ca3976acef32 = L.marker(
                [43.74248611, -79.22206817],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_123624d25709f9cc63ff0788cded78d4 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_7464af5266ec224721f42112bdfbd9a3 = $(`&lt;div id=&quot;html_7464af5266ec224721f42112bdfbd9a3&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Scarborough Village&lt;/div&gt;`)[0];
            popup_123624d25709f9cc63ff0788cded78d4.setContent(html_7464af5266ec224721f42112bdfbd9a3);


        marker_9e886f5b6994121d9036ca3976acef32.bindPopup(popup_123624d25709f9cc63ff0788cded78d4)
        ;




            var marker_ba3509a590da4806433d98d09c359329 = L.marker(
                [43.77888161, -79.41953867],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_4c5ab8dc9d3d5b36eed50fec8a800548 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_7e962d89f13ade2bb8a3624fd76b7591 = $(`&lt;div id=&quot;html_7e962d89f13ade2bb8a3624fd76b7591&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Newtonbrook West&lt;/div&gt;`)[0];
            popup_4c5ab8dc9d3d5b36eed50fec8a800548.setContent(html_7e962d89f13ade2bb8a3624fd76b7591);


        marker_ba3509a590da4806433d98d09c359329.bindPopup(popup_4c5ab8dc9d3d5b36eed50fec8a800548)
        ;




            var marker_ab90d343b84e70817f14e8b5bafd7a67 = L.marker(
                [43.71107784, -79.39927621],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_0c3458a3ae2652ffb2b0a2f6ed49d976 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_47d416ace1c4212cd1293727f4a81a4e = $(`&lt;div id=&quot;html_47d416ace1c4212cd1293727f4a81a4e&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Mount Pleasant West&lt;/div&gt;`)[0];
            popup_0c3458a3ae2652ffb2b0a2f6ed49d976.setContent(html_47d416ace1c4212cd1293727f4a81a4e);


        marker_ab90d343b84e70817f14e8b5bafd7a67.bindPopup(popup_0c3458a3ae2652ffb2b0a2f6ed49d976)
        ;




            var marker_4d78eb184ff4c3c3818fc692895b4acb = L.marker(
                [43.67780884, -79.47860613],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_6d06bf47a7f1041c3fd562bc85a55fb9 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_03015f6af22f2829b0b7e508c28907e7 = $(`&lt;div id=&quot;html_03015f6af22f2829b0b7e508c28907e7&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Rockcliffe-Smythe&lt;/div&gt;`)[0];
            popup_6d06bf47a7f1041c3fd562bc85a55fb9.setContent(html_03015f6af22f2829b0b7e508c28907e7);


        marker_4d78eb184ff4c3c3818fc692895b4acb.bindPopup(popup_6d06bf47a7f1041c3fd562bc85a55fb9)
        ;




            var marker_39d7d88be38454aaba20f7987a65e363 = L.marker(
                [43.63933996, -79.45127101],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_360098cf1952bf3dd12976f246eba6a8 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_e83eee3859ade7db7a4cf1e45ceef3cb = $(`&lt;div id=&quot;html_e83eee3859ade7db7a4cf1e45ceef3cb&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;High Park-Swansea&lt;/div&gt;`)[0];
            popup_360098cf1952bf3dd12976f246eba6a8.setContent(html_e83eee3859ade7db7a4cf1e45ceef3cb);


        marker_39d7d88be38454aaba20f7987a65e363.bindPopup(popup_360098cf1952bf3dd12976f246eba6a8)
        ;




            var marker_ad0c96aa98901f630071bbcc98dd56c6 = L.marker(
                [43.67051816, -79.31158524],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_af5f3f932b5675c63d4a04541b4b1d34 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_d27bae7820edc6d7d4fc823f9c6003a7 = $(`&lt;div id=&quot;html_d27bae7820edc6d7d4fc823f9c6003a7&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Woodbine Corridor&lt;/div&gt;`)[0];
            popup_af5f3f932b5675c63d4a04541b4b1d34.setContent(html_d27bae7820edc6d7d4fc823f9c6003a7);


        marker_ad0c96aa98901f630071bbcc98dd56c6.bindPopup(popup_af5f3f932b5675c63d4a04541b4b1d34)
        ;




            var marker_ffe651137e816f2ff10d28da13e52007 = L.marker(
                [43.70060252, -79.51775154],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_9b942f124489a15c51eec06187f6721c = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_a4c1eca2eaabd8e505a9f8cbe8069e19 = $(`&lt;div id=&quot;html_a4c1eca2eaabd8e505a9f8cbe8069e19&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Weston&lt;/div&gt;`)[0];
            popup_9b942f124489a15c51eec06187f6721c.setContent(html_a4c1eca2eaabd8e505a9f8cbe8069e19);


        marker_ffe651137e816f2ff10d28da13e52007.bindPopup(popup_9b942f124489a15c51eec06187f6721c)
        ;




            var marker_7ddedf835d2acb6250ca008849528bcc = L.marker(
                [43.76882728, -79.52036423],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_d3d577fcdd6935923d41f8c15993f6da = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_f7e9d10c3ed13f669fbdb984b6188b3c = $(`&lt;div id=&quot;html_f7e9d10c3ed13f669fbdb984b6188b3c&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Black Creek&lt;/div&gt;`)[0];
            popup_d3d577fcdd6935923d41f8c15993f6da.setContent(html_f7e9d10c3ed13f669fbdb984b6188b3c);


        marker_7ddedf835d2acb6250ca008849528bcc.bindPopup(popup_d3d577fcdd6935923d41f8c15993f6da)
        ;




            var marker_978572e63906148e414b5033e203cf69 = L.marker(
                [43.72998475, -79.26699358],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_0ae7673fd6e6ee2a06ac9806eb24be52 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_52cda540ebb60544240dbe1546564220 = $(`&lt;div id=&quot;html_52cda540ebb60544240dbe1546564220&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Kennedy Park&lt;/div&gt;`)[0];
            popup_0ae7673fd6e6ee2a06ac9806eb24be52.setContent(html_52cda540ebb60544240dbe1546564220);


        marker_978572e63906148e414b5033e203cf69.bindPopup(popup_0ae7673fd6e6ee2a06ac9806eb24be52)
        ;




            var marker_a30cadf01eb8b26c78adf5519323f695 = L.marker(
                [43.67862763, -79.32787432],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_a2227226f949fdba8949a9d5652042b0 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_e5a1e3aaac55538dca9715c291c9e845 = $(`&lt;div id=&quot;html_e5a1e3aaac55538dca9715c291c9e845&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Greenwood-Coxwell&lt;/div&gt;`)[0];
            popup_a2227226f949fdba8949a9d5652042b0.setContent(html_e5a1e3aaac55538dca9715c291c9e845);


        marker_a30cadf01eb8b26c78adf5519323f695.bindPopup(popup_a2227226f949fdba8949a9d5652042b0)
        ;




            var marker_8204cfa2875761267b2ccb738c18b2a6 = L.marker(
                [0.0, 0.0],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_5552241f21d8eb046976d8f3029113c8 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_eaa45ec874c84c315b3a6bb60b11d763 = $(`&lt;div id=&quot;html_eaa45ec874c84c315b3a6bb60b11d763&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;NSA&lt;/div&gt;`)[0];
            popup_5552241f21d8eb046976d8f3029113c8.setContent(html_eaa45ec874c84c315b3a6bb60b11d763);


        marker_8204cfa2875761267b2ccb738c18b2a6.bindPopup(popup_5552241f21d8eb046976d8f3029113c8)
        ;




            var marker_92c0ef2015f0dfa6983044309de6112a = L.marker(
                [43.78959109, -79.44983192],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_3f93b538cab743f1cdb084e8738bdd3d = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_f53ad6156ceebe6f2964aae2b6fec175 = $(`&lt;div id=&quot;html_f53ad6156ceebe6f2964aae2b6fec175&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Westminster-Branson&lt;/div&gt;`)[0];
            popup_3f93b538cab743f1cdb084e8738bdd3d.setContent(html_f53ad6156ceebe6f2964aae2b6fec175);


        marker_92c0ef2015f0dfa6983044309de6112a.bindPopup(popup_3f93b538cab743f1cdb084e8738bdd3d)
        ;




            var marker_f2bda4f99c3e5e4e9c0e6aeab8097a6a = L.marker(
                [43.6880498, -79.47154503],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_dcce07a6a457a94307986842dbcbbc4b = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_cf366dfb324830c28200588ba8224da5 = $(`&lt;div id=&quot;html_cf366dfb324830c28200588ba8224da5&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Keelesdale-Eglinton West&lt;/div&gt;`)[0];
            popup_dcce07a6a457a94307986842dbcbbc4b.setContent(html_cf366dfb324830c28200588ba8224da5);


        marker_f2bda4f99c3e5e4e9c0e6aeab8097a6a.bindPopup(popup_dcce07a6a457a94307986842dbcbbc4b)
        ;




            var marker_1cb2e26e913a6e7cffb8f20d20a26541 = L.marker(
                [43.75001169, -79.45390923],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_5f8e5cde8c412b45a88220f07b153b11 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_ce7941b6628d7b606bf1903c15a9cd4d = $(`&lt;div id=&quot;html_ce7941b6628d7b606bf1903c15a9cd4d&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Clanton Park&lt;/div&gt;`)[0];
            popup_5f8e5cde8c412b45a88220f07b153b11.setContent(html_ce7941b6628d7b606bf1903c15a9cd4d);


        marker_1cb2e26e913a6e7cffb8f20d20a26541.bindPopup(popup_5f8e5cde8c412b45a88220f07b153b11)
        ;




            var marker_b58c0721b7c0d8a17d1573cd0c5003ef = L.marker(
                [43.63920551, -79.58433063],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_3a76bd0e42645f96f7f0548b20ad070b = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_3a003bd557ddbd74c5dfd672fa5b5258 = $(`&lt;div id=&quot;html_3a003bd557ddbd74c5dfd672fa5b5258&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Markland Wood&lt;/div&gt;`)[0];
            popup_3a76bd0e42645f96f7f0548b20ad070b.setContent(html_3a003bd557ddbd74c5dfd672fa5b5258);


        marker_b58c0721b7c0d8a17d1573cd0c5003ef.bindPopup(popup_3a76bd0e42645f96f7f0548b20ad070b)
        ;




            var marker_7512d6fb88204b01ccce017aa889d54e = L.marker(
                [43.75258277, -79.28319326],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_ee6ea92474353e94e53d3d1303d20c0c = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_2d7c35b3cf9325efc3375448c3427ea4 = $(`&lt;div id=&quot;html_2d7c35b3cf9325efc3375448c3427ea4&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Dorset Park&lt;/div&gt;`)[0];
            popup_ee6ea92474353e94e53d3d1303d20c0c.setContent(html_2d7c35b3cf9325efc3375448c3427ea4);


        marker_7512d6fb88204b01ccce017aa889d54e.bindPopup(popup_ee6ea92474353e94e53d3d1303d20c0c)
        ;




            var marker_00bf4f266c1945c46c6aab2fd17951c6 = L.marker(
                [43.71427823, -79.3059261],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_60945b19214e605ab4f7473aa7ed5ee4 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_b9b0df2138cd96f58e36b54234868b7a = $(`&lt;div id=&quot;html_b9b0df2138cd96f58e36b54234868b7a&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;OConnor-Parkview&lt;/div&gt;`)[0];
            popup_60945b19214e605ab4f7473aa7ed5ee4.setContent(html_b9b0df2138cd96f58e36b54234868b7a);


        marker_00bf4f266c1945c46c6aab2fd17951c6.bindPopup(popup_60945b19214e605ab4f7473aa7ed5ee4)
        ;




            var marker_532c3bee232242e269964650887599fb = L.marker(
                [43.71178861, -79.37853604],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_3cb1037e87260cde9af4ffb66d83fdec = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_086fca9b8846a0ef0e8bbd3241102a96 = $(`&lt;div id=&quot;html_086fca9b8846a0ef0e8bbd3241102a96&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Mount Pleasant East&lt;/div&gt;`)[0];
            popup_3cb1037e87260cde9af4ffb66d83fdec.setContent(html_086fca9b8846a0ef0e8bbd3241102a96);


        marker_532c3bee232242e269964650887599fb.bindPopup(popup_3cb1037e87260cde9af4ffb66d83fdec)
        ;




            var marker_20ae53b5f94378da52f97ce521bbcc33 = L.marker(
                [43.66428681, -79.50215597],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_e97079842046c69bcb5ddfb4f1d069dc = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_43fd591012f03d6f434836449dc04326 = $(`&lt;div id=&quot;html_43fd591012f03d6f434836449dc04326&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Lambton Baby Point&lt;/div&gt;`)[0];
            popup_e97079842046c69bcb5ddfb4f1d069dc.setContent(html_43fd591012f03d6f434836449dc04326);


        marker_20ae53b5f94378da52f97ce521bbcc33.bindPopup(popup_e97079842046c69bcb5ddfb4f1d069dc)
        ;




            var marker_7559c062372d5b0003a950cc6b5e7e17 = L.marker(
                [43.73640808, -79.3818677],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_df8c56ea344c3980614c6f083721c8e3 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_990085a026216feb66dfeeee93b4b2ed = $(`&lt;div id=&quot;html_990085a026216feb66dfeeee93b4b2ed&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Bridle Path-Sunnybrook-York Mills&lt;/div&gt;`)[0];
            popup_df8c56ea344c3980614c6f083721c8e3.setContent(html_990085a026216feb66dfeeee93b4b2ed);


        marker_7559c062372d5b0003a950cc6b5e7e17.bindPopup(popup_df8c56ea344c3980614c6f083721c8e3)
        ;




            var marker_228a7fc7840a3e6d45dc39d6591b9cde = L.marker(
                [43.60750763, -79.52985168],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_ad9b73a50c90fd0a04833a68fae9fc3a = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_20e0722dca0b71f6dd7dd7455f7b1843 = $(`&lt;div id=&quot;html_20e0722dca0b71f6dd7dd7455f7b1843&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Alderwood&lt;/div&gt;`)[0];
            popup_ad9b73a50c90fd0a04833a68fae9fc3a.setContent(html_20e0722dca0b71f6dd7dd7455f7b1843);


        marker_228a7fc7840a3e6d45dc39d6591b9cde.bindPopup(popup_ad9b73a50c90fd0a04833a68fae9fc3a)
        ;




            var marker_aebb96881ffeb69f989d92dbe4216faf = L.marker(
                [43.60326759, -79.50627079],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_89b1b6b425085a02a671344114afbf55 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_3f8712165de8eb5a173b1926b3fbae01 = $(`&lt;div id=&quot;html_3f8712165de8eb5a173b1926b3fbae01&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;New Toronto&lt;/div&gt;`)[0];
            popup_89b1b6b425085a02a671344114afbf55.setContent(html_3f8712165de8eb5a173b1926b3fbae01);


        marker_aebb96881ffeb69f989d92dbe4216faf.bindPopup(popup_89b1b6b425085a02a671344114afbf55)
        ;




            var marker_ec23e0e10f8614e26647d1a8ccf949bf = L.marker(
                [43.69432519, -79.41498645],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_fc3a355e71fff8a260b8bdfeaf81a9e2 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_b6bd4567f51163809828452613f5b115 = $(`&lt;div id=&quot;html_b6bd4567f51163809828452613f5b115&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Forest Hill South&lt;/div&gt;`)[0];
            popup_fc3a355e71fff8a260b8bdfeaf81a9e2.setContent(html_b6bd4567f51163809828452613f5b115);


        marker_ec23e0e10f8614e26647d1a8ccf949bf.bindPopup(popup_fc3a355e71fff8a260b8bdfeaf81a9e2)
        ;




            var marker_2afa7239851b11e8d993f49da5dbec16 = L.marker(
                [43.72935527, -79.32835907],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_66b2538b2cd6a42754c2f12ecd0283f0 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_61a7c4f0fbd7929b3c05ed3381d3c350 = $(`&lt;div id=&quot;html_61a7c4f0fbd7929b3c05ed3381d3c350&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Banbury-Don Mills&lt;/div&gt;`)[0];
            popup_66b2538b2cd6a42754c2f12ecd0283f0.setContent(html_61a7c4f0fbd7929b3c05ed3381d3c350);


        marker_2afa7239851b11e8d993f49da5dbec16.bindPopup(popup_66b2538b2cd6a42754c2f12ecd0283f0)
        ;




            var marker_da3f11616c618c1f082bf28ebd0c50cb = L.marker(
                [43.7441499, -79.40668473],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_e02c80aae3e87a673d476f871a2edce3 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_a26fcd623d9af434266a22d6da6046b1 = $(`&lt;div id=&quot;html_a26fcd623d9af434266a22d6da6046b1&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;St.Andrew-Windfields&lt;/div&gt;`)[0];
            popup_e02c80aae3e87a673d476f871a2edce3.setContent(html_a26fcd623d9af434266a22d6da6046b1);


        marker_da3f11616c618c1f082bf28ebd0c50cb.bindPopup(popup_e02c80aae3e87a673d476f871a2edce3)
        ;




            var marker_e4bae036ac5c36717164ae5fcd41f3ac = L.marker(
                [43.65633298, -79.46818422],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_48e9732af6b2f6295f879657c04d0731 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_b573e90805c627d9b225043730de1406 = $(`&lt;div id=&quot;html_b573e90805c627d9b225043730de1406&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;High Park North&lt;/div&gt;`)[0];
            popup_48e9732af6b2f6295f879657c04d0731.setContent(html_b573e90805c627d9b225043730de1406);


        marker_e4bae036ac5c36717164ae5fcd41f3ac.bindPopup(popup_48e9732af6b2f6295f879657c04d0731)
        ;




            var marker_668d5a060acff573a917a31d7e7155e6 = L.marker(
                [43.67235839, -79.37681431],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_b98294ce5e79cd5993584895f07c9594 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_54bb255b73af92f486fb815256d283e0 = $(`&lt;div id=&quot;html_54bb255b73af92f486fb815256d283e0&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;North St.James Town&lt;/div&gt;`)[0];
            popup_b98294ce5e79cd5993584895f07c9594.setContent(html_54bb255b73af92f486fb815256d283e0);


        marker_668d5a060acff573a917a31d7e7155e6.bindPopup(popup_b98294ce5e79cd5993584895f07c9594)
        ;




            var marker_1bbae35638dcf7265e0c6e51fa039b11 = L.marker(
                [43.72798391, -79.22908163],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_9bffa92884eb046264d469c528e9b0cd = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_05d3c3ce98ec97b553bce5b47a2f692b = $(`&lt;div id=&quot;html_05d3c3ce98ec97b553bce5b47a2f692b&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Cliffcrest&lt;/div&gt;`)[0];
            popup_9bffa92884eb046264d469c528e9b0cd.setContent(html_05d3c3ce98ec97b553bce5b47a2f692b);


        marker_1bbae35638dcf7265e0c6e51fa039b11.bindPopup(popup_9bffa92884eb046264d469c528e9b0cd)
        ;




            var marker_76c965a452a0471d14dd61bc2066988c = L.marker(
                [43.7366874, -79.5088181],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_1cc15002f4c856fe771611838c468fae = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_c2b0044ff4300595672811b90c614d87 = $(`&lt;div id=&quot;html_c2b0044ff4300595672811b90c614d87&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Glenfield-Jane Heights&lt;/div&gt;`)[0];
            popup_1cc15002f4c856fe771611838c468fae.setContent(html_c2b0044ff4300595672811b90c614d87);


        marker_76c965a452a0471d14dd61bc2066988c.bindPopup(popup_1cc15002f4c856fe771611838c468fae)
        ;




            var marker_c9e5f19bbb72b312365acacc64f294aa = L.marker(
                [43.76262335, -79.56438518],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_4854aa5b9bbe717c771abe9b943ba268 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_4e2ed8a7135e3411961f2f88fc268d7c = $(`&lt;div id=&quot;html_4e2ed8a7135e3411961f2f88fc268d7c&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Humber Summit&lt;/div&gt;`)[0];
            popup_4854aa5b9bbe717c771abe9b943ba268.setContent(html_4e2ed8a7135e3411961f2f88fc268d7c);


        marker_c9e5f19bbb72b312365acacc64f294aa.bindPopup(popup_4854aa5b9bbe717c771abe9b943ba268)
        ;




            var marker_4ad538a157b8b07506799f38018f0641 = L.marker(
                [43.71545763, -79.50718536],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_68cee9d634536470868929f84e98165e = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_c43a4d77263dbd20eb522a2780d6858f = $(`&lt;div id=&quot;html_c43a4d77263dbd20eb522a2780d6858f&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Pelmo Park-Humberlea&lt;/div&gt;`)[0];
            popup_68cee9d634536470868929f84e98165e.setContent(html_c43a4d77263dbd20eb522a2780d6858f);


        marker_4ad538a157b8b07506799f38018f0641.bindPopup(popup_68cee9d634536470868929f84e98165e)
        ;




            var marker_76b2ba16a30fccd479be13744b74f6de = L.marker(
                [43.62229718, -79.50590083],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_0fdb0a6d52a3ccf358ff7ab44524141c = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_289d03c84e41e4d73f5c55c8fc5ed9d9 = $(`&lt;div id=&quot;html_289d03c84e41e4d73f5c55c8fc5ed9d9&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Stonegate-Queensway&lt;/div&gt;`)[0];
            popup_0fdb0a6d52a3ccf358ff7ab44524141c.setContent(html_289d03c84e41e4d73f5c55c8fc5ed9d9);


        marker_76b2ba16a30fccd479be13744b74f6de.bindPopup(popup_0fdb0a6d52a3ccf358ff7ab44524141c)
        ;




            var marker_e48710c725df4faa805c8fdbf29e6c77 = L.marker(
                [43.70151038, -79.25289415],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_2b429d9e252282f86b1533f40b54d3cc = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_f06731dbf486b7e3e16cdcf315a212c0 = $(`&lt;div id=&quot;html_f06731dbf486b7e3e16cdcf315a212c0&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Birchcliffe-Cliffside&lt;/div&gt;`)[0];
            popup_2b429d9e252282f86b1533f40b54d3cc.setContent(html_f06731dbf486b7e3e16cdcf315a212c0);


        marker_e48710c725df4faa805c8fdbf29e6c77.bindPopup(popup_2b429d9e252282f86b1533f40b54d3cc)
        ;




            var marker_89de83f35fd21bf6193d1cae1a27aa4e = L.marker(
                [43.75545869, -79.43844041],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_f980cb7c439f5863423569f5f2c430e6 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_b41b6b24bb9ab2aee80930cb422ef616 = $(`&lt;div id=&quot;html_b41b6b24bb9ab2aee80930cb422ef616&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Bathurst Manor&lt;/div&gt;`)[0];
            popup_f980cb7c439f5863423569f5f2c430e6.setContent(html_b41b6b24bb9ab2aee80930cb422ef616);


        marker_89de83f35fd21bf6193d1cae1a27aa4e.bindPopup(popup_f980cb7c439f5863423569f5f2c430e6)
        ;




            var marker_60255d871c808946c0b95dcbeab7d03d = L.marker(
                [43.71780474, -79.40349687],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_6439f6839959474dd66b834ea2170218 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_be7703631c37d4bfaa1f517ed23db4ba = $(`&lt;div id=&quot;html_be7703631c37d4bfaa1f517ed23db4ba&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Lawrence Park South&lt;/div&gt;`)[0];
            popup_6439f6839959474dd66b834ea2170218.setContent(html_be7703631c37d4bfaa1f517ed23db4ba);


        marker_60255d871c808946c0b95dcbeab7d03d.bindPopup(popup_6439f6839959474dd66b834ea2170218)
        ;




            var marker_832f6d23ec43230c182510090552aaf6 = L.marker(
                [43.66542584, -79.46585038],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_8bcbd3c9c0b0547a9ed7e3e1a038cd4e = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_99890f74366c64b7a16b14314f76a4d0 = $(`&lt;div id=&quot;html_99890f74366c64b7a16b14314f76a4d0&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Junction Area&lt;/div&gt;`)[0];
            popup_8bcbd3c9c0b0547a9ed7e3e1a038cd4e.setContent(html_99890f74366c64b7a16b14314f76a4d0);


        marker_832f6d23ec43230c182510090552aaf6.bindPopup(popup_8bcbd3c9c0b0547a9ed7e3e1a038cd4e)
        ;




            var marker_f9930195ae71606ed50a905aab104655 = L.marker(
                [43.71510482, -79.55507738],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_04e6fd9cb4cf1db762030868b664228a = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_4e686bfc31117b47de9a77af758f6a30 = $(`&lt;div id=&quot;html_4e686bfc31117b47de9a77af758f6a30&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Rexdale-Kipling&lt;/div&gt;`)[0];
            popup_04e6fd9cb4cf1db762030868b664228a.setContent(html_4e686bfc31117b47de9a77af758f6a30);


        marker_f9930195ae71606ed50a905aab104655.bindPopup(popup_04e6fd9cb4cf1db762030868b664228a)
        ;




            var marker_9460b398c83bd5e76e8b147d123d71d5 = L.marker(
                [43.77908536, -79.34869595],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_fec525191f023e617c47a515b6f13ee2 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_123566c0c564f640f56bfbeaff0f209e = $(`&lt;div id=&quot;html_123566c0c564f640f56bfbeaff0f209e&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Don Valley Village&lt;/div&gt;`)[0];
            popup_fec525191f023e617c47a515b6f13ee2.setContent(html_123566c0c564f640f56bfbeaff0f209e);


        marker_9460b398c83bd5e76e8b147d123d71d5.bindPopup(popup_fec525191f023e617c47a515b6f13ee2)
        ;




            var marker_8f4d734975c3dafde476be97f4e47470 = L.marker(
                [43.72003382, -79.42993872],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_73eb73ee0a3a215b107a2e4696996193 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_eb7e8b420c03c4ab5de2042ecc278c9b = $(`&lt;div id=&quot;html_eb7e8b420c03c4ab5de2042ecc278c9b&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Bedford Park-Nortown&lt;/div&gt;`)[0];
            popup_73eb73ee0a3a215b107a2e4696996193.setContent(html_eb7e8b420c03c4ab5de2042ecc278c9b);


        marker_8f4d734975c3dafde476be97f4e47470.bindPopup(popup_73eb73ee0a3a215b107a2e4696996193)
        ;




            var marker_45c4727c8a68b7f00a33bfcf18c095e6 = L.marker(
                [43.7727692, -79.44063916],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_79d6a01a5d34f6b8c4f677f3dc94fce4 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_9e0ec72fbf6f344dbe2a7a524debd2a4 = $(`&lt;div id=&quot;html_9e0ec72fbf6f344dbe2a7a524debd2a4&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Willowdale West&lt;/div&gt;`)[0];
            popup_79d6a01a5d34f6b8c4f677f3dc94fce4.setContent(html_9e0ec72fbf6f344dbe2a7a524debd2a4);


        marker_45c4727c8a68b7f00a33bfcf18c095e6.bindPopup(popup_79d6a01a5d34f6b8c4f677f3dc94fce4)
        ;




            var marker_df5877a017e663bd1fa15b8ace267a1d = L.marker(
                [43.79031287, -79.19793737],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_e8a3ab6c9d2803d7dc63b4338199d70f = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_1e84ae98a66370c8ebbb0bf8624e03aa = $(`&lt;div id=&quot;html_1e84ae98a66370c8ebbb0bf8624e03aa&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Morningside&lt;/div&gt;`)[0];
            popup_e8a3ab6c9d2803d7dc63b4338199d70f.setContent(html_1e84ae98a66370c8ebbb0bf8624e03aa);


        marker_df5877a017e663bd1fa15b8ace267a1d.bindPopup(popup_e8a3ab6c9d2803d7dc63b4338199d70f)
        ;




            var marker_f811c6581eff318b92f12130398d7851 = L.marker(
                [43.8164915, -79.33141941],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_438929b6b13a6804ada867dc814e22a5 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_03f5a5dac0a2887931b9b6dd3d0fda61 = $(`&lt;div id=&quot;html_03f5a5dac0a2887931b9b6dd3d0fda61&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Steeles&lt;/div&gt;`)[0];
            popup_438929b6b13a6804ada867dc814e22a5.setContent(html_03f5a5dac0a2887931b9b6dd3d0fda61);


        marker_f811c6581eff318b92f12130398d7851.bindPopup(popup_438929b6b13a6804ada867dc814e22a5)
        ;




            var marker_e48e88e510809d73bae9d977857bd56c = L.marker(
                [43.78714471, -79.15225673],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_a8510c36c6b7deaa97a612146b0a7571 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_fb31def5267a93ecf60db882c90de6ca = $(`&lt;div id=&quot;html_fb31def5267a93ecf60db882c90de6ca&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Centennial Scarborough&lt;/div&gt;`)[0];
            popup_a8510c36c6b7deaa97a612146b0a7571.setContent(html_fb31def5267a93ecf60db882c90de6ca);


        marker_e48e88e510809d73bae9d977857bd56c.bindPopup(popup_a8510c36c6b7deaa97a612146b0a7571)
        ;




            var marker_261d0dd41d20578629d5a1be0e8a5508 = L.marker(
                [43.6897005, -79.39744799],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_78ac17c36709911e7f8e9b574d15d61b = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_2e9842e3deb3274e9ba36ec0dc5212fd = $(`&lt;div id=&quot;html_2e9842e3deb3274e9ba36ec0dc5212fd&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Yonge-St.Clair&lt;/div&gt;`)[0];
            popup_78ac17c36709911e7f8e9b574d15d61b.setContent(html_2e9842e3deb3274e9ba36ec0dc5212fd);


        marker_261d0dd41d20578629d5a1be0e8a5508.bindPopup(popup_78ac17c36709911e7f8e9b574d15d61b)
        ;




            var marker_fdaf0fa97882c7950915c33ebb9fd9b7 = L.marker(
                [43.6799437, -79.40611935],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_e302021fb93533353bd4586cb37ad685 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_44e30fbef762ad54b95361373c588066 = $(`&lt;div id=&quot;html_44e30fbef762ad54b95361373c588066&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Casa Loma&lt;/div&gt;`)[0];
            popup_e302021fb93533353bd4586cb37ad685.setContent(html_44e30fbef762ad54b95361373c588066);


        marker_fdaf0fa97882c7950915c33ebb9fd9b7.bindPopup(popup_e302021fb93533353bd4586cb37ad685)
        ;




            var marker_542cb4884d59a86b07b5f09d9ae5caf3 = L.marker(
                [43.80263794, -79.35242116],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_ff9645409de96d725a1eddf641be23eb = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_119656c284091b2766ed1bcc89ba0124 = $(`&lt;div id=&quot;html_119656c284091b2766ed1bcc89ba0124&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Hillcrest Village&lt;/div&gt;`)[0];
            popup_ff9645409de96d725a1eddf641be23eb.setContent(html_119656c284091b2766ed1bcc89ba0124);


        marker_542cb4884d59a86b07b5f09d9ae5caf3.bindPopup(popup_ff9645409de96d725a1eddf641be23eb)
        ;




            var marker_4206f5066b56fb92568cfeb146ba2fe7 = L.marker(
                [43.66465652, -79.40270156],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_f8cc2594cb8d798052988843851a62a0 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_a37ab0b6a39b4dbc336444013960e4d5 = $(`&lt;div id=&quot;html_a37ab0b6a39b4dbc336444013960e4d5&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;University&lt;/div&gt;`)[0];
            popup_f8cc2594cb8d798052988843851a62a0.setContent(html_a37ab0b6a39b4dbc336444013960e4d5);


        marker_4206f5066b56fb92568cfeb146ba2fe7.bindPopup(popup_f8cc2594cb8d798052988843851a62a0)
        ;




            var marker_689da10d0a3829ee956cd70696dcdff3 = L.marker(
                [43.73114796, -79.40750317],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_eb522d42d789b1ef121a445e96cb1baf = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_44b1d68dd394a236a40ed17024d6affd = $(`&lt;div id=&quot;html_44b1d68dd394a236a40ed17024d6affd&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Lawrence Park North&lt;/div&gt;`)[0];
            popup_eb522d42d789b1ef121a445e96cb1baf.setContent(html_44b1d68dd394a236a40ed17024d6affd);


        marker_689da10d0a3829ee956cd70696dcdff3.bindPopup(popup_eb522d42d789b1ef121a445e96cb1baf)
        ;




            var marker_34676a81af2aa92b5be27ea8857e4ff6 = L.marker(
                [43.76053065, -79.4231866],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_d4a36b967ba37583f5c2bbd619b3831e = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_b17d1007c19d523b188ccf7d33b6d3a4 = $(`&lt;div id=&quot;html_b17d1007c19d523b188ccf7d33b6d3a4&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Lansing-Westgate&lt;/div&gt;`)[0];
            popup_d4a36b967ba37583f5c2bbd619b3831e.setContent(html_b17d1007c19d523b188ccf7d33b6d3a4);


        marker_34676a81af2aa92b5be27ea8857e4ff6.bindPopup(popup_d4a36b967ba37583f5c2bbd619b3831e)
        ;




            var marker_e0ad721aa170793a48db92a742d22d9a = L.marker(
                [43.74326507, -79.58207638],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_8f9328ac3e678ffff201d276860d4dd2 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_95531ad11a225dd65f827f584d9aab0c = $(`&lt;div id=&quot;html_95531ad11a225dd65f827f584d9aab0c&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Mount Olive-Silverstone-Jamestown&lt;/div&gt;`)[0];
            popup_8f9328ac3e678ffff201d276860d4dd2.setContent(html_95531ad11a225dd65f827f584d9aab0c);


        marker_e0ad721aa170793a48db92a742d22d9a.bindPopup(popup_8f9328ac3e678ffff201d276860d4dd2)
        ;




            var marker_abd9b793a2f9253e5526530012f4f5df = L.marker(
                [43.77797984, -79.31116492],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_d0071714c46a7423b02e80300f05cc5b = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_310dc8a79d5b7a93177ba03488af92fe = $(`&lt;div id=&quot;html_310dc8a79d5b7a93177ba03488af92fe&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Tam OShanter-Sullivan&lt;/div&gt;`)[0];
            popup_d0071714c46a7423b02e80300f05cc5b.setContent(html_310dc8a79d5b7a93177ba03488af92fe);


        marker_abd9b793a2f9253e5526530012f4f5df.bindPopup(popup_d0071714c46a7423b02e80300f05cc5b)
        ;




            var marker_b16e9333142076c92f0993b23c1a035b = L.marker(
                [43.71806233, -79.55384096],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_1e80e4122d60ff9d81e660aea34df748 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_e2864850b63f5d09bf583f21a3f96a08 = $(`&lt;div id=&quot;html_e2864850b63f5d09bf583f21a3f96a08&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Elms-Old Rexdale&lt;/div&gt;`)[0];
            popup_1e80e4122d60ff9d81e660aea34df748.setContent(html_e2864850b63f5d09bf583f21a3f96a08);


        marker_b16e9333142076c92f0993b23c1a035b.bindPopup(popup_1e80e4122d60ff9d81e660aea34df748)
        ;




            var marker_721e2594219e74a6d9afdaaf52cc8cbb = L.marker(
                [43.70628591, -79.37403755],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_6092941d765e07272ea50b1b86c3206d = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_d74148174a9e175473c62f59405e1da4 = $(`&lt;div id=&quot;html_d74148174a9e175473c62f59405e1da4&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Leaside-Bennington&lt;/div&gt;`)[0];
            popup_6092941d765e07272ea50b1b86c3206d.setContent(html_d74148174a9e175473c62f59405e1da4);


        marker_721e2594219e74a6d9afdaaf52cc8cbb.bindPopup(popup_6092941d765e07272ea50b1b86c3206d)
        ;




            var marker_bb7b38ed920b1e3bed548dcf3c96dd88 = L.marker(
                [43.79500447, -79.32961357],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_a65ba8392a70c06c4d3687435ef735a8 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_3780b19c4ae3a443d4cab7c0f967b331 = $(`&lt;div id=&quot;html_3780b19c4ae3a443d4cab7c0f967b331&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;LAmoreaux&lt;/div&gt;`)[0];
            popup_a65ba8392a70c06c4d3687435ef735a8.setContent(html_3780b19c4ae3a443d4cab7c0f967b331);


        marker_bb7b38ed920b1e3bed548dcf3c96dd88.bindPopup(popup_a65ba8392a70c06c4d3687435ef735a8)
        ;




            var marker_1c0021bc409265446fc702ec8d1f2811 = L.marker(
                [43.71574209, -79.5047176],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_d6a4080888a0ead5384ca8cd2811aca4 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_dbb014da1722e58be5f83e2f2c918710 = $(`&lt;div id=&quot;html_dbb014da1722e58be5f83e2f2c918710&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Rustic&lt;/div&gt;`)[0];
            popup_d6a4080888a0ead5384ca8cd2811aca4.setContent(html_dbb014da1722e58be5f83e2f2c918710);


        marker_1c0021bc409265446fc702ec8d1f2811.bindPopup(popup_d6a4080888a0ead5384ca8cd2811aca4)
        ;




            var marker_4d7d2e976e3236c0c671cfb0763c29ed = L.marker(
                [43.67779387, -79.35070987],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_2da18a138a591e7e807c2789ae6135cd = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_e23de4b34cf15766fdfefefbd7a693df = $(`&lt;div id=&quot;html_e23de4b34cf15766fdfefefbd7a693df&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;North Riverdale&lt;/div&gt;`)[0];
            popup_2da18a138a591e7e807c2789ae6135cd.setContent(html_e23de4b34cf15766fdfefefbd7a693df);


        marker_4d7d2e976e3236c0c671cfb0763c29ed.bindPopup(popup_2da18a138a591e7e807c2789ae6135cd)
        ;




            var marker_af5111f72a4d3344e374f9ac08507b27 = L.marker(
                [43.68445552, -79.42140231],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_94b0964357cf0b88b53eaa90732075f9 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_126c3772829eddf607ad5000df7edc9b = $(`&lt;div id=&quot;html_126c3772829eddf607ad5000df7edc9b&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Humewood-Cedarvale&lt;/div&gt;`)[0];
            popup_94b0964357cf0b88b53eaa90732075f9.setContent(html_126c3772829eddf607ad5000df7edc9b);


        marker_af5111f72a4d3344e374f9ac08507b27.bindPopup(popup_94b0964357cf0b88b53eaa90732075f9)
        ;




            var marker_b1823f83801279ec8562d8411fd2aa3e = L.marker(
                [43.74171555, -79.57377923],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_39c67c12a447bda3c6f0219dd1ea42cb = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_8718c24087765f7b9429e7d9095a620d = $(`&lt;div id=&quot;html_8718c24087765f7b9429e7d9095a620d&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Thistletown-Beaumond Heights&lt;/div&gt;`)[0];
            popup_39c67c12a447bda3c6f0219dd1ea42cb.setContent(html_8718c24087765f7b9429e7d9095a620d);


        marker_b1823f83801279ec8562d8411fd2aa3e.bindPopup(popup_39c67c12a447bda3c6f0219dd1ea42cb)
        ;




            var marker_61d14a294ba765fe0bfa06d744213669 = L.marker(
                [43.6761888, -79.33746603],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_8d2d752ca04ec55e774c5b90ca5fd72f = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_33dc2406fe544502b6d36d556d213f9e = $(`&lt;div id=&quot;html_33dc2406fe544502b6d36d556d213f9e&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Blake-Jones&lt;/div&gt;`)[0];
            popup_8d2d752ca04ec55e774c5b90ca5fd72f.setContent(html_33dc2406fe544502b6d36d556d213f9e);


        marker_61d14a294ba765fe0bfa06d744213669.bindPopup(popup_8d2d752ca04ec55e774c5b90ca5fd72f)
        ;




            var marker_6ffd17185763fbf5c2057c05ec954ad6 = L.marker(
                [43.66198485, -79.42562006],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_55394e4c83c71987db81be6a6c2f4eb3 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_8b29da20a58c476460e69e528a4324c7 = $(`&lt;div id=&quot;html_8b29da20a58c476460e69e528a4324c7&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Palmerston-Little Italy&lt;/div&gt;`)[0];
            popup_55394e4c83c71987db81be6a6c2f4eb3.setContent(html_8b29da20a58c476460e69e528a4324c7);


        marker_6ffd17185763fbf5c2057c05ec954ad6.bindPopup(popup_55394e4c83c71987db81be6a6c2f4eb3)
        ;




            var marker_b09794bb20a82ff225a62b6715621f1a = L.marker(
                [43.64207956, -79.58609531],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_3a2613c2b8a2354601c47338da5d81cd = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_4594bab19b6a6b03a279e99def5567f9 = $(`&lt;div id=&quot;html_4594bab19b6a6b03a279e99def5567f9&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Eringate-Centennial-West Deane&lt;/div&gt;`)[0];
            popup_3a2613c2b8a2354601c47338da5d81cd.setContent(html_4594bab19b6a6b03a279e99def5567f9);


        marker_b09794bb20a82ff225a62b6715621f1a.bindPopup(popup_3a2613c2b8a2354601c47338da5d81cd)
        ;




            var marker_21f86377fd118d296b119be34ac409ed = L.marker(
                [43.73027846, -79.43819728],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_416f7f40d4e511c31c3aa9259572c2b8 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_fd2ced123420dfcf83ca9329ae9a6ea7 = $(`&lt;div id=&quot;html_fd2ced123420dfcf83ca9329ae9a6ea7&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Englemount-Lawrence&lt;/div&gt;`)[0];
            popup_416f7f40d4e511c31c3aa9259572c2b8.setContent(html_fd2ced123420dfcf83ca9329ae9a6ea7);


        marker_21f86377fd118d296b119be34ac409ed.bindPopup(popup_416f7f40d4e511c31c3aa9259572c2b8)
        ;




            var marker_e5ee8de32afdfc372aa23de760dc53cf = L.marker(
                [43.69876975, -79.43597803],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_4d935fc5949e42ceb9395925f7408254 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_038e3bdcf4a391ebcc1e228cd90eb2aa = $(`&lt;div id=&quot;html_038e3bdcf4a391ebcc1e228cd90eb2aa&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Forest Hill North&lt;/div&gt;`)[0];
            popup_4d935fc5949e42ceb9395925f7408254.setContent(html_038e3bdcf4a391ebcc1e228cd90eb2aa);


        marker_e5ee8de32afdfc372aa23de760dc53cf.bindPopup(popup_4d935fc5949e42ceb9395925f7408254)
        ;




            var marker_9e0cb105ca6826436f71bffa6e13fce7 = L.marker(
                [43.66561293, -79.48477942],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_e503a1e24faac6d529bfadf285486cc5 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_7e2ab060f9f5a190b7eab607dd15882f = $(`&lt;div id=&quot;html_7e2ab060f9f5a190b7eab607dd15882f&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Runnymede-Bloor West Village&lt;/div&gt;`)[0];
            popup_e503a1e24faac6d529bfadf285486cc5.setContent(html_7e2ab060f9f5a190b7eab607dd15882f);


        marker_9e0cb105ca6826436f71bffa6e13fce7.bindPopup(popup_e503a1e24faac6d529bfadf285486cc5)
        ;




            var marker_c016aade9aaec50213847fc8b161e137 = L.marker(
                [43.67633938, -79.57037025],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_a80c7558648ceba1bb59160c47ea51f6 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_32e623e1a39d0131384bfe01cb591ab3 = $(`&lt;div id=&quot;html_32e623e1a39d0131384bfe01cb591ab3&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Willowridge-Martingrove-Richview&lt;/div&gt;`)[0];
            popup_a80c7558648ceba1bb59160c47ea51f6.setContent(html_32e623e1a39d0131384bfe01cb591ab3);


        marker_c016aade9aaec50213847fc8b161e137.bindPopup(popup_a80c7558648ceba1bb59160c47ea51f6)
        ;




            var marker_659fb150de3e74cb82b3e01b9097cf8e = L.marker(
                [43.808508, -79.3724657],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_54a54c7f06d8f7b17b83e5e869ca0ee7 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_90d3eb254d9c88064bb4b304447a155d = $(`&lt;div id=&quot;html_90d3eb254d9c88064bb4b304447a155d&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Bayview Woods-Steeles&lt;/div&gt;`)[0];
            popup_54a54c7f06d8f7b17b83e5e869ca0ee7.setContent(html_90d3eb254d9c88064bb4b304447a155d);


        marker_659fb150de3e74cb82b3e01b9097cf8e.bindPopup(popup_54a54c7f06d8f7b17b83e5e869ca0ee7)
        ;




            var marker_6afa4d77bdd27bf64d29272545044c90 = L.marker(
                [43.79922772, -79.28219213],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_7c63dccce7a226283d93a24f22a9376e = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_66fd56136fd1f9ffe800c592875cb00e = $(`&lt;div id=&quot;html_66fd56136fd1f9ffe800c592875cb00e&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Agincourt North&lt;/div&gt;`)[0];
            popup_7c63dccce7a226283d93a24f22a9376e.setContent(html_66fd56136fd1f9ffe800c592875cb00e);


        marker_6afa4d77bdd27bf64d29272545044c90.bindPopup(popup_7c63dccce7a226283d93a24f22a9376e)
        ;




            var marker_2bdd7d8426d8b782d2ffdd4d60d9548d = L.marker(
                [43.69214748, -79.30477556],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_14dfd630aa74a958bbf3359ac1b8b2d3 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_5099955878f542cfa86b456d434807f7 = $(`&lt;div id=&quot;html_5099955878f542cfa86b456d434807f7&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Woodbine-Lumsden&lt;/div&gt;`)[0];
            popup_14dfd630aa74a958bbf3359ac1b8b2d3.setContent(html_5099955878f542cfa86b456d434807f7);


        marker_2bdd7d8426d8b782d2ffdd4d60d9548d.bindPopup(popup_14dfd630aa74a958bbf3359ac1b8b2d3)
        ;




            var marker_14e9395014aac2c7ee04e54d90dbfa0d = L.marker(
                [43.59415756, -79.52254725],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_cc3b2598338640a2d6de7849e4beb5fb = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_e2c3d9a2953f16ffd8dd788e821dae0a = $(`&lt;div id=&quot;html_e2c3d9a2953f16ffd8dd788e821dae0a&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Long Branch&lt;/div&gt;`)[0];
            popup_cc3b2598338640a2d6de7849e4beb5fb.setContent(html_e2c3d9a2953f16ffd8dd788e821dae0a);


        marker_14e9395014aac2c7ee04e54d90dbfa0d.bindPopup(popup_cc3b2598338640a2d6de7849e4beb5fb)
        ;




            var heat_map_abafd49bbca6969f79ba34dcd42cde87 = L.heatLayer(
                [[43.66672554, -79.44642226, 13.0], [43.63294904, -79.43438482, 14.0], [43.65227394, -79.40110737, 12.0], [43.74848196, -79.55006743, 4.0], [43.65571598, -79.38372586, 23.0], [43.70321193, -79.34658826, 5.0], [43.7870825, -79.32992957, 1.0], [43.72091645, -79.50859475, 19.0], [43.69425151, -79.55861018, 7.0], [43.72577689, -79.27383346, 5.0], [43.70917038, -79.40102123, 4.0], [43.69625936, -79.44764573, 5.0], [43.77099307, -79.41327513, 22.0], [43.8225461, -79.27141938, 8.0], [43.68475127, -79.31005511, 7.0], [43.67363686, -79.42340096, 7.0], [43.64926232, -79.37410556, 45.0], [43.64509634, -79.57350939, 1.0], [43.75937098, -79.33874208, 5.0], [43.68889241, -79.5039677, 3.0], [43.66874022, -79.45797855, 12.0], [43.64881159, -79.38888568, 36.0], [43.66716143, -79.40149998, 11.0], [43.67967885, -79.34511536, 10.0], [43.71204501, -79.28096318, 11.0], [43.66228154, -79.34055684, 11.0], [43.64944981, -79.37142509, 24.0], [43.64204126, -79.41193075, 12.0], [43.76842365, -79.26876189, 6.0], [43.81421617, -79.23709431, 7.0], [43.64220797, -79.42860473, 9.0], [43.67007127, -79.29978601, 10.0], [43.7319067, -79.59600355, 25.0], [43.64788722, -79.52685653, 14.0], [43.76525072, -79.50372563, 12.0], [43.76834039, -79.37043936, 5.0], [43.74873834, -79.23556927, 11.0], [43.83402039, -79.22699861, 13.0], [43.69702545, -79.49503182, 7.0], [43.66094505, -79.43038141, 1.0], [43.69437813, -79.30056835, 4.0], [43.66399224, -79.36926698, 11.0], [43.64938527, -79.42274326, 6.0], [43.78420347, -79.39961562, 5.0], [43.68712374, -79.36076592, 4.0], [43.70321772, -79.27947672, 9.0], [43.67201015, -79.44557624, 3.0], [43.61649591, -79.5210248, 13.0], [43.77214083, -79.25145731, 23.0], [43.72351294, -79.45978516, 8.0], [43.78469811, -79.17484165, 2.0], [0.0, 0.0, 9.0], [43.76758275, -79.18323393, 15.0], [43.65680676, -79.36252926, 10.0], [43.74375996, -79.30216238, 10.0], [43.67866925, -79.346226, 5.0], [43.6728738, -79.38782632, 19.0], [43.7694265, -79.34434334, 7.0], [43.69676539, -79.44527396, 9.0], [43.79206024, -79.25977154, 13.0], [43.64912973, -79.43790302, 8.0], [43.69144722, -79.32062053, 4.0], [43.71492666, -79.33414521, 4.0], [43.74248611, -79.22206817, 4.0], [43.77888161, -79.41953867, 13.0], [43.71107784, -79.39927621, 11.0], [43.67780884, -79.47860613, 7.0], [43.63933996, -79.45127101, 9.0], [43.67051816, -79.31158524, 6.0], [43.70060252, -79.51775154, 8.0], [43.76882728, -79.52036423, 12.0], [43.72998475, -79.26699358, 6.0], [43.67862763, -79.32787432, 5.0], [0.0, 0.0, 12.0], [43.78959109, -79.44983192, 2.0], [43.6880498, -79.47154503, 5.0], [43.75001169, -79.45390923, 9.0], [43.63920551, -79.58433063, 2.0], [43.75258277, -79.28319326, 7.0], [43.71427823, -79.3059261, 9.0], [43.71178861, -79.37853604, 5.0], [43.66428681, -79.50215597, 5.0], [43.73640808, -79.3818677, 9.0], [43.60750763, -79.52985168, 4.0], [43.60326759, -79.50627079, 4.0], [43.69432519, -79.41498645, 4.0], [43.72935527, -79.32835907, 2.0], [43.7441499, -79.40668473, 2.0], [43.65633298, -79.46818422, 4.0], [43.67235839, -79.37681431, 4.0], [43.72798391, -79.22908163, 6.0], [43.7366874, -79.5088181, 5.0], [43.76262335, -79.56438518, 8.0], [43.71545763, -79.50718536, 4.0], [43.62229718, -79.50590083, 12.0], [43.70151038, -79.25289415, 9.0], [43.75545869, -79.43844041, 2.0], [43.71780474, -79.40349687, 3.0], [43.66542584, -79.46585038, 4.0], [43.71510482, -79.55507738, 3.0], [43.77908536, -79.34869595, 7.0], [43.72003382, -79.42993872, 8.0], [43.7727692, -79.44063916, 5.0], [43.79031287, -79.19793737, 1.0], [43.8164915, -79.33141941, 7.0], [43.78714471, -79.15225673, 4.0], [43.6897005, -79.39744799, 6.0], [43.6799437, -79.40611935, 2.0], [43.80263794, -79.35242116, 2.0], [43.66465652, -79.40270156, 5.0], [43.73114796, -79.40750317, 5.0], [43.76053065, -79.4231866, 6.0], [43.74326507, -79.58207638, 10.0], [43.77797984, -79.31116492, 11.0], [43.71806233, -79.55384096, 5.0], [43.70628591, -79.37403755, 6.0], [43.79500447, -79.32961357, 2.0], [43.71574209, -79.5047176, 2.0], [43.67779387, -79.35070987, 1.0], [43.68445552, -79.42140231, 2.0], [43.74171555, -79.57377923, 3.0], [43.6761888, -79.33746603, 2.0], [43.66198485, -79.42562006, 2.0], [43.64207956, -79.58609531, 2.0], [43.73027846, -79.43819728, 3.0], [43.69876975, -79.43597803, 1.0], [43.66561293, -79.48477942, 1.0], [43.67633938, -79.57037025, 1.0], [43.808508, -79.3724657, 1.0], [43.79922772, -79.28219213, 1.0], [43.69214748, -79.30477556, 1.0], [43.59415756, -79.52254725, 1.0]],
                {&quot;blur&quot;: 20, &quot;maxZoom&quot;: 15, &quot;minOpacity&quot;: 0.2, &quot;radius&quot;: 30}
            ).addTo(map_f8e9f8c831a93fb452c7426f10c07a3b);

&lt;/script&gt;
&lt;/html&gt;" style="position:absolute;width:100%;height:100%;left:0;top:0;border:none !important;" allowfullscreen webkitallowfullscreen mozallowfullscreen></iframe></div></div>



**Results**

> The heatmap is color-coded, with darker shades of red indicating higher crime density and lighter shades indicating lower crime density. The color scheme ranges from blue (lowest density) to red (highest density). The heatmap is interactive, allowing users to zoom in and out, and pan across the map to explore different areas of Toronto.
>
>The heatmap also includes clusters of markers that show the location of each neighborhood on the map. The clusters are color-coded based on the number of neighborhoods in each cluster, with larger clusters indicating more densely populated areas of the city. The markers provide additional information about each neighborhood, such as the name and location.
>
>The heatmap provides a visual representation of the distribution of criminal activities in Toronto and can be used to identify areas that may require increased policing or other interventions to address crime.
>
> The neighbourhood in red area is *Church-Yonge Corridor*. To confirm it, I have calculated the central tendency.



**Adding central tendency**
> To find the central tendency, mode has to be calculated (i.e., the most frequently occurring value) of the 'Neighbourhood' column in the 'crime_data' dataset.
>
> The marker is used to visually display the central tendency information on the map. 


```python
# Calculating mode value for neighbourhood column
central_tendency = crime_data['Neighbourhood'].mode()[0]

# Add popup with central tendency information
popup_text = "Central tendency based on neighbourhood: " + central_tendency
folium.Marker([43.7, -79.4], popup=popup_text).add_to(heat_map)

# Show the map to see the heat map with the central tendency
heat_map
```




<div style="width:100%;"><div style="position:relative;width:100%;height:0;padding-bottom:60%;"><span style="color:#565656">Make this Notebook Trusted to load map: File -> Trust Notebook</span><iframe srcdoc="&lt;!DOCTYPE html&gt;
&lt;html&gt;
&lt;head&gt;

    &lt;meta http-equiv=&quot;content-type&quot; content=&quot;text/html; charset=UTF-8&quot; /&gt;

        &lt;script&gt;
            L_NO_TOUCH = false;
            L_DISABLE_3D = false;
        &lt;/script&gt;

    &lt;style&gt;html, body {width: 100%;height: 100%;margin: 0;padding: 0;}&lt;/style&gt;
    &lt;style&gt;#map {position:absolute;top:0;bottom:0;right:0;left:0;}&lt;/style&gt;
    &lt;script src=&quot;https://cdn.jsdelivr.net/npm/leaflet@1.6.0/dist/leaflet.js&quot;&gt;&lt;/script&gt;
    &lt;script src=&quot;https://code.jquery.com/jquery-1.12.4.min.js&quot;&gt;&lt;/script&gt;
    &lt;script src=&quot;https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js&quot;&gt;&lt;/script&gt;
    &lt;script src=&quot;https://cdnjs.cloudflare.com/ajax/libs/Leaflet.awesome-markers/2.0.2/leaflet.awesome-markers.js&quot;&gt;&lt;/script&gt;
    &lt;link rel=&quot;stylesheet&quot; href=&quot;https://cdn.jsdelivr.net/npm/leaflet@1.6.0/dist/leaflet.css&quot;/&gt;
    &lt;link rel=&quot;stylesheet&quot; href=&quot;https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css&quot;/&gt;
    &lt;link rel=&quot;stylesheet&quot; href=&quot;https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap-theme.min.css&quot;/&gt;
    &lt;link rel=&quot;stylesheet&quot; href=&quot;https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css&quot;/&gt;
    &lt;link rel=&quot;stylesheet&quot; href=&quot;https://cdnjs.cloudflare.com/ajax/libs/Leaflet.awesome-markers/2.0.2/leaflet.awesome-markers.css&quot;/&gt;
    &lt;link rel=&quot;stylesheet&quot; href=&quot;https://cdn.jsdelivr.net/gh/python-visualization/folium/folium/templates/leaflet.awesome.rotate.min.css&quot;/&gt;

            &lt;meta name=&quot;viewport&quot; content=&quot;width=device-width,
                initial-scale=1.0, maximum-scale=1.0, user-scalable=no&quot; /&gt;
            &lt;style&gt;
                #map_f8e9f8c831a93fb452c7426f10c07a3b {
                    position: relative;
                    width: 100.0%;
                    height: 100.0%;
                    left: 0.0%;
                    top: 0.0%;
                }
            &lt;/style&gt;

    &lt;script src=&quot;https://cdnjs.cloudflare.com/ajax/libs/leaflet.markercluster/1.1.0/leaflet.markercluster.js&quot;&gt;&lt;/script&gt;
    &lt;link rel=&quot;stylesheet&quot; href=&quot;https://cdnjs.cloudflare.com/ajax/libs/leaflet.markercluster/1.1.0/MarkerCluster.css&quot;/&gt;
    &lt;link rel=&quot;stylesheet&quot; href=&quot;https://cdnjs.cloudflare.com/ajax/libs/leaflet.markercluster/1.1.0/MarkerCluster.Default.css&quot;/&gt;
    &lt;script src=&quot;https://cdn.jsdelivr.net/gh/python-visualization/folium@master/folium/templates/leaflet_heat.min.js&quot;&gt;&lt;/script&gt;
&lt;/head&gt;
&lt;body&gt;


            &lt;div class=&quot;folium-map&quot; id=&quot;map_f8e9f8c831a93fb452c7426f10c07a3b&quot; &gt;&lt;/div&gt;

&lt;/body&gt;
&lt;script&gt;


            var map_f8e9f8c831a93fb452c7426f10c07a3b = L.map(
                &quot;map_f8e9f8c831a93fb452c7426f10c07a3b&quot;,
                {
                    center: [43.70227, -79.366074],
                    crs: L.CRS.EPSG3857,
                    zoom: 11,
                    zoomControl: true,
                    preferCanvas: false,
                }
            );





            var tile_layer_11b1e54f2270b4c109cc31ce6ec6fc2b = L.tileLayer(
                &quot;https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png&quot;,
                {&quot;attribution&quot;: &quot;Data by \u0026copy; \u003ca href=\&quot;http://openstreetmap.org\&quot;\u003eOpenStreetMap\u003c/a\u003e, under \u003ca href=\&quot;http://www.openstreetmap.org/copyright\&quot;\u003eODbL\u003c/a\u003e.&quot;, &quot;detectRetina&quot;: false, &quot;maxNativeZoom&quot;: 18, &quot;maxZoom&quot;: 18, &quot;minZoom&quot;: 0, &quot;noWrap&quot;: false, &quot;opacity&quot;: 1, &quot;subdomains&quot;: &quot;abc&quot;, &quot;tms&quot;: false}
            ).addTo(map_f8e9f8c831a93fb452c7426f10c07a3b);


            var marker_cluster_bee2ede4db751c0f106987df10836fd4 = L.markerClusterGroup(
                {}
            );
            map_f8e9f8c831a93fb452c7426f10c07a3b.addLayer(marker_cluster_bee2ede4db751c0f106987df10836fd4);


            var marker_5de3173c5aad0341a6861bf3c1f8e53f = L.marker(
                [43.66672554, -79.44642226],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_b732fbf9ea90483e254c47f8f3974e88 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_b483a0a219af31808bdb376cf4164513 = $(`&lt;div id=&quot;html_b483a0a219af31808bdb376cf4164513&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Dovercourt-Wallace Emerson-Junction&lt;/div&gt;`)[0];
            popup_b732fbf9ea90483e254c47f8f3974e88.setContent(html_b483a0a219af31808bdb376cf4164513);


        marker_5de3173c5aad0341a6861bf3c1f8e53f.bindPopup(popup_b732fbf9ea90483e254c47f8f3974e88)
        ;




            var marker_2c5bd8711350555f5245b442bf0ec4d0 = L.marker(
                [43.63294904, -79.43438482],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_b10d61d3f20385a09a058e42e9ec9b98 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_55153e391f1dbe01bc99e8b81fa24fa9 = $(`&lt;div id=&quot;html_55153e391f1dbe01bc99e8b81fa24fa9&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;South Parkdale&lt;/div&gt;`)[0];
            popup_b10d61d3f20385a09a058e42e9ec9b98.setContent(html_55153e391f1dbe01bc99e8b81fa24fa9);


        marker_2c5bd8711350555f5245b442bf0ec4d0.bindPopup(popup_b10d61d3f20385a09a058e42e9ec9b98)
        ;




            var marker_ca9aaaaa6ec2bfc046ccaf20cc213aeb = L.marker(
                [43.65227394, -79.40110737],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_90b9dd6b744fc28ca4f3ebde9d3f2b49 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_7cc8a61eafa0d665c9b5dfb28887d103 = $(`&lt;div id=&quot;html_7cc8a61eafa0d665c9b5dfb28887d103&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Kensington-Chinatown&lt;/div&gt;`)[0];
            popup_90b9dd6b744fc28ca4f3ebde9d3f2b49.setContent(html_7cc8a61eafa0d665c9b5dfb28887d103);


        marker_ca9aaaaa6ec2bfc046ccaf20cc213aeb.bindPopup(popup_90b9dd6b744fc28ca4f3ebde9d3f2b49)
        ;




            var marker_61f61b66e1292db75aad1ea7069a11f7 = L.marker(
                [43.74848196, -79.55006743],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_bb7f996a498967f36bad22f30096934f = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_4e841a146cc2b2f7388b367cc913e72c = $(`&lt;div id=&quot;html_4e841a146cc2b2f7388b367cc913e72c&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Humbermede&lt;/div&gt;`)[0];
            popup_bb7f996a498967f36bad22f30096934f.setContent(html_4e841a146cc2b2f7388b367cc913e72c);


        marker_61f61b66e1292db75aad1ea7069a11f7.bindPopup(popup_bb7f996a498967f36bad22f30096934f)
        ;




            var marker_2a5d084aeab4d2954ce3e901aba42f43 = L.marker(
                [43.65571598, -79.38372586],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_f5e8e98e75b7f8a8f8e20c947f883874 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_7c36abf1a00c6cfae014da6098e2b32a = $(`&lt;div id=&quot;html_7c36abf1a00c6cfae014da6098e2b32a&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Bay Street Corridor&lt;/div&gt;`)[0];
            popup_f5e8e98e75b7f8a8f8e20c947f883874.setContent(html_7c36abf1a00c6cfae014da6098e2b32a);


        marker_2a5d084aeab4d2954ce3e901aba42f43.bindPopup(popup_f5e8e98e75b7f8a8f8e20c947f883874)
        ;




            var marker_f29197aeb5b20c0de1eae3c38ced27b9 = L.marker(
                [43.70321193, -79.34658826],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_aa0137b372dc6459b8980973b6e36618 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_ba379d150dce7eb2cbb87516e77f7955 = $(`&lt;div id=&quot;html_ba379d150dce7eb2cbb87516e77f7955&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Thorncliffe Park&lt;/div&gt;`)[0];
            popup_aa0137b372dc6459b8980973b6e36618.setContent(html_ba379d150dce7eb2cbb87516e77f7955);


        marker_f29197aeb5b20c0de1eae3c38ced27b9.bindPopup(popup_aa0137b372dc6459b8980973b6e36618)
        ;




            var marker_5a74dfd61ab9c1b5a256cf929e2d5b79 = L.marker(
                [43.7870825, -79.32992957],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_bf1387649d72f730299b7a3386c18983 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_998e7b91472642de2fbceef9df9850c0 = $(`&lt;div id=&quot;html_998e7b91472642de2fbceef9df9850c0&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Pleasant View&lt;/div&gt;`)[0];
            popup_bf1387649d72f730299b7a3386c18983.setContent(html_998e7b91472642de2fbceef9df9850c0);


        marker_5a74dfd61ab9c1b5a256cf929e2d5b79.bindPopup(popup_bf1387649d72f730299b7a3386c18983)
        ;




            var marker_cb5c9112a74547b462da53929fa99a97 = L.marker(
                [43.72091645, -79.50859475],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_c56deaf51d1ed389f51a9f5f69921b50 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_52c428eaf7400440c378fd423105a407 = $(`&lt;div id=&quot;html_52c428eaf7400440c378fd423105a407&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Downsview-Roding-CFB&lt;/div&gt;`)[0];
            popup_c56deaf51d1ed389f51a9f5f69921b50.setContent(html_52c428eaf7400440c378fd423105a407);


        marker_cb5c9112a74547b462da53929fa99a97.bindPopup(popup_c56deaf51d1ed389f51a9f5f69921b50)
        ;




            var marker_25f8bb4eef610e502cd902efdbeedf16 = L.marker(
                [43.69425151, -79.55861018],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_b00124e8d93a9d9a1e617217d852653c = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_7369e4a25b69b5349b69d5a42bac1172 = $(`&lt;div id=&quot;html_7369e4a25b69b5349b69d5a42bac1172&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Kingsview Village-The Westway&lt;/div&gt;`)[0];
            popup_b00124e8d93a9d9a1e617217d852653c.setContent(html_7369e4a25b69b5349b69d5a42bac1172);


        marker_25f8bb4eef610e502cd902efdbeedf16.bindPopup(popup_b00124e8d93a9d9a1e617217d852653c)
        ;




            var marker_934dac2d3ec95537990d752c5aed8446 = L.marker(
                [43.72577689, -79.27383346],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_862d5e62f2911b82cbf044090e145b26 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_6d6be59da9aaf095bd834215f2996243 = $(`&lt;div id=&quot;html_6d6be59da9aaf095bd834215f2996243&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Ionview&lt;/div&gt;`)[0];
            popup_862d5e62f2911b82cbf044090e145b26.setContent(html_6d6be59da9aaf095bd834215f2996243);


        marker_934dac2d3ec95537990d752c5aed8446.bindPopup(popup_862d5e62f2911b82cbf044090e145b26)
        ;




            var marker_021b199cc604faf1cc109d27f0df4398 = L.marker(
                [43.70917038, -79.40102123],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_4e415ccf75e369ebe51989c3ea7b26f2 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_f7d5d2eb5bfd7410a37e609c052c90e4 = $(`&lt;div id=&quot;html_f7d5d2eb5bfd7410a37e609c052c90e4&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Yonge-Eglinton&lt;/div&gt;`)[0];
            popup_4e415ccf75e369ebe51989c3ea7b26f2.setContent(html_f7d5d2eb5bfd7410a37e609c052c90e4);


        marker_021b199cc604faf1cc109d27f0df4398.bindPopup(popup_4e415ccf75e369ebe51989c3ea7b26f2)
        ;




            var marker_44a89a71783c0dc2087cff47dfe0e4d4 = L.marker(
                [43.69625936, -79.44764573],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_300c6f9214427d52a0fa257b87be3060 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_876442b2216b06e91c8c892f2a88c7ea = $(`&lt;div id=&quot;html_876442b2216b06e91c8c892f2a88c7ea&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Oakwood Village&lt;/div&gt;`)[0];
            popup_300c6f9214427d52a0fa257b87be3060.setContent(html_876442b2216b06e91c8c892f2a88c7ea);


        marker_44a89a71783c0dc2087cff47dfe0e4d4.bindPopup(popup_300c6f9214427d52a0fa257b87be3060)
        ;




            var marker_67347af44be9a4af290e8d8549c0525a = L.marker(
                [43.77099307, -79.41327513],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_31dc2d579740bda3ad84a54a020a7a36 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_54911a28da1599c505ad2cd57c9a0dd8 = $(`&lt;div id=&quot;html_54911a28da1599c505ad2cd57c9a0dd8&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Willowdale East&lt;/div&gt;`)[0];
            popup_31dc2d579740bda3ad84a54a020a7a36.setContent(html_54911a28da1599c505ad2cd57c9a0dd8);


        marker_67347af44be9a4af290e8d8549c0525a.bindPopup(popup_31dc2d579740bda3ad84a54a020a7a36)
        ;




            var marker_db069fb00832ea35b102e942f1207b46 = L.marker(
                [43.8225461, -79.27141938],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_0562724ab89fe0348dc09eb81d27bdc8 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_db3385f3db116d86dd1c2ab998922141 = $(`&lt;div id=&quot;html_db3385f3db116d86dd1c2ab998922141&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Milliken&lt;/div&gt;`)[0];
            popup_0562724ab89fe0348dc09eb81d27bdc8.setContent(html_db3385f3db116d86dd1c2ab998922141);


        marker_db069fb00832ea35b102e942f1207b46.bindPopup(popup_0562724ab89fe0348dc09eb81d27bdc8)
        ;




            var marker_59a2881dfa05285a1be84ae28f180cf1 = L.marker(
                [43.68475127, -79.31005511],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_b21a267ddd70584ce374feffbd509dfe = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_21b635e16b8b8fadb9617d4f45ba3b8f = $(`&lt;div id=&quot;html_21b635e16b8b8fadb9617d4f45ba3b8f&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;East End-Danforth&lt;/div&gt;`)[0];
            popup_b21a267ddd70584ce374feffbd509dfe.setContent(html_21b635e16b8b8fadb9617d4f45ba3b8f);


        marker_59a2881dfa05285a1be84ae28f180cf1.bindPopup(popup_b21a267ddd70584ce374feffbd509dfe)
        ;




            var marker_15435b18801ef1ed7cb27f8bffa25b2f = L.marker(
                [43.67363686, -79.42340096],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_a0f075fff70a3d8d49267a51c6bc0c8c = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_6d52586ec54dc569f54648ed826be3cb = $(`&lt;div id=&quot;html_6d52586ec54dc569f54648ed826be3cb&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Wychwood&lt;/div&gt;`)[0];
            popup_a0f075fff70a3d8d49267a51c6bc0c8c.setContent(html_6d52586ec54dc569f54648ed826be3cb);


        marker_15435b18801ef1ed7cb27f8bffa25b2f.bindPopup(popup_a0f075fff70a3d8d49267a51c6bc0c8c)
        ;




            var marker_7b1c3632cf6f80d20d4b67665176a044 = L.marker(
                [43.64926232, -79.37410556],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_1eb78f31e2b4dcc263ed6fbd08f959b0 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_c6bdfee1c672cc17afd28e003e992018 = $(`&lt;div id=&quot;html_c6bdfee1c672cc17afd28e003e992018&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Church-Yonge Corridor&lt;/div&gt;`)[0];
            popup_1eb78f31e2b4dcc263ed6fbd08f959b0.setContent(html_c6bdfee1c672cc17afd28e003e992018);


        marker_7b1c3632cf6f80d20d4b67665176a044.bindPopup(popup_1eb78f31e2b4dcc263ed6fbd08f959b0)
        ;




            var marker_e6001d612cabbec7d3d5a93300fb5880 = L.marker(
                [43.64509634, -79.57350939],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_a668f8f26e9b5e6acf196462be22dba1 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_8de4f6c8989f7dae1e8e3a79b73c8aae = $(`&lt;div id=&quot;html_8de4f6c8989f7dae1e8e3a79b73c8aae&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Etobicoke West Mall&lt;/div&gt;`)[0];
            popup_a668f8f26e9b5e6acf196462be22dba1.setContent(html_8de4f6c8989f7dae1e8e3a79b73c8aae);


        marker_e6001d612cabbec7d3d5a93300fb5880.bindPopup(popup_a668f8f26e9b5e6acf196462be22dba1)
        ;




            var marker_b97e00725c97a5973bd018a197e90726 = L.marker(
                [43.75937098, -79.33874208],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_28ebdb8e0356fffbe0a2577b45f16ad9 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_c1592a5282abbebbd107eb5b1a75ed4a = $(`&lt;div id=&quot;html_c1592a5282abbebbd107eb5b1a75ed4a&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Parkwoods-Donalda&lt;/div&gt;`)[0];
            popup_28ebdb8e0356fffbe0a2577b45f16ad9.setContent(html_c1592a5282abbebbd107eb5b1a75ed4a);


        marker_b97e00725c97a5973bd018a197e90726.bindPopup(popup_28ebdb8e0356fffbe0a2577b45f16ad9)
        ;




            var marker_422b52218a9b4a577ba2965386ca97c9 = L.marker(
                [43.68889241, -79.5039677],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_f043ab989e3b19b5029f7493532e148c = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_67538d64bfdfbd3d5596e6684427b7a0 = $(`&lt;div id=&quot;html_67538d64bfdfbd3d5596e6684427b7a0&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Mount Dennis&lt;/div&gt;`)[0];
            popup_f043ab989e3b19b5029f7493532e148c.setContent(html_67538d64bfdfbd3d5596e6684427b7a0);


        marker_422b52218a9b4a577ba2965386ca97c9.bindPopup(popup_f043ab989e3b19b5029f7493532e148c)
        ;




            var marker_16a5d702f2457e790f5d87b3ababdd85 = L.marker(
                [43.66874022, -79.45797855],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_93350cc4870f6c4d72d79ccb258f5475 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_da67430da716d663d45e1b46520712a4 = $(`&lt;div id=&quot;html_da67430da716d663d45e1b46520712a4&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Weston-Pellam Park&lt;/div&gt;`)[0];
            popup_93350cc4870f6c4d72d79ccb258f5475.setContent(html_da67430da716d663d45e1b46520712a4);


        marker_16a5d702f2457e790f5d87b3ababdd85.bindPopup(popup_93350cc4870f6c4d72d79ccb258f5475)
        ;




            var marker_d78e2aa5b0ae15449242e4caab2cb273 = L.marker(
                [43.64881159, -79.38888568],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_3c846c16753c88e43f83e649dfc8e91d = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_1ab5762cc0e93fc14c2236861aa66b3d = $(`&lt;div id=&quot;html_1ab5762cc0e93fc14c2236861aa66b3d&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Waterfront Communities-The Island&lt;/div&gt;`)[0];
            popup_3c846c16753c88e43f83e649dfc8e91d.setContent(html_1ab5762cc0e93fc14c2236861aa66b3d);


        marker_d78e2aa5b0ae15449242e4caab2cb273.bindPopup(popup_3c846c16753c88e43f83e649dfc8e91d)
        ;




            var marker_678fa50d0a15e6cf5ebf6a06e486d6af = L.marker(
                [43.66716143, -79.40149998],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_9c06b51fea232e1e91b9424d2553bc7f = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_64d02f9ecddf7043c4e1a45286d76224 = $(`&lt;div id=&quot;html_64d02f9ecddf7043c4e1a45286d76224&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Annex&lt;/div&gt;`)[0];
            popup_9c06b51fea232e1e91b9424d2553bc7f.setContent(html_64d02f9ecddf7043c4e1a45286d76224);


        marker_678fa50d0a15e6cf5ebf6a06e486d6af.bindPopup(popup_9c06b51fea232e1e91b9424d2553bc7f)
        ;




            var marker_6e07786710e8615b855cfca83ca91a76 = L.marker(
                [43.67967885, -79.34511536],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_805ef5aac57b3d156c295aefe1f4fa96 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_584167999ee5e549629a4a1b4e5cfd86 = $(`&lt;div id=&quot;html_584167999ee5e549629a4a1b4e5cfd86&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Danforth&lt;/div&gt;`)[0];
            popup_805ef5aac57b3d156c295aefe1f4fa96.setContent(html_584167999ee5e549629a4a1b4e5cfd86);


        marker_6e07786710e8615b855cfca83ca91a76.bindPopup(popup_805ef5aac57b3d156c295aefe1f4fa96)
        ;




            var marker_72e7ea417a3d6985104aa2915f56d4ab = L.marker(
                [43.71204501, -79.28096318],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_7be7a4385f86c07e993d50595ea90ef0 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_7c5a81d3eae6644c626baddb2ec4c3af = $(`&lt;div id=&quot;html_7c5a81d3eae6644c626baddb2ec4c3af&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Clairlea-Birchmount&lt;/div&gt;`)[0];
            popup_7be7a4385f86c07e993d50595ea90ef0.setContent(html_7c5a81d3eae6644c626baddb2ec4c3af);


        marker_72e7ea417a3d6985104aa2915f56d4ab.bindPopup(popup_7be7a4385f86c07e993d50595ea90ef0)
        ;




            var marker_354f1a0492724ba6d5bd491a5e3a0b37 = L.marker(
                [43.66228154, -79.34055684],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_ccaced00c9d60ba5c714f2eb64981189 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_58cb396cb99ea0aced3a2d0eb42a2b35 = $(`&lt;div id=&quot;html_58cb396cb99ea0aced3a2d0eb42a2b35&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;South Riverdale&lt;/div&gt;`)[0];
            popup_ccaced00c9d60ba5c714f2eb64981189.setContent(html_58cb396cb99ea0aced3a2d0eb42a2b35);


        marker_354f1a0492724ba6d5bd491a5e3a0b37.bindPopup(popup_ccaced00c9d60ba5c714f2eb64981189)
        ;




            var marker_9bff86f39b5164e9d6f3241d99c0e12d = L.marker(
                [43.64944981, -79.37142509],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_ef7ac1cb6450a656f907d5f74ef7f355 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_6bfc53cdd1f76afed325a27633c874ab = $(`&lt;div id=&quot;html_6bfc53cdd1f76afed325a27633c874ab&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Moss Park&lt;/div&gt;`)[0];
            popup_ef7ac1cb6450a656f907d5f74ef7f355.setContent(html_6bfc53cdd1f76afed325a27633c874ab);


        marker_9bff86f39b5164e9d6f3241d99c0e12d.bindPopup(popup_ef7ac1cb6450a656f907d5f74ef7f355)
        ;




            var marker_2e065f1517c7576f0e342ace5ddf1119 = L.marker(
                [43.64204126, -79.41193075],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_e2d6ab783824238876d96f1713786327 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_786b237c5e51b2f7bb01d01813084b3a = $(`&lt;div id=&quot;html_786b237c5e51b2f7bb01d01813084b3a&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Niagara&lt;/div&gt;`)[0];
            popup_e2d6ab783824238876d96f1713786327.setContent(html_786b237c5e51b2f7bb01d01813084b3a);


        marker_2e065f1517c7576f0e342ace5ddf1119.bindPopup(popup_e2d6ab783824238876d96f1713786327)
        ;




            var marker_22182d5cf7edba836dbe910736b04eae = L.marker(
                [43.76842365, -79.26876189],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_e5ad028af1e48f110ed5104bc0d071c8 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_d59d3cee5e53a7cf869148a6f63a7987 = $(`&lt;div id=&quot;html_d59d3cee5e53a7cf869148a6f63a7987&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Bendale&lt;/div&gt;`)[0];
            popup_e5ad028af1e48f110ed5104bc0d071c8.setContent(html_d59d3cee5e53a7cf869148a6f63a7987);


        marker_22182d5cf7edba836dbe910736b04eae.bindPopup(popup_e5ad028af1e48f110ed5104bc0d071c8)
        ;




            var marker_5356fcd3689f106a324611bf5a6f35f8 = L.marker(
                [43.81421617, -79.23709431],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_78997cc73e3f5b7f77941e2aaff0d560 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_a0aade197a0d233bca0d97711d5d8843 = $(`&lt;div id=&quot;html_a0aade197a0d233bca0d97711d5d8843&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Malvern&lt;/div&gt;`)[0];
            popup_78997cc73e3f5b7f77941e2aaff0d560.setContent(html_a0aade197a0d233bca0d97711d5d8843);


        marker_5356fcd3689f106a324611bf5a6f35f8.bindPopup(popup_78997cc73e3f5b7f77941e2aaff0d560)
        ;




            var marker_4ddedc2c278437c0b3c524a71fdf4135 = L.marker(
                [43.64220797, -79.42860473],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_5cb5c11bd7e29202a9cb1ec2689b71b9 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_8f3375c8cf21b3b2cdbdfcdc4d30b80d = $(`&lt;div id=&quot;html_8f3375c8cf21b3b2cdbdfcdc4d30b80d&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Roncesvalles&lt;/div&gt;`)[0];
            popup_5cb5c11bd7e29202a9cb1ec2689b71b9.setContent(html_8f3375c8cf21b3b2cdbdfcdc4d30b80d);


        marker_4ddedc2c278437c0b3c524a71fdf4135.bindPopup(popup_5cb5c11bd7e29202a9cb1ec2689b71b9)
        ;




            var marker_cfac55c10106b2fb30011eb255e860f6 = L.marker(
                [43.67007127, -79.29978601],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_f53f335faac4c9971f4759c05fe2f5fe = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_750ba050b3ebb69302c88c12830fd392 = $(`&lt;div id=&quot;html_750ba050b3ebb69302c88c12830fd392&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;The Beaches&lt;/div&gt;`)[0];
            popup_f53f335faac4c9971f4759c05fe2f5fe.setContent(html_750ba050b3ebb69302c88c12830fd392);


        marker_cfac55c10106b2fb30011eb255e860f6.bindPopup(popup_f53f335faac4c9971f4759c05fe2f5fe)
        ;




            var marker_a6876b21fbba271bcc74c59a877a3047 = L.marker(
                [43.7319067, -79.59600355],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_1a5f51abbb97151dc7bba034b6285d15 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_fe8ce268bffa49c8699981bb5f36fff2 = $(`&lt;div id=&quot;html_fe8ce268bffa49c8699981bb5f36fff2&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;West Humber-Clairville&lt;/div&gt;`)[0];
            popup_1a5f51abbb97151dc7bba034b6285d15.setContent(html_fe8ce268bffa49c8699981bb5f36fff2);


        marker_a6876b21fbba271bcc74c59a877a3047.bindPopup(popup_1a5f51abbb97151dc7bba034b6285d15)
        ;




            var marker_1a58545ecb7d3199b83228f9029dd187 = L.marker(
                [43.64788722, -79.52685653],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_a8055eea04b2c3b5297d288d6f1feadd = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_c960922ec1f3c413b3b8acd9104e3e4d = $(`&lt;div id=&quot;html_c960922ec1f3c413b3b8acd9104e3e4d&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Islington-City Centre West&lt;/div&gt;`)[0];
            popup_a8055eea04b2c3b5297d288d6f1feadd.setContent(html_c960922ec1f3c413b3b8acd9104e3e4d);


        marker_1a58545ecb7d3199b83228f9029dd187.bindPopup(popup_a8055eea04b2c3b5297d288d6f1feadd)
        ;




            var marker_79607cc1a6867c24d782c46839efcb53 = L.marker(
                [43.76525072, -79.50372563],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_d10f142897924dbf96ab0c9861247d15 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_d61ed32d7ce32464d064e6f7bdd8932b = $(`&lt;div id=&quot;html_d61ed32d7ce32464d064e6f7bdd8932b&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;York University Heights&lt;/div&gt;`)[0];
            popup_d10f142897924dbf96ab0c9861247d15.setContent(html_d61ed32d7ce32464d064e6f7bdd8932b);


        marker_79607cc1a6867c24d782c46839efcb53.bindPopup(popup_d10f142897924dbf96ab0c9861247d15)
        ;




            var marker_2c3662f916a25afa5a783ed125e633e9 = L.marker(
                [43.76834039, -79.37043936],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_9c9b74ec8e706a83d8054f8862a9b9b5 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_a699e7602dc60f04937406e502286451 = $(`&lt;div id=&quot;html_a699e7602dc60f04937406e502286451&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Bayview Village&lt;/div&gt;`)[0];
            popup_9c9b74ec8e706a83d8054f8862a9b9b5.setContent(html_a699e7602dc60f04937406e502286451);


        marker_2c3662f916a25afa5a783ed125e633e9.bindPopup(popup_9c9b74ec8e706a83d8054f8862a9b9b5)
        ;




            var marker_123bcb2613d2d5d0a06fef49eded1df7 = L.marker(
                [43.74873834, -79.23556927],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_bdd4e5ccb5b219ab1981f5e4e2cf5adb = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_748de048c73e1f3b8525b5f143227f20 = $(`&lt;div id=&quot;html_748de048c73e1f3b8525b5f143227f20&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Eglinton East&lt;/div&gt;`)[0];
            popup_bdd4e5ccb5b219ab1981f5e4e2cf5adb.setContent(html_748de048c73e1f3b8525b5f143227f20);


        marker_123bcb2613d2d5d0a06fef49eded1df7.bindPopup(popup_bdd4e5ccb5b219ab1981f5e4e2cf5adb)
        ;




            var marker_82fcfb5d423bf567c2441698f8cc6195 = L.marker(
                [43.83402039, -79.22699861],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_cec9ab1ef9a86290bb8ef9923dee587c = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_f9a232e65a96421e51e9dcf435a6af5b = $(`&lt;div id=&quot;html_f9a232e65a96421e51e9dcf435a6af5b&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Rouge&lt;/div&gt;`)[0];
            popup_cec9ab1ef9a86290bb8ef9923dee587c.setContent(html_f9a232e65a96421e51e9dcf435a6af5b);


        marker_82fcfb5d423bf567c2441698f8cc6195.bindPopup(popup_cec9ab1ef9a86290bb8ef9923dee587c)
        ;




            var marker_13545a857286b586b4afc8a209c821cf = L.marker(
                [43.69702545, -79.49503182],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_eb65d04495ffbe3a867e9529a5fd97bd = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_a5a89c07625c5b1e8f3c1e6198318350 = $(`&lt;div id=&quot;html_a5a89c07625c5b1e8f3c1e6198318350&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Brookhaven-Amesbury&lt;/div&gt;`)[0];
            popup_eb65d04495ffbe3a867e9529a5fd97bd.setContent(html_a5a89c07625c5b1e8f3c1e6198318350);


        marker_13545a857286b586b4afc8a209c821cf.bindPopup(popup_eb65d04495ffbe3a867e9529a5fd97bd)
        ;




            var marker_50f4d3ac1c3fb9582a49448df8b41b36 = L.marker(
                [43.66094505, -79.43038141],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_c5977c133dbfb0fd7f85972f325105d8 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_3887261a91adb71a57b55553db6bbe09 = $(`&lt;div id=&quot;html_3887261a91adb71a57b55553db6bbe09&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Dufferin Grove&lt;/div&gt;`)[0];
            popup_c5977c133dbfb0fd7f85972f325105d8.setContent(html_3887261a91adb71a57b55553db6bbe09);


        marker_50f4d3ac1c3fb9582a49448df8b41b36.bindPopup(popup_c5977c133dbfb0fd7f85972f325105d8)
        ;




            var marker_43a53f25aa1fdacb4fa54e15b07831fe = L.marker(
                [43.69437813, -79.30056835],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_063a7f8e8f52d1c0b4c48eb7e77f2104 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_f36fb5b30ffd6d92e0bca6cd20ffa170 = $(`&lt;div id=&quot;html_f36fb5b30ffd6d92e0bca6cd20ffa170&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Taylor-Massey&lt;/div&gt;`)[0];
            popup_063a7f8e8f52d1c0b4c48eb7e77f2104.setContent(html_f36fb5b30ffd6d92e0bca6cd20ffa170);


        marker_43a53f25aa1fdacb4fa54e15b07831fe.bindPopup(popup_063a7f8e8f52d1c0b4c48eb7e77f2104)
        ;




            var marker_c798af39e59932a3f61571407d420053 = L.marker(
                [43.66399224, -79.36926698],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_222473cf8a64bdf480920598f859eb3a = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_1acdade94441a9152e2605a1b0939c62 = $(`&lt;div id=&quot;html_1acdade94441a9152e2605a1b0939c62&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Cabbagetown-South St.James Town&lt;/div&gt;`)[0];
            popup_222473cf8a64bdf480920598f859eb3a.setContent(html_1acdade94441a9152e2605a1b0939c62);


        marker_c798af39e59932a3f61571407d420053.bindPopup(popup_222473cf8a64bdf480920598f859eb3a)
        ;




            var marker_5fd1e2d2bfe1c0bd0e414e1c276921a6 = L.marker(
                [43.64938527, -79.42274326],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_83ff935f7fb9054d56d711765b8b4160 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_f8b57fd1807265caff80b0100ab3d5c2 = $(`&lt;div id=&quot;html_f8b57fd1807265caff80b0100ab3d5c2&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Trinity-Bellwoods&lt;/div&gt;`)[0];
            popup_83ff935f7fb9054d56d711765b8b4160.setContent(html_f8b57fd1807265caff80b0100ab3d5c2);


        marker_5fd1e2d2bfe1c0bd0e414e1c276921a6.bindPopup(popup_83ff935f7fb9054d56d711765b8b4160)
        ;




            var marker_ed99789cc6a57ffe66d85fb1f31ef112 = L.marker(
                [43.78420347, -79.39961562],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_a7ed79749e0a166911104c40d9d56521 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_068ebf9d8c869b9d041983b3b7fe08b1 = $(`&lt;div id=&quot;html_068ebf9d8c869b9d041983b3b7fe08b1&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Newtonbrook East&lt;/div&gt;`)[0];
            popup_a7ed79749e0a166911104c40d9d56521.setContent(html_068ebf9d8c869b9d041983b3b7fe08b1);


        marker_ed99789cc6a57ffe66d85fb1f31ef112.bindPopup(popup_a7ed79749e0a166911104c40d9d56521)
        ;




            var marker_7fa3691e7e9b4c560554d4549bf8be4f = L.marker(
                [43.68712374, -79.36076592],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_7ef293d3267c8b326af21df8ad0ec18d = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_9318f36114da45711359e4618d3cb633 = $(`&lt;div id=&quot;html_9318f36114da45711359e4618d3cb633&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Broadview North&lt;/div&gt;`)[0];
            popup_7ef293d3267c8b326af21df8ad0ec18d.setContent(html_9318f36114da45711359e4618d3cb633);


        marker_7fa3691e7e9b4c560554d4549bf8be4f.bindPopup(popup_7ef293d3267c8b326af21df8ad0ec18d)
        ;




            var marker_0160c722a7df0f32fc4c8cabe5518738 = L.marker(
                [43.70321772, -79.27947672],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_cac5c9274048ecb353ba461aea0302c4 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_5feab4f7bdb3881d2d9638a68cb62699 = $(`&lt;div id=&quot;html_5feab4f7bdb3881d2d9638a68cb62699&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Oakridge&lt;/div&gt;`)[0];
            popup_cac5c9274048ecb353ba461aea0302c4.setContent(html_5feab4f7bdb3881d2d9638a68cb62699);


        marker_0160c722a7df0f32fc4c8cabe5518738.bindPopup(popup_cac5c9274048ecb353ba461aea0302c4)
        ;




            var marker_211e9b397ab577deef7898e1fcf06fac = L.marker(
                [43.67201015, -79.44557624],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_768c033fdb938bf21f47573eb0fcdc67 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_821d564778908cb910b95a633e409d26 = $(`&lt;div id=&quot;html_821d564778908cb910b95a633e409d26&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Corso Italia-Davenport&lt;/div&gt;`)[0];
            popup_768c033fdb938bf21f47573eb0fcdc67.setContent(html_821d564778908cb910b95a633e409d26);


        marker_211e9b397ab577deef7898e1fcf06fac.bindPopup(popup_768c033fdb938bf21f47573eb0fcdc67)
        ;




            var marker_721b08d6bac1a4fbded3887c7beaf751 = L.marker(
                [43.61649591, -79.5210248],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_f4c996ca982261350878c8475d43d1b8 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_3afb00182fd312aa10b08903fd3d3ce5 = $(`&lt;div id=&quot;html_3afb00182fd312aa10b08903fd3d3ce5&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Mimico&lt;/div&gt;`)[0];
            popup_f4c996ca982261350878c8475d43d1b8.setContent(html_3afb00182fd312aa10b08903fd3d3ce5);


        marker_721b08d6bac1a4fbded3887c7beaf751.bindPopup(popup_f4c996ca982261350878c8475d43d1b8)
        ;




            var marker_84a40d7bd2dd77e2099db752f2f98a80 = L.marker(
                [43.77214083, -79.25145731],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_da40adf3f3ec78a2c59d01bc10fc18af = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_aae66aff9a8e9706bcf319b005bfffd9 = $(`&lt;div id=&quot;html_aae66aff9a8e9706bcf319b005bfffd9&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Woburn&lt;/div&gt;`)[0];
            popup_da40adf3f3ec78a2c59d01bc10fc18af.setContent(html_aae66aff9a8e9706bcf319b005bfffd9);


        marker_84a40d7bd2dd77e2099db752f2f98a80.bindPopup(popup_da40adf3f3ec78a2c59d01bc10fc18af)
        ;




            var marker_b0f8aef9956ee573789a176d61816d18 = L.marker(
                [43.72351294, -79.45978516],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_7ea17408ca15ec7b9100442e3e6aaedd = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_e1e34c2a795e14aa802ac22642deaa6b = $(`&lt;div id=&quot;html_e1e34c2a795e14aa802ac22642deaa6b&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Yorkdale-Glen Park&lt;/div&gt;`)[0];
            popup_7ea17408ca15ec7b9100442e3e6aaedd.setContent(html_e1e34c2a795e14aa802ac22642deaa6b);


        marker_b0f8aef9956ee573789a176d61816d18.bindPopup(popup_7ea17408ca15ec7b9100442e3e6aaedd)
        ;




            var marker_0a3e90975c1785e6cb86ade4bfab6615 = L.marker(
                [43.78469811, -79.17484165],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_a6e39857b0570685e6d2d788e0ade8eb = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_388b60dd047ffaee7f687d0a2e8947b8 = $(`&lt;div id=&quot;html_388b60dd047ffaee7f687d0a2e8947b8&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Highland Creek&lt;/div&gt;`)[0];
            popup_a6e39857b0570685e6d2d788e0ade8eb.setContent(html_388b60dd047ffaee7f687d0a2e8947b8);


        marker_0a3e90975c1785e6cb86ade4bfab6615.bindPopup(popup_a6e39857b0570685e6d2d788e0ade8eb)
        ;




            var marker_ca7e4770e27d367b3c3b890d686aed2a = L.marker(
                [0.0, 0.0],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_319293ebab226cbd85c6011afdb51db9 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_9e8b1cad47d4a1b0d65645db451c61c5 = $(`&lt;div id=&quot;html_9e8b1cad47d4a1b0d65645db451c61c5&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Victoria Village&lt;/div&gt;`)[0];
            popup_319293ebab226cbd85c6011afdb51db9.setContent(html_9e8b1cad47d4a1b0d65645db451c61c5);


        marker_ca7e4770e27d367b3c3b890d686aed2a.bindPopup(popup_319293ebab226cbd85c6011afdb51db9)
        ;




            var marker_9438668a462e27933e58b201bac94a46 = L.marker(
                [43.76758275, -79.18323393],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_060a4a35cf3745fa5b965f5b764c828f = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_ac91dec4ccb105bf2aec51576340cfa5 = $(`&lt;div id=&quot;html_ac91dec4ccb105bf2aec51576340cfa5&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;West Hill&lt;/div&gt;`)[0];
            popup_060a4a35cf3745fa5b965f5b764c828f.setContent(html_ac91dec4ccb105bf2aec51576340cfa5);


        marker_9438668a462e27933e58b201bac94a46.bindPopup(popup_060a4a35cf3745fa5b965f5b764c828f)
        ;




            var marker_054248051e0bd14bd31916f197b00bff = L.marker(
                [43.65680676, -79.36252926],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_64872e457456f934f0918a8079a30bef = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_f042cb81705de988efbdc38796f07504 = $(`&lt;div id=&quot;html_f042cb81705de988efbdc38796f07504&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Regent Park&lt;/div&gt;`)[0];
            popup_64872e457456f934f0918a8079a30bef.setContent(html_f042cb81705de988efbdc38796f07504);


        marker_054248051e0bd14bd31916f197b00bff.bindPopup(popup_64872e457456f934f0918a8079a30bef)
        ;




            var marker_5cfd8bf7ecd6e0f022d107626cdb4f8c = L.marker(
                [43.74375996, -79.30216238],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_438f22e5d04723374782b0be57ea9683 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_8eb47382de111b58360c2e3e1f31f438 = $(`&lt;div id=&quot;html_8eb47382de111b58360c2e3e1f31f438&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Wexford/Maryvale&lt;/div&gt;`)[0];
            popup_438f22e5d04723374782b0be57ea9683.setContent(html_8eb47382de111b58360c2e3e1f31f438);


        marker_5cfd8bf7ecd6e0f022d107626cdb4f8c.bindPopup(popup_438f22e5d04723374782b0be57ea9683)
        ;




            var marker_097f2abb1404dddb74974843c9e6c5c2 = L.marker(
                [43.67866925, -79.346226],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_6d28db2880b228237e49850586a9543d = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_f02b3a4602a73163913fe2943dd41558 = $(`&lt;div id=&quot;html_f02b3a4602a73163913fe2943dd41558&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Playter Estates-Danforth&lt;/div&gt;`)[0];
            popup_6d28db2880b228237e49850586a9543d.setContent(html_f02b3a4602a73163913fe2943dd41558);


        marker_097f2abb1404dddb74974843c9e6c5c2.bindPopup(popup_6d28db2880b228237e49850586a9543d)
        ;




            var marker_86206eab617d9089b15b03b5cbbe6e1f = L.marker(
                [43.6728738, -79.38782632],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_cff38ccaceedf9be672525d3f51fdc4f = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_58c1b05e5be3b04736408f0326564ed9 = $(`&lt;div id=&quot;html_58c1b05e5be3b04736408f0326564ed9&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Rosedale-Moore Park&lt;/div&gt;`)[0];
            popup_cff38ccaceedf9be672525d3f51fdc4f.setContent(html_58c1b05e5be3b04736408f0326564ed9);


        marker_86206eab617d9089b15b03b5cbbe6e1f.bindPopup(popup_cff38ccaceedf9be672525d3f51fdc4f)
        ;




            var marker_3125fdefb2596ddd1beb916a459c1347 = L.marker(
                [43.7694265, -79.34434334],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_e00fce643f8eb1cc0421d355656e25b3 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_e7f2b5fdffe497d88eed3b89f10d11c6 = $(`&lt;div id=&quot;html_e7f2b5fdffe497d88eed3b89f10d11c6&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Henry Farm&lt;/div&gt;`)[0];
            popup_e00fce643f8eb1cc0421d355656e25b3.setContent(html_e7f2b5fdffe497d88eed3b89f10d11c6);


        marker_3125fdefb2596ddd1beb916a459c1347.bindPopup(popup_e00fce643f8eb1cc0421d355656e25b3)
        ;




            var marker_61c858202bb946b984fa36364700748b = L.marker(
                [43.69676539, -79.44527396],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_98d79655652aed32495a67aa8ca0089d = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_f6272f0d19630f00f8c05bc9b5e08327 = $(`&lt;div id=&quot;html_f6272f0d19630f00f8c05bc9b5e08327&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Briar Hill-Belgravia&lt;/div&gt;`)[0];
            popup_98d79655652aed32495a67aa8ca0089d.setContent(html_f6272f0d19630f00f8c05bc9b5e08327);


        marker_61c858202bb946b984fa36364700748b.bindPopup(popup_98d79655652aed32495a67aa8ca0089d)
        ;




            var marker_9bce5fb03f4b1c9396d67b933f170418 = L.marker(
                [43.79206024, -79.25977154],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_c7ac239ace14725556a424f26c258f64 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_036630085e42e52f63dc82dfe7762381 = $(`&lt;div id=&quot;html_036630085e42e52f63dc82dfe7762381&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Agincourt South-Malvern West&lt;/div&gt;`)[0];
            popup_c7ac239ace14725556a424f26c258f64.setContent(html_036630085e42e52f63dc82dfe7762381);


        marker_9bce5fb03f4b1c9396d67b933f170418.bindPopup(popup_c7ac239ace14725556a424f26c258f64)
        ;




            var marker_7dfe16ff6b0d634b3745f74c6e5059c0 = L.marker(
                [43.64912973, -79.43790302],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_ec09366e0b7b57f3fd9d5478ecce2ee9 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_2171989ec8ab797c37e362584e8d18f1 = $(`&lt;div id=&quot;html_2171989ec8ab797c37e362584e8d18f1&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Little Portugal&lt;/div&gt;`)[0];
            popup_ec09366e0b7b57f3fd9d5478ecce2ee9.setContent(html_2171989ec8ab797c37e362584e8d18f1);


        marker_7dfe16ff6b0d634b3745f74c6e5059c0.bindPopup(popup_ec09366e0b7b57f3fd9d5478ecce2ee9)
        ;




            var marker_15d756b7ba9ef0c94cc7f46d3b3f2a90 = L.marker(
                [43.69144722, -79.32062053],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_1943a302b5c701d6240c7f214338db38 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_7b4794a3ed4b6a9a521622031b420b03 = $(`&lt;div id=&quot;html_7b4794a3ed4b6a9a521622031b420b03&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Danforth East York&lt;/div&gt;`)[0];
            popup_1943a302b5c701d6240c7f214338db38.setContent(html_7b4794a3ed4b6a9a521622031b420b03);


        marker_15d756b7ba9ef0c94cc7f46d3b3f2a90.bindPopup(popup_1943a302b5c701d6240c7f214338db38)
        ;




            var marker_50d852aef22abfe31df42814ee1564a7 = L.marker(
                [43.71492666, -79.33414521],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_694f01a8550a7e8b3ac57ae2e2e575fa = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_3f366851ba7de9b2346a413cbb6da1a1 = $(`&lt;div id=&quot;html_3f366851ba7de9b2346a413cbb6da1a1&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Flemingdon Park&lt;/div&gt;`)[0];
            popup_694f01a8550a7e8b3ac57ae2e2e575fa.setContent(html_3f366851ba7de9b2346a413cbb6da1a1);


        marker_50d852aef22abfe31df42814ee1564a7.bindPopup(popup_694f01a8550a7e8b3ac57ae2e2e575fa)
        ;




            var marker_9e886f5b6994121d9036ca3976acef32 = L.marker(
                [43.74248611, -79.22206817],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_123624d25709f9cc63ff0788cded78d4 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_7464af5266ec224721f42112bdfbd9a3 = $(`&lt;div id=&quot;html_7464af5266ec224721f42112bdfbd9a3&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Scarborough Village&lt;/div&gt;`)[0];
            popup_123624d25709f9cc63ff0788cded78d4.setContent(html_7464af5266ec224721f42112bdfbd9a3);


        marker_9e886f5b6994121d9036ca3976acef32.bindPopup(popup_123624d25709f9cc63ff0788cded78d4)
        ;




            var marker_ba3509a590da4806433d98d09c359329 = L.marker(
                [43.77888161, -79.41953867],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_4c5ab8dc9d3d5b36eed50fec8a800548 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_7e962d89f13ade2bb8a3624fd76b7591 = $(`&lt;div id=&quot;html_7e962d89f13ade2bb8a3624fd76b7591&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Newtonbrook West&lt;/div&gt;`)[0];
            popup_4c5ab8dc9d3d5b36eed50fec8a800548.setContent(html_7e962d89f13ade2bb8a3624fd76b7591);


        marker_ba3509a590da4806433d98d09c359329.bindPopup(popup_4c5ab8dc9d3d5b36eed50fec8a800548)
        ;




            var marker_ab90d343b84e70817f14e8b5bafd7a67 = L.marker(
                [43.71107784, -79.39927621],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_0c3458a3ae2652ffb2b0a2f6ed49d976 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_47d416ace1c4212cd1293727f4a81a4e = $(`&lt;div id=&quot;html_47d416ace1c4212cd1293727f4a81a4e&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Mount Pleasant West&lt;/div&gt;`)[0];
            popup_0c3458a3ae2652ffb2b0a2f6ed49d976.setContent(html_47d416ace1c4212cd1293727f4a81a4e);


        marker_ab90d343b84e70817f14e8b5bafd7a67.bindPopup(popup_0c3458a3ae2652ffb2b0a2f6ed49d976)
        ;




            var marker_4d78eb184ff4c3c3818fc692895b4acb = L.marker(
                [43.67780884, -79.47860613],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_6d06bf47a7f1041c3fd562bc85a55fb9 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_03015f6af22f2829b0b7e508c28907e7 = $(`&lt;div id=&quot;html_03015f6af22f2829b0b7e508c28907e7&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Rockcliffe-Smythe&lt;/div&gt;`)[0];
            popup_6d06bf47a7f1041c3fd562bc85a55fb9.setContent(html_03015f6af22f2829b0b7e508c28907e7);


        marker_4d78eb184ff4c3c3818fc692895b4acb.bindPopup(popup_6d06bf47a7f1041c3fd562bc85a55fb9)
        ;




            var marker_39d7d88be38454aaba20f7987a65e363 = L.marker(
                [43.63933996, -79.45127101],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_360098cf1952bf3dd12976f246eba6a8 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_e83eee3859ade7db7a4cf1e45ceef3cb = $(`&lt;div id=&quot;html_e83eee3859ade7db7a4cf1e45ceef3cb&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;High Park-Swansea&lt;/div&gt;`)[0];
            popup_360098cf1952bf3dd12976f246eba6a8.setContent(html_e83eee3859ade7db7a4cf1e45ceef3cb);


        marker_39d7d88be38454aaba20f7987a65e363.bindPopup(popup_360098cf1952bf3dd12976f246eba6a8)
        ;




            var marker_ad0c96aa98901f630071bbcc98dd56c6 = L.marker(
                [43.67051816, -79.31158524],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_af5f3f932b5675c63d4a04541b4b1d34 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_d27bae7820edc6d7d4fc823f9c6003a7 = $(`&lt;div id=&quot;html_d27bae7820edc6d7d4fc823f9c6003a7&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Woodbine Corridor&lt;/div&gt;`)[0];
            popup_af5f3f932b5675c63d4a04541b4b1d34.setContent(html_d27bae7820edc6d7d4fc823f9c6003a7);


        marker_ad0c96aa98901f630071bbcc98dd56c6.bindPopup(popup_af5f3f932b5675c63d4a04541b4b1d34)
        ;




            var marker_ffe651137e816f2ff10d28da13e52007 = L.marker(
                [43.70060252, -79.51775154],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_9b942f124489a15c51eec06187f6721c = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_a4c1eca2eaabd8e505a9f8cbe8069e19 = $(`&lt;div id=&quot;html_a4c1eca2eaabd8e505a9f8cbe8069e19&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Weston&lt;/div&gt;`)[0];
            popup_9b942f124489a15c51eec06187f6721c.setContent(html_a4c1eca2eaabd8e505a9f8cbe8069e19);


        marker_ffe651137e816f2ff10d28da13e52007.bindPopup(popup_9b942f124489a15c51eec06187f6721c)
        ;




            var marker_7ddedf835d2acb6250ca008849528bcc = L.marker(
                [43.76882728, -79.52036423],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_d3d577fcdd6935923d41f8c15993f6da = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_f7e9d10c3ed13f669fbdb984b6188b3c = $(`&lt;div id=&quot;html_f7e9d10c3ed13f669fbdb984b6188b3c&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Black Creek&lt;/div&gt;`)[0];
            popup_d3d577fcdd6935923d41f8c15993f6da.setContent(html_f7e9d10c3ed13f669fbdb984b6188b3c);


        marker_7ddedf835d2acb6250ca008849528bcc.bindPopup(popup_d3d577fcdd6935923d41f8c15993f6da)
        ;




            var marker_978572e63906148e414b5033e203cf69 = L.marker(
                [43.72998475, -79.26699358],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_0ae7673fd6e6ee2a06ac9806eb24be52 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_52cda540ebb60544240dbe1546564220 = $(`&lt;div id=&quot;html_52cda540ebb60544240dbe1546564220&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Kennedy Park&lt;/div&gt;`)[0];
            popup_0ae7673fd6e6ee2a06ac9806eb24be52.setContent(html_52cda540ebb60544240dbe1546564220);


        marker_978572e63906148e414b5033e203cf69.bindPopup(popup_0ae7673fd6e6ee2a06ac9806eb24be52)
        ;




            var marker_a30cadf01eb8b26c78adf5519323f695 = L.marker(
                [43.67862763, -79.32787432],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_a2227226f949fdba8949a9d5652042b0 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_e5a1e3aaac55538dca9715c291c9e845 = $(`&lt;div id=&quot;html_e5a1e3aaac55538dca9715c291c9e845&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Greenwood-Coxwell&lt;/div&gt;`)[0];
            popup_a2227226f949fdba8949a9d5652042b0.setContent(html_e5a1e3aaac55538dca9715c291c9e845);


        marker_a30cadf01eb8b26c78adf5519323f695.bindPopup(popup_a2227226f949fdba8949a9d5652042b0)
        ;




            var marker_8204cfa2875761267b2ccb738c18b2a6 = L.marker(
                [0.0, 0.0],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_5552241f21d8eb046976d8f3029113c8 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_eaa45ec874c84c315b3a6bb60b11d763 = $(`&lt;div id=&quot;html_eaa45ec874c84c315b3a6bb60b11d763&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;NSA&lt;/div&gt;`)[0];
            popup_5552241f21d8eb046976d8f3029113c8.setContent(html_eaa45ec874c84c315b3a6bb60b11d763);


        marker_8204cfa2875761267b2ccb738c18b2a6.bindPopup(popup_5552241f21d8eb046976d8f3029113c8)
        ;




            var marker_92c0ef2015f0dfa6983044309de6112a = L.marker(
                [43.78959109, -79.44983192],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_3f93b538cab743f1cdb084e8738bdd3d = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_f53ad6156ceebe6f2964aae2b6fec175 = $(`&lt;div id=&quot;html_f53ad6156ceebe6f2964aae2b6fec175&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Westminster-Branson&lt;/div&gt;`)[0];
            popup_3f93b538cab743f1cdb084e8738bdd3d.setContent(html_f53ad6156ceebe6f2964aae2b6fec175);


        marker_92c0ef2015f0dfa6983044309de6112a.bindPopup(popup_3f93b538cab743f1cdb084e8738bdd3d)
        ;




            var marker_f2bda4f99c3e5e4e9c0e6aeab8097a6a = L.marker(
                [43.6880498, -79.47154503],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_dcce07a6a457a94307986842dbcbbc4b = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_cf366dfb324830c28200588ba8224da5 = $(`&lt;div id=&quot;html_cf366dfb324830c28200588ba8224da5&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Keelesdale-Eglinton West&lt;/div&gt;`)[0];
            popup_dcce07a6a457a94307986842dbcbbc4b.setContent(html_cf366dfb324830c28200588ba8224da5);


        marker_f2bda4f99c3e5e4e9c0e6aeab8097a6a.bindPopup(popup_dcce07a6a457a94307986842dbcbbc4b)
        ;




            var marker_1cb2e26e913a6e7cffb8f20d20a26541 = L.marker(
                [43.75001169, -79.45390923],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_5f8e5cde8c412b45a88220f07b153b11 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_ce7941b6628d7b606bf1903c15a9cd4d = $(`&lt;div id=&quot;html_ce7941b6628d7b606bf1903c15a9cd4d&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Clanton Park&lt;/div&gt;`)[0];
            popup_5f8e5cde8c412b45a88220f07b153b11.setContent(html_ce7941b6628d7b606bf1903c15a9cd4d);


        marker_1cb2e26e913a6e7cffb8f20d20a26541.bindPopup(popup_5f8e5cde8c412b45a88220f07b153b11)
        ;




            var marker_b58c0721b7c0d8a17d1573cd0c5003ef = L.marker(
                [43.63920551, -79.58433063],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_3a76bd0e42645f96f7f0548b20ad070b = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_3a003bd557ddbd74c5dfd672fa5b5258 = $(`&lt;div id=&quot;html_3a003bd557ddbd74c5dfd672fa5b5258&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Markland Wood&lt;/div&gt;`)[0];
            popup_3a76bd0e42645f96f7f0548b20ad070b.setContent(html_3a003bd557ddbd74c5dfd672fa5b5258);


        marker_b58c0721b7c0d8a17d1573cd0c5003ef.bindPopup(popup_3a76bd0e42645f96f7f0548b20ad070b)
        ;




            var marker_7512d6fb88204b01ccce017aa889d54e = L.marker(
                [43.75258277, -79.28319326],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_ee6ea92474353e94e53d3d1303d20c0c = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_2d7c35b3cf9325efc3375448c3427ea4 = $(`&lt;div id=&quot;html_2d7c35b3cf9325efc3375448c3427ea4&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Dorset Park&lt;/div&gt;`)[0];
            popup_ee6ea92474353e94e53d3d1303d20c0c.setContent(html_2d7c35b3cf9325efc3375448c3427ea4);


        marker_7512d6fb88204b01ccce017aa889d54e.bindPopup(popup_ee6ea92474353e94e53d3d1303d20c0c)
        ;




            var marker_00bf4f266c1945c46c6aab2fd17951c6 = L.marker(
                [43.71427823, -79.3059261],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_60945b19214e605ab4f7473aa7ed5ee4 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_b9b0df2138cd96f58e36b54234868b7a = $(`&lt;div id=&quot;html_b9b0df2138cd96f58e36b54234868b7a&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;OConnor-Parkview&lt;/div&gt;`)[0];
            popup_60945b19214e605ab4f7473aa7ed5ee4.setContent(html_b9b0df2138cd96f58e36b54234868b7a);


        marker_00bf4f266c1945c46c6aab2fd17951c6.bindPopup(popup_60945b19214e605ab4f7473aa7ed5ee4)
        ;




            var marker_532c3bee232242e269964650887599fb = L.marker(
                [43.71178861, -79.37853604],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_3cb1037e87260cde9af4ffb66d83fdec = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_086fca9b8846a0ef0e8bbd3241102a96 = $(`&lt;div id=&quot;html_086fca9b8846a0ef0e8bbd3241102a96&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Mount Pleasant East&lt;/div&gt;`)[0];
            popup_3cb1037e87260cde9af4ffb66d83fdec.setContent(html_086fca9b8846a0ef0e8bbd3241102a96);


        marker_532c3bee232242e269964650887599fb.bindPopup(popup_3cb1037e87260cde9af4ffb66d83fdec)
        ;




            var marker_20ae53b5f94378da52f97ce521bbcc33 = L.marker(
                [43.66428681, -79.50215597],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_e97079842046c69bcb5ddfb4f1d069dc = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_43fd591012f03d6f434836449dc04326 = $(`&lt;div id=&quot;html_43fd591012f03d6f434836449dc04326&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Lambton Baby Point&lt;/div&gt;`)[0];
            popup_e97079842046c69bcb5ddfb4f1d069dc.setContent(html_43fd591012f03d6f434836449dc04326);


        marker_20ae53b5f94378da52f97ce521bbcc33.bindPopup(popup_e97079842046c69bcb5ddfb4f1d069dc)
        ;




            var marker_7559c062372d5b0003a950cc6b5e7e17 = L.marker(
                [43.73640808, -79.3818677],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_df8c56ea344c3980614c6f083721c8e3 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_990085a026216feb66dfeeee93b4b2ed = $(`&lt;div id=&quot;html_990085a026216feb66dfeeee93b4b2ed&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Bridle Path-Sunnybrook-York Mills&lt;/div&gt;`)[0];
            popup_df8c56ea344c3980614c6f083721c8e3.setContent(html_990085a026216feb66dfeeee93b4b2ed);


        marker_7559c062372d5b0003a950cc6b5e7e17.bindPopup(popup_df8c56ea344c3980614c6f083721c8e3)
        ;




            var marker_228a7fc7840a3e6d45dc39d6591b9cde = L.marker(
                [43.60750763, -79.52985168],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_ad9b73a50c90fd0a04833a68fae9fc3a = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_20e0722dca0b71f6dd7dd7455f7b1843 = $(`&lt;div id=&quot;html_20e0722dca0b71f6dd7dd7455f7b1843&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Alderwood&lt;/div&gt;`)[0];
            popup_ad9b73a50c90fd0a04833a68fae9fc3a.setContent(html_20e0722dca0b71f6dd7dd7455f7b1843);


        marker_228a7fc7840a3e6d45dc39d6591b9cde.bindPopup(popup_ad9b73a50c90fd0a04833a68fae9fc3a)
        ;




            var marker_aebb96881ffeb69f989d92dbe4216faf = L.marker(
                [43.60326759, -79.50627079],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_89b1b6b425085a02a671344114afbf55 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_3f8712165de8eb5a173b1926b3fbae01 = $(`&lt;div id=&quot;html_3f8712165de8eb5a173b1926b3fbae01&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;New Toronto&lt;/div&gt;`)[0];
            popup_89b1b6b425085a02a671344114afbf55.setContent(html_3f8712165de8eb5a173b1926b3fbae01);


        marker_aebb96881ffeb69f989d92dbe4216faf.bindPopup(popup_89b1b6b425085a02a671344114afbf55)
        ;




            var marker_ec23e0e10f8614e26647d1a8ccf949bf = L.marker(
                [43.69432519, -79.41498645],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_fc3a355e71fff8a260b8bdfeaf81a9e2 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_b6bd4567f51163809828452613f5b115 = $(`&lt;div id=&quot;html_b6bd4567f51163809828452613f5b115&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Forest Hill South&lt;/div&gt;`)[0];
            popup_fc3a355e71fff8a260b8bdfeaf81a9e2.setContent(html_b6bd4567f51163809828452613f5b115);


        marker_ec23e0e10f8614e26647d1a8ccf949bf.bindPopup(popup_fc3a355e71fff8a260b8bdfeaf81a9e2)
        ;




            var marker_2afa7239851b11e8d993f49da5dbec16 = L.marker(
                [43.72935527, -79.32835907],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_66b2538b2cd6a42754c2f12ecd0283f0 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_61a7c4f0fbd7929b3c05ed3381d3c350 = $(`&lt;div id=&quot;html_61a7c4f0fbd7929b3c05ed3381d3c350&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Banbury-Don Mills&lt;/div&gt;`)[0];
            popup_66b2538b2cd6a42754c2f12ecd0283f0.setContent(html_61a7c4f0fbd7929b3c05ed3381d3c350);


        marker_2afa7239851b11e8d993f49da5dbec16.bindPopup(popup_66b2538b2cd6a42754c2f12ecd0283f0)
        ;




            var marker_da3f11616c618c1f082bf28ebd0c50cb = L.marker(
                [43.7441499, -79.40668473],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_e02c80aae3e87a673d476f871a2edce3 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_a26fcd623d9af434266a22d6da6046b1 = $(`&lt;div id=&quot;html_a26fcd623d9af434266a22d6da6046b1&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;St.Andrew-Windfields&lt;/div&gt;`)[0];
            popup_e02c80aae3e87a673d476f871a2edce3.setContent(html_a26fcd623d9af434266a22d6da6046b1);


        marker_da3f11616c618c1f082bf28ebd0c50cb.bindPopup(popup_e02c80aae3e87a673d476f871a2edce3)
        ;




            var marker_e4bae036ac5c36717164ae5fcd41f3ac = L.marker(
                [43.65633298, -79.46818422],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_48e9732af6b2f6295f879657c04d0731 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_b573e90805c627d9b225043730de1406 = $(`&lt;div id=&quot;html_b573e90805c627d9b225043730de1406&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;High Park North&lt;/div&gt;`)[0];
            popup_48e9732af6b2f6295f879657c04d0731.setContent(html_b573e90805c627d9b225043730de1406);


        marker_e4bae036ac5c36717164ae5fcd41f3ac.bindPopup(popup_48e9732af6b2f6295f879657c04d0731)
        ;




            var marker_668d5a060acff573a917a31d7e7155e6 = L.marker(
                [43.67235839, -79.37681431],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_b98294ce5e79cd5993584895f07c9594 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_54bb255b73af92f486fb815256d283e0 = $(`&lt;div id=&quot;html_54bb255b73af92f486fb815256d283e0&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;North St.James Town&lt;/div&gt;`)[0];
            popup_b98294ce5e79cd5993584895f07c9594.setContent(html_54bb255b73af92f486fb815256d283e0);


        marker_668d5a060acff573a917a31d7e7155e6.bindPopup(popup_b98294ce5e79cd5993584895f07c9594)
        ;




            var marker_1bbae35638dcf7265e0c6e51fa039b11 = L.marker(
                [43.72798391, -79.22908163],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_9bffa92884eb046264d469c528e9b0cd = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_05d3c3ce98ec97b553bce5b47a2f692b = $(`&lt;div id=&quot;html_05d3c3ce98ec97b553bce5b47a2f692b&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Cliffcrest&lt;/div&gt;`)[0];
            popup_9bffa92884eb046264d469c528e9b0cd.setContent(html_05d3c3ce98ec97b553bce5b47a2f692b);


        marker_1bbae35638dcf7265e0c6e51fa039b11.bindPopup(popup_9bffa92884eb046264d469c528e9b0cd)
        ;




            var marker_76c965a452a0471d14dd61bc2066988c = L.marker(
                [43.7366874, -79.5088181],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_1cc15002f4c856fe771611838c468fae = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_c2b0044ff4300595672811b90c614d87 = $(`&lt;div id=&quot;html_c2b0044ff4300595672811b90c614d87&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Glenfield-Jane Heights&lt;/div&gt;`)[0];
            popup_1cc15002f4c856fe771611838c468fae.setContent(html_c2b0044ff4300595672811b90c614d87);


        marker_76c965a452a0471d14dd61bc2066988c.bindPopup(popup_1cc15002f4c856fe771611838c468fae)
        ;




            var marker_c9e5f19bbb72b312365acacc64f294aa = L.marker(
                [43.76262335, -79.56438518],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_4854aa5b9bbe717c771abe9b943ba268 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_4e2ed8a7135e3411961f2f88fc268d7c = $(`&lt;div id=&quot;html_4e2ed8a7135e3411961f2f88fc268d7c&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Humber Summit&lt;/div&gt;`)[0];
            popup_4854aa5b9bbe717c771abe9b943ba268.setContent(html_4e2ed8a7135e3411961f2f88fc268d7c);


        marker_c9e5f19bbb72b312365acacc64f294aa.bindPopup(popup_4854aa5b9bbe717c771abe9b943ba268)
        ;




            var marker_4ad538a157b8b07506799f38018f0641 = L.marker(
                [43.71545763, -79.50718536],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_68cee9d634536470868929f84e98165e = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_c43a4d77263dbd20eb522a2780d6858f = $(`&lt;div id=&quot;html_c43a4d77263dbd20eb522a2780d6858f&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Pelmo Park-Humberlea&lt;/div&gt;`)[0];
            popup_68cee9d634536470868929f84e98165e.setContent(html_c43a4d77263dbd20eb522a2780d6858f);


        marker_4ad538a157b8b07506799f38018f0641.bindPopup(popup_68cee9d634536470868929f84e98165e)
        ;




            var marker_76b2ba16a30fccd479be13744b74f6de = L.marker(
                [43.62229718, -79.50590083],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_0fdb0a6d52a3ccf358ff7ab44524141c = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_289d03c84e41e4d73f5c55c8fc5ed9d9 = $(`&lt;div id=&quot;html_289d03c84e41e4d73f5c55c8fc5ed9d9&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Stonegate-Queensway&lt;/div&gt;`)[0];
            popup_0fdb0a6d52a3ccf358ff7ab44524141c.setContent(html_289d03c84e41e4d73f5c55c8fc5ed9d9);


        marker_76b2ba16a30fccd479be13744b74f6de.bindPopup(popup_0fdb0a6d52a3ccf358ff7ab44524141c)
        ;




            var marker_e48710c725df4faa805c8fdbf29e6c77 = L.marker(
                [43.70151038, -79.25289415],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_2b429d9e252282f86b1533f40b54d3cc = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_f06731dbf486b7e3e16cdcf315a212c0 = $(`&lt;div id=&quot;html_f06731dbf486b7e3e16cdcf315a212c0&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Birchcliffe-Cliffside&lt;/div&gt;`)[0];
            popup_2b429d9e252282f86b1533f40b54d3cc.setContent(html_f06731dbf486b7e3e16cdcf315a212c0);


        marker_e48710c725df4faa805c8fdbf29e6c77.bindPopup(popup_2b429d9e252282f86b1533f40b54d3cc)
        ;




            var marker_89de83f35fd21bf6193d1cae1a27aa4e = L.marker(
                [43.75545869, -79.43844041],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_f980cb7c439f5863423569f5f2c430e6 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_b41b6b24bb9ab2aee80930cb422ef616 = $(`&lt;div id=&quot;html_b41b6b24bb9ab2aee80930cb422ef616&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Bathurst Manor&lt;/div&gt;`)[0];
            popup_f980cb7c439f5863423569f5f2c430e6.setContent(html_b41b6b24bb9ab2aee80930cb422ef616);


        marker_89de83f35fd21bf6193d1cae1a27aa4e.bindPopup(popup_f980cb7c439f5863423569f5f2c430e6)
        ;




            var marker_60255d871c808946c0b95dcbeab7d03d = L.marker(
                [43.71780474, -79.40349687],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_6439f6839959474dd66b834ea2170218 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_be7703631c37d4bfaa1f517ed23db4ba = $(`&lt;div id=&quot;html_be7703631c37d4bfaa1f517ed23db4ba&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Lawrence Park South&lt;/div&gt;`)[0];
            popup_6439f6839959474dd66b834ea2170218.setContent(html_be7703631c37d4bfaa1f517ed23db4ba);


        marker_60255d871c808946c0b95dcbeab7d03d.bindPopup(popup_6439f6839959474dd66b834ea2170218)
        ;




            var marker_832f6d23ec43230c182510090552aaf6 = L.marker(
                [43.66542584, -79.46585038],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_8bcbd3c9c0b0547a9ed7e3e1a038cd4e = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_99890f74366c64b7a16b14314f76a4d0 = $(`&lt;div id=&quot;html_99890f74366c64b7a16b14314f76a4d0&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Junction Area&lt;/div&gt;`)[0];
            popup_8bcbd3c9c0b0547a9ed7e3e1a038cd4e.setContent(html_99890f74366c64b7a16b14314f76a4d0);


        marker_832f6d23ec43230c182510090552aaf6.bindPopup(popup_8bcbd3c9c0b0547a9ed7e3e1a038cd4e)
        ;




            var marker_f9930195ae71606ed50a905aab104655 = L.marker(
                [43.71510482, -79.55507738],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_04e6fd9cb4cf1db762030868b664228a = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_4e686bfc31117b47de9a77af758f6a30 = $(`&lt;div id=&quot;html_4e686bfc31117b47de9a77af758f6a30&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Rexdale-Kipling&lt;/div&gt;`)[0];
            popup_04e6fd9cb4cf1db762030868b664228a.setContent(html_4e686bfc31117b47de9a77af758f6a30);


        marker_f9930195ae71606ed50a905aab104655.bindPopup(popup_04e6fd9cb4cf1db762030868b664228a)
        ;




            var marker_9460b398c83bd5e76e8b147d123d71d5 = L.marker(
                [43.77908536, -79.34869595],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_fec525191f023e617c47a515b6f13ee2 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_123566c0c564f640f56bfbeaff0f209e = $(`&lt;div id=&quot;html_123566c0c564f640f56bfbeaff0f209e&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Don Valley Village&lt;/div&gt;`)[0];
            popup_fec525191f023e617c47a515b6f13ee2.setContent(html_123566c0c564f640f56bfbeaff0f209e);


        marker_9460b398c83bd5e76e8b147d123d71d5.bindPopup(popup_fec525191f023e617c47a515b6f13ee2)
        ;




            var marker_8f4d734975c3dafde476be97f4e47470 = L.marker(
                [43.72003382, -79.42993872],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_73eb73ee0a3a215b107a2e4696996193 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_eb7e8b420c03c4ab5de2042ecc278c9b = $(`&lt;div id=&quot;html_eb7e8b420c03c4ab5de2042ecc278c9b&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Bedford Park-Nortown&lt;/div&gt;`)[0];
            popup_73eb73ee0a3a215b107a2e4696996193.setContent(html_eb7e8b420c03c4ab5de2042ecc278c9b);


        marker_8f4d734975c3dafde476be97f4e47470.bindPopup(popup_73eb73ee0a3a215b107a2e4696996193)
        ;




            var marker_45c4727c8a68b7f00a33bfcf18c095e6 = L.marker(
                [43.7727692, -79.44063916],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_79d6a01a5d34f6b8c4f677f3dc94fce4 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_9e0ec72fbf6f344dbe2a7a524debd2a4 = $(`&lt;div id=&quot;html_9e0ec72fbf6f344dbe2a7a524debd2a4&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Willowdale West&lt;/div&gt;`)[0];
            popup_79d6a01a5d34f6b8c4f677f3dc94fce4.setContent(html_9e0ec72fbf6f344dbe2a7a524debd2a4);


        marker_45c4727c8a68b7f00a33bfcf18c095e6.bindPopup(popup_79d6a01a5d34f6b8c4f677f3dc94fce4)
        ;




            var marker_df5877a017e663bd1fa15b8ace267a1d = L.marker(
                [43.79031287, -79.19793737],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_e8a3ab6c9d2803d7dc63b4338199d70f = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_1e84ae98a66370c8ebbb0bf8624e03aa = $(`&lt;div id=&quot;html_1e84ae98a66370c8ebbb0bf8624e03aa&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Morningside&lt;/div&gt;`)[0];
            popup_e8a3ab6c9d2803d7dc63b4338199d70f.setContent(html_1e84ae98a66370c8ebbb0bf8624e03aa);


        marker_df5877a017e663bd1fa15b8ace267a1d.bindPopup(popup_e8a3ab6c9d2803d7dc63b4338199d70f)
        ;




            var marker_f811c6581eff318b92f12130398d7851 = L.marker(
                [43.8164915, -79.33141941],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_438929b6b13a6804ada867dc814e22a5 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_03f5a5dac0a2887931b9b6dd3d0fda61 = $(`&lt;div id=&quot;html_03f5a5dac0a2887931b9b6dd3d0fda61&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Steeles&lt;/div&gt;`)[0];
            popup_438929b6b13a6804ada867dc814e22a5.setContent(html_03f5a5dac0a2887931b9b6dd3d0fda61);


        marker_f811c6581eff318b92f12130398d7851.bindPopup(popup_438929b6b13a6804ada867dc814e22a5)
        ;




            var marker_e48e88e510809d73bae9d977857bd56c = L.marker(
                [43.78714471, -79.15225673],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_a8510c36c6b7deaa97a612146b0a7571 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_fb31def5267a93ecf60db882c90de6ca = $(`&lt;div id=&quot;html_fb31def5267a93ecf60db882c90de6ca&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Centennial Scarborough&lt;/div&gt;`)[0];
            popup_a8510c36c6b7deaa97a612146b0a7571.setContent(html_fb31def5267a93ecf60db882c90de6ca);


        marker_e48e88e510809d73bae9d977857bd56c.bindPopup(popup_a8510c36c6b7deaa97a612146b0a7571)
        ;




            var marker_261d0dd41d20578629d5a1be0e8a5508 = L.marker(
                [43.6897005, -79.39744799],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_78ac17c36709911e7f8e9b574d15d61b = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_2e9842e3deb3274e9ba36ec0dc5212fd = $(`&lt;div id=&quot;html_2e9842e3deb3274e9ba36ec0dc5212fd&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Yonge-St.Clair&lt;/div&gt;`)[0];
            popup_78ac17c36709911e7f8e9b574d15d61b.setContent(html_2e9842e3deb3274e9ba36ec0dc5212fd);


        marker_261d0dd41d20578629d5a1be0e8a5508.bindPopup(popup_78ac17c36709911e7f8e9b574d15d61b)
        ;




            var marker_fdaf0fa97882c7950915c33ebb9fd9b7 = L.marker(
                [43.6799437, -79.40611935],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_e302021fb93533353bd4586cb37ad685 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_44e30fbef762ad54b95361373c588066 = $(`&lt;div id=&quot;html_44e30fbef762ad54b95361373c588066&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Casa Loma&lt;/div&gt;`)[0];
            popup_e302021fb93533353bd4586cb37ad685.setContent(html_44e30fbef762ad54b95361373c588066);


        marker_fdaf0fa97882c7950915c33ebb9fd9b7.bindPopup(popup_e302021fb93533353bd4586cb37ad685)
        ;




            var marker_542cb4884d59a86b07b5f09d9ae5caf3 = L.marker(
                [43.80263794, -79.35242116],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_ff9645409de96d725a1eddf641be23eb = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_119656c284091b2766ed1bcc89ba0124 = $(`&lt;div id=&quot;html_119656c284091b2766ed1bcc89ba0124&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Hillcrest Village&lt;/div&gt;`)[0];
            popup_ff9645409de96d725a1eddf641be23eb.setContent(html_119656c284091b2766ed1bcc89ba0124);


        marker_542cb4884d59a86b07b5f09d9ae5caf3.bindPopup(popup_ff9645409de96d725a1eddf641be23eb)
        ;




            var marker_4206f5066b56fb92568cfeb146ba2fe7 = L.marker(
                [43.66465652, -79.40270156],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_f8cc2594cb8d798052988843851a62a0 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_a37ab0b6a39b4dbc336444013960e4d5 = $(`&lt;div id=&quot;html_a37ab0b6a39b4dbc336444013960e4d5&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;University&lt;/div&gt;`)[0];
            popup_f8cc2594cb8d798052988843851a62a0.setContent(html_a37ab0b6a39b4dbc336444013960e4d5);


        marker_4206f5066b56fb92568cfeb146ba2fe7.bindPopup(popup_f8cc2594cb8d798052988843851a62a0)
        ;




            var marker_689da10d0a3829ee956cd70696dcdff3 = L.marker(
                [43.73114796, -79.40750317],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_eb522d42d789b1ef121a445e96cb1baf = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_44b1d68dd394a236a40ed17024d6affd = $(`&lt;div id=&quot;html_44b1d68dd394a236a40ed17024d6affd&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Lawrence Park North&lt;/div&gt;`)[0];
            popup_eb522d42d789b1ef121a445e96cb1baf.setContent(html_44b1d68dd394a236a40ed17024d6affd);


        marker_689da10d0a3829ee956cd70696dcdff3.bindPopup(popup_eb522d42d789b1ef121a445e96cb1baf)
        ;




            var marker_34676a81af2aa92b5be27ea8857e4ff6 = L.marker(
                [43.76053065, -79.4231866],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_d4a36b967ba37583f5c2bbd619b3831e = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_b17d1007c19d523b188ccf7d33b6d3a4 = $(`&lt;div id=&quot;html_b17d1007c19d523b188ccf7d33b6d3a4&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Lansing-Westgate&lt;/div&gt;`)[0];
            popup_d4a36b967ba37583f5c2bbd619b3831e.setContent(html_b17d1007c19d523b188ccf7d33b6d3a4);


        marker_34676a81af2aa92b5be27ea8857e4ff6.bindPopup(popup_d4a36b967ba37583f5c2bbd619b3831e)
        ;




            var marker_e0ad721aa170793a48db92a742d22d9a = L.marker(
                [43.74326507, -79.58207638],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_8f9328ac3e678ffff201d276860d4dd2 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_95531ad11a225dd65f827f584d9aab0c = $(`&lt;div id=&quot;html_95531ad11a225dd65f827f584d9aab0c&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Mount Olive-Silverstone-Jamestown&lt;/div&gt;`)[0];
            popup_8f9328ac3e678ffff201d276860d4dd2.setContent(html_95531ad11a225dd65f827f584d9aab0c);


        marker_e0ad721aa170793a48db92a742d22d9a.bindPopup(popup_8f9328ac3e678ffff201d276860d4dd2)
        ;




            var marker_abd9b793a2f9253e5526530012f4f5df = L.marker(
                [43.77797984, -79.31116492],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_d0071714c46a7423b02e80300f05cc5b = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_310dc8a79d5b7a93177ba03488af92fe = $(`&lt;div id=&quot;html_310dc8a79d5b7a93177ba03488af92fe&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Tam OShanter-Sullivan&lt;/div&gt;`)[0];
            popup_d0071714c46a7423b02e80300f05cc5b.setContent(html_310dc8a79d5b7a93177ba03488af92fe);


        marker_abd9b793a2f9253e5526530012f4f5df.bindPopup(popup_d0071714c46a7423b02e80300f05cc5b)
        ;




            var marker_b16e9333142076c92f0993b23c1a035b = L.marker(
                [43.71806233, -79.55384096],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_1e80e4122d60ff9d81e660aea34df748 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_e2864850b63f5d09bf583f21a3f96a08 = $(`&lt;div id=&quot;html_e2864850b63f5d09bf583f21a3f96a08&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Elms-Old Rexdale&lt;/div&gt;`)[0];
            popup_1e80e4122d60ff9d81e660aea34df748.setContent(html_e2864850b63f5d09bf583f21a3f96a08);


        marker_b16e9333142076c92f0993b23c1a035b.bindPopup(popup_1e80e4122d60ff9d81e660aea34df748)
        ;




            var marker_721e2594219e74a6d9afdaaf52cc8cbb = L.marker(
                [43.70628591, -79.37403755],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_6092941d765e07272ea50b1b86c3206d = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_d74148174a9e175473c62f59405e1da4 = $(`&lt;div id=&quot;html_d74148174a9e175473c62f59405e1da4&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Leaside-Bennington&lt;/div&gt;`)[0];
            popup_6092941d765e07272ea50b1b86c3206d.setContent(html_d74148174a9e175473c62f59405e1da4);


        marker_721e2594219e74a6d9afdaaf52cc8cbb.bindPopup(popup_6092941d765e07272ea50b1b86c3206d)
        ;




            var marker_bb7b38ed920b1e3bed548dcf3c96dd88 = L.marker(
                [43.79500447, -79.32961357],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_a65ba8392a70c06c4d3687435ef735a8 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_3780b19c4ae3a443d4cab7c0f967b331 = $(`&lt;div id=&quot;html_3780b19c4ae3a443d4cab7c0f967b331&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;LAmoreaux&lt;/div&gt;`)[0];
            popup_a65ba8392a70c06c4d3687435ef735a8.setContent(html_3780b19c4ae3a443d4cab7c0f967b331);


        marker_bb7b38ed920b1e3bed548dcf3c96dd88.bindPopup(popup_a65ba8392a70c06c4d3687435ef735a8)
        ;




            var marker_1c0021bc409265446fc702ec8d1f2811 = L.marker(
                [43.71574209, -79.5047176],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_d6a4080888a0ead5384ca8cd2811aca4 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_dbb014da1722e58be5f83e2f2c918710 = $(`&lt;div id=&quot;html_dbb014da1722e58be5f83e2f2c918710&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Rustic&lt;/div&gt;`)[0];
            popup_d6a4080888a0ead5384ca8cd2811aca4.setContent(html_dbb014da1722e58be5f83e2f2c918710);


        marker_1c0021bc409265446fc702ec8d1f2811.bindPopup(popup_d6a4080888a0ead5384ca8cd2811aca4)
        ;




            var marker_4d7d2e976e3236c0c671cfb0763c29ed = L.marker(
                [43.67779387, -79.35070987],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_2da18a138a591e7e807c2789ae6135cd = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_e23de4b34cf15766fdfefefbd7a693df = $(`&lt;div id=&quot;html_e23de4b34cf15766fdfefefbd7a693df&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;North Riverdale&lt;/div&gt;`)[0];
            popup_2da18a138a591e7e807c2789ae6135cd.setContent(html_e23de4b34cf15766fdfefefbd7a693df);


        marker_4d7d2e976e3236c0c671cfb0763c29ed.bindPopup(popup_2da18a138a591e7e807c2789ae6135cd)
        ;




            var marker_af5111f72a4d3344e374f9ac08507b27 = L.marker(
                [43.68445552, -79.42140231],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_94b0964357cf0b88b53eaa90732075f9 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_126c3772829eddf607ad5000df7edc9b = $(`&lt;div id=&quot;html_126c3772829eddf607ad5000df7edc9b&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Humewood-Cedarvale&lt;/div&gt;`)[0];
            popup_94b0964357cf0b88b53eaa90732075f9.setContent(html_126c3772829eddf607ad5000df7edc9b);


        marker_af5111f72a4d3344e374f9ac08507b27.bindPopup(popup_94b0964357cf0b88b53eaa90732075f9)
        ;




            var marker_b1823f83801279ec8562d8411fd2aa3e = L.marker(
                [43.74171555, -79.57377923],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_39c67c12a447bda3c6f0219dd1ea42cb = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_8718c24087765f7b9429e7d9095a620d = $(`&lt;div id=&quot;html_8718c24087765f7b9429e7d9095a620d&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Thistletown-Beaumond Heights&lt;/div&gt;`)[0];
            popup_39c67c12a447bda3c6f0219dd1ea42cb.setContent(html_8718c24087765f7b9429e7d9095a620d);


        marker_b1823f83801279ec8562d8411fd2aa3e.bindPopup(popup_39c67c12a447bda3c6f0219dd1ea42cb)
        ;




            var marker_61d14a294ba765fe0bfa06d744213669 = L.marker(
                [43.6761888, -79.33746603],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_8d2d752ca04ec55e774c5b90ca5fd72f = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_33dc2406fe544502b6d36d556d213f9e = $(`&lt;div id=&quot;html_33dc2406fe544502b6d36d556d213f9e&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Blake-Jones&lt;/div&gt;`)[0];
            popup_8d2d752ca04ec55e774c5b90ca5fd72f.setContent(html_33dc2406fe544502b6d36d556d213f9e);


        marker_61d14a294ba765fe0bfa06d744213669.bindPopup(popup_8d2d752ca04ec55e774c5b90ca5fd72f)
        ;




            var marker_6ffd17185763fbf5c2057c05ec954ad6 = L.marker(
                [43.66198485, -79.42562006],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_55394e4c83c71987db81be6a6c2f4eb3 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_8b29da20a58c476460e69e528a4324c7 = $(`&lt;div id=&quot;html_8b29da20a58c476460e69e528a4324c7&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Palmerston-Little Italy&lt;/div&gt;`)[0];
            popup_55394e4c83c71987db81be6a6c2f4eb3.setContent(html_8b29da20a58c476460e69e528a4324c7);


        marker_6ffd17185763fbf5c2057c05ec954ad6.bindPopup(popup_55394e4c83c71987db81be6a6c2f4eb3)
        ;




            var marker_b09794bb20a82ff225a62b6715621f1a = L.marker(
                [43.64207956, -79.58609531],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_3a2613c2b8a2354601c47338da5d81cd = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_4594bab19b6a6b03a279e99def5567f9 = $(`&lt;div id=&quot;html_4594bab19b6a6b03a279e99def5567f9&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Eringate-Centennial-West Deane&lt;/div&gt;`)[0];
            popup_3a2613c2b8a2354601c47338da5d81cd.setContent(html_4594bab19b6a6b03a279e99def5567f9);


        marker_b09794bb20a82ff225a62b6715621f1a.bindPopup(popup_3a2613c2b8a2354601c47338da5d81cd)
        ;




            var marker_21f86377fd118d296b119be34ac409ed = L.marker(
                [43.73027846, -79.43819728],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_416f7f40d4e511c31c3aa9259572c2b8 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_fd2ced123420dfcf83ca9329ae9a6ea7 = $(`&lt;div id=&quot;html_fd2ced123420dfcf83ca9329ae9a6ea7&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Englemount-Lawrence&lt;/div&gt;`)[0];
            popup_416f7f40d4e511c31c3aa9259572c2b8.setContent(html_fd2ced123420dfcf83ca9329ae9a6ea7);


        marker_21f86377fd118d296b119be34ac409ed.bindPopup(popup_416f7f40d4e511c31c3aa9259572c2b8)
        ;




            var marker_e5ee8de32afdfc372aa23de760dc53cf = L.marker(
                [43.69876975, -79.43597803],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_4d935fc5949e42ceb9395925f7408254 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_038e3bdcf4a391ebcc1e228cd90eb2aa = $(`&lt;div id=&quot;html_038e3bdcf4a391ebcc1e228cd90eb2aa&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Forest Hill North&lt;/div&gt;`)[0];
            popup_4d935fc5949e42ceb9395925f7408254.setContent(html_038e3bdcf4a391ebcc1e228cd90eb2aa);


        marker_e5ee8de32afdfc372aa23de760dc53cf.bindPopup(popup_4d935fc5949e42ceb9395925f7408254)
        ;




            var marker_9e0cb105ca6826436f71bffa6e13fce7 = L.marker(
                [43.66561293, -79.48477942],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_e503a1e24faac6d529bfadf285486cc5 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_7e2ab060f9f5a190b7eab607dd15882f = $(`&lt;div id=&quot;html_7e2ab060f9f5a190b7eab607dd15882f&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Runnymede-Bloor West Village&lt;/div&gt;`)[0];
            popup_e503a1e24faac6d529bfadf285486cc5.setContent(html_7e2ab060f9f5a190b7eab607dd15882f);


        marker_9e0cb105ca6826436f71bffa6e13fce7.bindPopup(popup_e503a1e24faac6d529bfadf285486cc5)
        ;




            var marker_c016aade9aaec50213847fc8b161e137 = L.marker(
                [43.67633938, -79.57037025],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_a80c7558648ceba1bb59160c47ea51f6 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_32e623e1a39d0131384bfe01cb591ab3 = $(`&lt;div id=&quot;html_32e623e1a39d0131384bfe01cb591ab3&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Willowridge-Martingrove-Richview&lt;/div&gt;`)[0];
            popup_a80c7558648ceba1bb59160c47ea51f6.setContent(html_32e623e1a39d0131384bfe01cb591ab3);


        marker_c016aade9aaec50213847fc8b161e137.bindPopup(popup_a80c7558648ceba1bb59160c47ea51f6)
        ;




            var marker_659fb150de3e74cb82b3e01b9097cf8e = L.marker(
                [43.808508, -79.3724657],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_54a54c7f06d8f7b17b83e5e869ca0ee7 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_90d3eb254d9c88064bb4b304447a155d = $(`&lt;div id=&quot;html_90d3eb254d9c88064bb4b304447a155d&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Bayview Woods-Steeles&lt;/div&gt;`)[0];
            popup_54a54c7f06d8f7b17b83e5e869ca0ee7.setContent(html_90d3eb254d9c88064bb4b304447a155d);


        marker_659fb150de3e74cb82b3e01b9097cf8e.bindPopup(popup_54a54c7f06d8f7b17b83e5e869ca0ee7)
        ;




            var marker_6afa4d77bdd27bf64d29272545044c90 = L.marker(
                [43.79922772, -79.28219213],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_7c63dccce7a226283d93a24f22a9376e = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_66fd56136fd1f9ffe800c592875cb00e = $(`&lt;div id=&quot;html_66fd56136fd1f9ffe800c592875cb00e&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Agincourt North&lt;/div&gt;`)[0];
            popup_7c63dccce7a226283d93a24f22a9376e.setContent(html_66fd56136fd1f9ffe800c592875cb00e);


        marker_6afa4d77bdd27bf64d29272545044c90.bindPopup(popup_7c63dccce7a226283d93a24f22a9376e)
        ;




            var marker_2bdd7d8426d8b782d2ffdd4d60d9548d = L.marker(
                [43.69214748, -79.30477556],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_14dfd630aa74a958bbf3359ac1b8b2d3 = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_5099955878f542cfa86b456d434807f7 = $(`&lt;div id=&quot;html_5099955878f542cfa86b456d434807f7&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Woodbine-Lumsden&lt;/div&gt;`)[0];
            popup_14dfd630aa74a958bbf3359ac1b8b2d3.setContent(html_5099955878f542cfa86b456d434807f7);


        marker_2bdd7d8426d8b782d2ffdd4d60d9548d.bindPopup(popup_14dfd630aa74a958bbf3359ac1b8b2d3)
        ;




            var marker_14e9395014aac2c7ee04e54d90dbfa0d = L.marker(
                [43.59415756, -79.52254725],
                {}
            ).addTo(marker_cluster_bee2ede4db751c0f106987df10836fd4);


        var popup_cc3b2598338640a2d6de7849e4beb5fb = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_e2c3d9a2953f16ffd8dd788e821dae0a = $(`&lt;div id=&quot;html_e2c3d9a2953f16ffd8dd788e821dae0a&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Long Branch&lt;/div&gt;`)[0];
            popup_cc3b2598338640a2d6de7849e4beb5fb.setContent(html_e2c3d9a2953f16ffd8dd788e821dae0a);


        marker_14e9395014aac2c7ee04e54d90dbfa0d.bindPopup(popup_cc3b2598338640a2d6de7849e4beb5fb)
        ;




            var heat_map_abafd49bbca6969f79ba34dcd42cde87 = L.heatLayer(
                [[43.66672554, -79.44642226, 13.0], [43.63294904, -79.43438482, 14.0], [43.65227394, -79.40110737, 12.0], [43.74848196, -79.55006743, 4.0], [43.65571598, -79.38372586, 23.0], [43.70321193, -79.34658826, 5.0], [43.7870825, -79.32992957, 1.0], [43.72091645, -79.50859475, 19.0], [43.69425151, -79.55861018, 7.0], [43.72577689, -79.27383346, 5.0], [43.70917038, -79.40102123, 4.0], [43.69625936, -79.44764573, 5.0], [43.77099307, -79.41327513, 22.0], [43.8225461, -79.27141938, 8.0], [43.68475127, -79.31005511, 7.0], [43.67363686, -79.42340096, 7.0], [43.64926232, -79.37410556, 45.0], [43.64509634, -79.57350939, 1.0], [43.75937098, -79.33874208, 5.0], [43.68889241, -79.5039677, 3.0], [43.66874022, -79.45797855, 12.0], [43.64881159, -79.38888568, 36.0], [43.66716143, -79.40149998, 11.0], [43.67967885, -79.34511536, 10.0], [43.71204501, -79.28096318, 11.0], [43.66228154, -79.34055684, 11.0], [43.64944981, -79.37142509, 24.0], [43.64204126, -79.41193075, 12.0], [43.76842365, -79.26876189, 6.0], [43.81421617, -79.23709431, 7.0], [43.64220797, -79.42860473, 9.0], [43.67007127, -79.29978601, 10.0], [43.7319067, -79.59600355, 25.0], [43.64788722, -79.52685653, 14.0], [43.76525072, -79.50372563, 12.0], [43.76834039, -79.37043936, 5.0], [43.74873834, -79.23556927, 11.0], [43.83402039, -79.22699861, 13.0], [43.69702545, -79.49503182, 7.0], [43.66094505, -79.43038141, 1.0], [43.69437813, -79.30056835, 4.0], [43.66399224, -79.36926698, 11.0], [43.64938527, -79.42274326, 6.0], [43.78420347, -79.39961562, 5.0], [43.68712374, -79.36076592, 4.0], [43.70321772, -79.27947672, 9.0], [43.67201015, -79.44557624, 3.0], [43.61649591, -79.5210248, 13.0], [43.77214083, -79.25145731, 23.0], [43.72351294, -79.45978516, 8.0], [43.78469811, -79.17484165, 2.0], [0.0, 0.0, 9.0], [43.76758275, -79.18323393, 15.0], [43.65680676, -79.36252926, 10.0], [43.74375996, -79.30216238, 10.0], [43.67866925, -79.346226, 5.0], [43.6728738, -79.38782632, 19.0], [43.7694265, -79.34434334, 7.0], [43.69676539, -79.44527396, 9.0], [43.79206024, -79.25977154, 13.0], [43.64912973, -79.43790302, 8.0], [43.69144722, -79.32062053, 4.0], [43.71492666, -79.33414521, 4.0], [43.74248611, -79.22206817, 4.0], [43.77888161, -79.41953867, 13.0], [43.71107784, -79.39927621, 11.0], [43.67780884, -79.47860613, 7.0], [43.63933996, -79.45127101, 9.0], [43.67051816, -79.31158524, 6.0], [43.70060252, -79.51775154, 8.0], [43.76882728, -79.52036423, 12.0], [43.72998475, -79.26699358, 6.0], [43.67862763, -79.32787432, 5.0], [0.0, 0.0, 12.0], [43.78959109, -79.44983192, 2.0], [43.6880498, -79.47154503, 5.0], [43.75001169, -79.45390923, 9.0], [43.63920551, -79.58433063, 2.0], [43.75258277, -79.28319326, 7.0], [43.71427823, -79.3059261, 9.0], [43.71178861, -79.37853604, 5.0], [43.66428681, -79.50215597, 5.0], [43.73640808, -79.3818677, 9.0], [43.60750763, -79.52985168, 4.0], [43.60326759, -79.50627079, 4.0], [43.69432519, -79.41498645, 4.0], [43.72935527, -79.32835907, 2.0], [43.7441499, -79.40668473, 2.0], [43.65633298, -79.46818422, 4.0], [43.67235839, -79.37681431, 4.0], [43.72798391, -79.22908163, 6.0], [43.7366874, -79.5088181, 5.0], [43.76262335, -79.56438518, 8.0], [43.71545763, -79.50718536, 4.0], [43.62229718, -79.50590083, 12.0], [43.70151038, -79.25289415, 9.0], [43.75545869, -79.43844041, 2.0], [43.71780474, -79.40349687, 3.0], [43.66542584, -79.46585038, 4.0], [43.71510482, -79.55507738, 3.0], [43.77908536, -79.34869595, 7.0], [43.72003382, -79.42993872, 8.0], [43.7727692, -79.44063916, 5.0], [43.79031287, -79.19793737, 1.0], [43.8164915, -79.33141941, 7.0], [43.78714471, -79.15225673, 4.0], [43.6897005, -79.39744799, 6.0], [43.6799437, -79.40611935, 2.0], [43.80263794, -79.35242116, 2.0], [43.66465652, -79.40270156, 5.0], [43.73114796, -79.40750317, 5.0], [43.76053065, -79.4231866, 6.0], [43.74326507, -79.58207638, 10.0], [43.77797984, -79.31116492, 11.0], [43.71806233, -79.55384096, 5.0], [43.70628591, -79.37403755, 6.0], [43.79500447, -79.32961357, 2.0], [43.71574209, -79.5047176, 2.0], [43.67779387, -79.35070987, 1.0], [43.68445552, -79.42140231, 2.0], [43.74171555, -79.57377923, 3.0], [43.6761888, -79.33746603, 2.0], [43.66198485, -79.42562006, 2.0], [43.64207956, -79.58609531, 2.0], [43.73027846, -79.43819728, 3.0], [43.69876975, -79.43597803, 1.0], [43.66561293, -79.48477942, 1.0], [43.67633938, -79.57037025, 1.0], [43.808508, -79.3724657, 1.0], [43.79922772, -79.28219213, 1.0], [43.69214748, -79.30477556, 1.0], [43.59415756, -79.52254725, 1.0]],
                {&quot;blur&quot;: 20, &quot;maxZoom&quot;: 15, &quot;minOpacity&quot;: 0.2, &quot;radius&quot;: 30}
            ).addTo(map_f8e9f8c831a93fb452c7426f10c07a3b);


            var marker_d4ac917bbd5f92af2f37ca600c5a04c7 = L.marker(
                [43.7, -79.4],
                {}
            ).addTo(map_f8e9f8c831a93fb452c7426f10c07a3b);


        var popup_dbb40e448bfb1e49236564586aa73a0d = L.popup({&quot;maxWidth&quot;: &quot;100%&quot;});


            var html_9c7921fcdac850617ccbdd58b514bcaf = $(`&lt;div id=&quot;html_9c7921fcdac850617ccbdd58b514bcaf&quot; style=&quot;width: 100.0%; height: 100.0%;&quot;&gt;Central tendency based on neighbourhood: Church-Yonge Corridor&lt;/div&gt;`)[0];
            popup_dbb40e448bfb1e49236564586aa73a0d.setContent(html_9c7921fcdac850617ccbdd58b514bcaf);


        marker_d4ac917bbd5f92af2f37ca600c5a04c7.bindPopup(popup_dbb40e448bfb1e49236564586aa73a0d)
        ;



&lt;/script&gt;
&lt;/html&gt;" style="position:absolute;width:100%;height:100%;left:0;top:0;border:none !important;" allowfullscreen webkitallowfullscreen mozallowfullscreen></iframe></div></div>



> It can be seen from the map that the central tendency is on *Church-Yonge Corridor* neighbourhood which matches the density map.

#### **2. Are there spatial outliers or trends in the data you’ve selected? Discuss (include any tests run, figures, and maps generated) (200 - 400 words).**


```python
# Importing 
import regex as re
```

> To find spatial trends or outliers, I am using *premises_type* and *mci_category* from crime_data dataframe in the  first part. In second part,  I am filtering it to Assault from the *offence* against the *mci_category* column.

Part 2.1 - Pie chart visualization
>  Firstly, the count of each category of crime in the mci_category column of the crime_data dataframe using the *value_counts()* function. The keys() function is used to extract the category names from the *value_counts()* object.
>
> I have grouped the data in the crime_data dataframe by the premises_type column, summed up the number of crimes in each group using the *count()* functionand sorted the resulting series in descending order using sort_values()
>
> I also checked if any group has less than 10 crimes, and if so, renamed that group to "Other" using the *rename()* function. This is done to reduce the number of categories and make the resulting visualization more readable.
>
> The code groups the data in the *prem_counts* dataframe by the index (i.e., the premises_type column after any renaming has been done), sums the crime counts for each group using the sum() function, and sorts the resulting dataframe in descending order using sort_values().
>
> Finally, the index of the resulting dataframe is stored in the *labels_neighbourhood* variable, and the crime counts are flattened into a 1D array using the *values.flatten()* function and stored in the values_neighbourhood variable.



```python
# Values count and labels from the crime_data df
values_mci = crime_data["mci_category"].value_counts() 
labels_mci = crime_data["mci_category"].value_counts().keys()

prem_counts = crime_data.groupby('premises_type')['mci_category'].count().sort_values(ascending=False)

# Aggregrating data to reduce the number of categories which will make visualization easier
for key,value in prem_counts.iteritems():
  if value < 10:
    prem_counts = pd.DataFrame(prem_counts.rename({key: "Other"}))

# Grouping the data by the prem_counts index 
prem_counts=prem_counts.groupby(prem_counts.index).sum().sort_values("mci_category",ascending=False) #Step 4.

# Storing the index and flattening the values
labels_neighbourhood = prem_counts.index    
values_neighbourhood = prem_counts.values.flatten()
```

> Visualizing the data using pie charts for further analysis.


```python
# Set figure size and layout
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(20,10))

# Create the first pie chart and set title 
ax1.pie(values_neighbourhood, labels=labels_neighbourhood, autopct='%1.1f%%', startangle=90, counterclock=False)
ax1.set_title("Premises types distribution for crime analysis in Toronto")

# Create the second pie chart and set title
ax2.pie(values_mci, labels=labels_mci, autopct='%1.1f%%', startangle=90, counterclock=False)
ax2.set_title("Distribution of MCI Categories for crime analysis in Toronto")

# Display the pie charts
plt.show()
```


    
![png](output_27_0.png)
    


**Discussion**

> The first pie chart (on left) shows that the most common premises types for crime incidents are apartments, commercial establishments, and homes, accounting for more than 65% of the total incidents. The "Other" category, which includes less common premises types, accounts for around 7.1% of the incidents. 

> The second pie chart (right side) shows that the most common Major Crime Indicators (MCI) categories for crime incidents are Assault, Break and Enter, and Auto theft accounting for more than 90% of the total incidents. The "Other" category, which includes less common MCI categories, accounts for around 10% of the incidents.

> The trends that can be seen here is breaking and entering which correlate to Apartment and house premises. Auto theft is also common with breaking and entering a house. Assault seems to be more common in commercial places or in the public.

Part 2.2 - Histogram visualization
> The process is similar like part 2.1 with pie charts. The columns that   are chosen to visualize are mci_category and filtered Assault from 'offence' column. I have aggregrated data related to crime incidents of the "ASSAULT" category. 
>
> Firstly, the rows in the crime_data DataFrame are filtered out which contain the string "ASSAULT" in the offence column and assigns it to the crime_assault variable. *values_assault*, a new Series which counts the number of occurrences of each unique value in the offence column of the crime_assault DataFrame is created.
>
> I grouped it, if the count is less than 15 and renamed it to 'Other'. and grouped the DataFrame by the index values and the sum of the values for each group is computed using groupby() and sum() methods of pandas DataFrame.
>
> Finally, the resulting DataFrame is sorted in descending order of the "offence" column and stored the index.



```python
# Values count and labels from the crime_data df
crime_assault = crime_data[crime_data["offence"].str.contains('ASSAULT', flags=re.IGNORECASE, regex=True)] 
values_assault = crime_assault["offence"].value_counts() 

# Aggregrating data to reduce the number of categories which will make visualization easier
for key,value in values_assault.iteritems(): #Step 3.
    if value < 15:
       values_assault= pd.DataFrame(values_assault.rename({key: "Other"}))

# Grouping the data by the values_assault index 
values_assault=values_assault.groupby(values_assault.index).sum().sort_values("offence",ascending=False) 

# Storing the index
labels_assault = values_assault.index 
```

> Visualizing the data using histogram for further analysis.


```python
# Set figure size and layout
fig, axes = plt.subplots(nrows=1, ncols=2, figsize=(20,6))

# Create the first subplot, set title and axes labels
sns.barplot(x=values_mci,y=labels_mci,palette="Blues_d", ax=axes[0])
axes[0].set_title("Crime Categories")
axes[0].set_ylabel("Category")
axes[0].set_xlabel("Count")

# Create the second subplot, set title and axes labels
sns.barplot(x=values_assault['offence'], y=labels_assault, palette="Reds_d", ax=axes[1])
axes[1].set_title("Assault Offences in Toronto Crime Dataset")
axes[1].set_xlabel("Number of Offences")
axes[1].set_ylabel("Offence Type")

# Adjust spacing between subplots
fig.subplots_adjust(wspace=0.5)

plt.show()
```


    
![png](output_32_0.png)
    


**Discussion**

> In the first bar subplot (left side), it is evident that the most common category of crime is Assault which was discussed above. I used  offence column and filtered all rows with 'Assault' keyword to analyze the types.
>
> The shows the count of different types of assault offences in the dataset. The most common type of assault offence is "Assault", followed by "Assault with weapon". Assuming, 'Assault' offence is without a weapon. This means that usage of weapon is low and most of the 'assault' crimes happen without a weapon.
>
> Other 'Assault' offence types are relatively low in Toronto. 
>
> Overall, the analysis of the assault offences provides a deeper understanding of the crimes that fall under the assault category. It is essential to analyze the specific types of crimes within a category to understand the severity and frequency of the different types of crimes. The bar charts help to visually represent the count of each crime category, which can aid in identifying patterns and trends in the data.

## Part B

#### **3. What is the probability that this spatial pattern could have arisen by chance (Moran’s I)? (Include graphs and or text to support your answer.)**


```python
# Importing required packages
from libpysal.weights import DistanceBand
from esda.moran import Moran, Moran_Local
from sklearn.preprocessing import StandardScaler
from splot.esda import moran_scatterplot, plot_moran, plot_moran_simulation
```

> To calculate Moran's I on spatial data, it is recommended to use a GeoPandas dataframe, as it includes spatial data and specific functionalities for spatial analysis. 
>
> I have converted the crime_data pandas dataframe to a geopandas dataframe *'gdf'*. Columns which were required are selected and put in the same *'gdf'* variable.
>
> It then removes any duplicate neighbourhoods based on "Neighbourhood" column and sets the index to "Neighbourhood" and performs an inner join with the "top" dataframe which consists of top n neighbourhoods.


```python
# Create a new column 'geometry' to store Shapely Point objects from 'longitude' and 'latitude'
crime_data['geometry'] = crime_data.apply(lambda row: Point(row.Longitude, row.Latitude), axis=1)

# Convert DataFrame to GeoDataFrame
gdf = gpd.GeoDataFrame(crime_data, geometry='geometry', crs='epsg:4326')
```


```python
# Selecting the columns which are required and resetting index
gdf = gdf[['Neighbourhood', 'Latitude', 'Longitude','geometry']].drop_duplicates('Neighbourhood').set_index('Neighbourhood').join(top, how='inner')
gdf = gdf.reset_index()
```

> The numerical columns "Latitude", "Longitude", and "mci_category" are standarized using sklearn's StandardScaler. This step scales the data to have zero mean and unit variance.
>
> Then, a spatial weights matrix "w" is created using the "*DistanceBand.from_dataframe()*"  function from PySAL. This function calculates a spatial weights matrix based on distances between points in the dataframe, and sets a distance threshold of 1000 units.
>
> It transforms the spatial weights matrix "*w*" using the "*Rook*" criterion. The Rook criterion specifies that two neighbouring areas share a border if they share an edge or a corner.



```python
# Standardize the data using sklearn's StandardScaler
scaler = StandardScaler()
X = scaler.fit_transform(gdf[['Latitude', 'Longitude', 'mci_category']])

# Create a spatial weights matrix based on distances between points
w = DistanceBand.from_dataframe(gdf, threshold=1000, binary=False)
w.transform = 'R'
```

    /usr/local/lib/python3.9/dist-packages/scipy/sparse/_data.py:117: RuntimeWarning: divide by zero encountered in reciprocal
      return self._with_data(data ** n)


> *Moran()* calculates the global Moran's I statistic for the given attribute in X (in this case, the mci_category column after standardization), using the spatial weights matrix w. The result is stored in the mi object.
>
> *Moran_Local()* calculates the local Moran's I statistic for each feature in the mci_category column using the same spatial weights matrix w. The resulting values are stored in moran_loc_values.
> 
> *moran_scatterplot()* creates a scatterplot of the data, with the Moran's I values on the x-axis and the local Moran's I values on the y-axis. It also highlights any statistically significant spatial clusters.



```python
# Calculate Moran's I
mi = Moran(X[:,2], w)
print("Moran's I (global)",mi.I)

# Calculate local Moran's I for each feature
moran_loc = Moran_Local(gdf['mci_category'], w)

# Calculate local Moran's I for each feature
moran_loc_values = moran_loc.Is
```

    Moran's I (global) 0.08008519028581117


> The Moran Scatterplot is a diagnostic tool for examining spatial autocorrelation in a dataset. It has two axes and a dashed line:
* x-axis: The standardized values of the variable being tested for spatial autocorrelation (i.e. Z-scores of the variable).
* y-axis: The spatial lag of the variable, which is a measure of how similar the variable values are among neighboring observations.
* The plot also includes a dashed line at the global mean of the feature value, which serves as a reference point for interpreting the scatterplot. 
>
>Each point on the scatterplot represents a pair of observations, with the x-coordinate representing the value of the variable for one observation and the y-coordinate representing the average value of the variable for that observation's neighbors. 


```python
# Create a Moran Scatterplot
fig, ax = moran_scatterplot(moran_loc, p=0.05)
plt.show()
```


    
![png](output_45_0.png)
    


> Finally, p_sim is calculated as the p-value associated with the global Moran's I statistic (mi.I), indicating the level of significance of the spatial autocorrelation in the data. 
>
> The p-value represents the probability that the observed spatial pattern of crime could have arisen by chance. If the p-value is less than 0.05, we can reject the null hypothesis that the spatial pattern is random and conclude that there is spatial autocorrelation in the data.


```python
# Calculate p_sim
p_sim = mi.p_sim

# Print p_sim
print("p_sim = ", p_sim)
```

    p_sim =  0.001


**Discussion**
> *Moran's I:* The value of 0.08008519028581117 for Moran's I suggests that there is some positive spatial autocorrelation in the data, meaning that areas with similar values of the variable being analyzed tend to be located near each other

> *Moran Scatterplot:* In the moran scatterplot, if a point falls above this line, it indicates that the feature value for that neighborhood is higher than the global mean and the values of its neighbors. Conversely, if a point falls below the line, it indicates that the feature value for that neighborhood is lower than the global mean and the values of its neighbors.
> The different colors of the points in the plot represent the significance of the local Moran's I values, with red indicating high significance and blue indicating low significance.  
> If the observed value is higher or lower than the majority of the permuted values, it is considered significant at a given level of significance (in this case, 0.05).

> *p-value:* We can say that the spatial pattern is statistically significant and not likely to have arisen by chance alone because the p_sim attribute is less than 0.05.

#### **4. What are some other factors that might influence the location of these types of crimes? Use plots or graphs as necessary to support your response. (200 - 400 words)**


> The datasets I explored didn't have specific location coordinates for privacy reasons. I have chosen [Arrests and Strip Searches in Toronto](https://data.torontopolice.on.ca/datasets/TorontoPS::arrests-and-strip-searches-rbdc-arr-tbl-001/about)
>
> Same steps as before (refer Part A.1) performed to access the API data using requests


```python
# Set API endpoint
arrests_url = "https://services.arcgis.com/S9th0jAJ7bqgIRjw/arcgis/rest/services/RBDC_ARR_TBL_001/FeatureServer/0/query"

# Using params variable for the filtered queries
arrests_params = {
    "where": "Arrest_Year = 2021 OR Arrest_Year = 2022",
    "outFields": "*",
    "outSR" : "4326",
    "f": "json"
}

# Send GET request to API to get the response
arrests_response = requests.get(arrests_url, params=arrests_params)
```


```python
# Check if request was successful and print the data for verification
if arrests_response.status_code == 200:
    # Retrieve crime data from response
    arrests_data = arrests_response.json()
else:
    print("Error: Request failed with status code", response.status_code)
```


```python
 # Using list comprehension to filter attributes 
arrests_data = [attr['attributes'] for attr in arrests_data['features']]

# Converting the list into dataFrame
arrests_data = pd.json_normalize(arrests_data)
```


```python
arrests_data.head()
```





  <div id="df-af4767cd-2901-482e-99b1-93a71e27940b">
    <div class="colab-df-container">
      <div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Arrest_Year</th>
      <th>Arrest_Month</th>
      <th>EventID</th>
      <th>ArrestID</th>
      <th>PersonID</th>
      <th>Perceived_Race</th>
      <th>Sex</th>
      <th>Age_group__at_arrest_</th>
      <th>Youth_at_arrest__under_18_years</th>
      <th>ArrestLocDiv</th>
      <th>StripSearch</th>
      <th>Booked</th>
      <th>Occurrence_Category</th>
      <th>Actions_at_arrest___Concealed_i</th>
      <th>Actions_at_arrest___Combative__</th>
      <th>Actions_at_arrest___Resisted__d</th>
      <th>Actions_at_arrest___Mental_inst</th>
      <th>Actions_at_arrest___Assaulted_o</th>
      <th>Actions_at_arrest___Cooperative</th>
      <th>SearchReason_CauseInjury</th>
      <th>SearchReason_AssistEscape</th>
      <th>SearchReason_PossessWeapons</th>
      <th>SearchReason_PossessEvidence</th>
      <th>ItemsFound</th>
      <th>ObjectId</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2021</td>
      <td>Jan-Mar</td>
      <td>1052190</td>
      <td>6029059</td>
      <td>327535</td>
      <td>Black</td>
      <td>M</td>
      <td>Aged 25 to 34 years</td>
      <td>Not a youth</td>
      <td>XX</td>
      <td>0</td>
      <td>0</td>
      <td>Harassment/Threatening</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>4</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2021</td>
      <td>Jan-Mar</td>
      <td>1015512</td>
      <td>6040372</td>
      <td>327535</td>
      <td>South Asian</td>
      <td>M</td>
      <td>Aged 25 to 34 years</td>
      <td>Not a youth</td>
      <td>XX</td>
      <td>0</td>
      <td>1</td>
      <td>FTA/FTC/Compliance Check/Parollee</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>5</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2021</td>
      <td>Apr-June</td>
      <td>1019145</td>
      <td>6060688</td>
      <td>327535</td>
      <td>South Asian</td>
      <td>M</td>
      <td>Aged 25 to 34 years</td>
      <td>Not a youth</td>
      <td>42</td>
      <td>0</td>
      <td>1</td>
      <td>Assault</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>6</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2021</td>
      <td>Jan-Mar</td>
      <td>1035445</td>
      <td>6053833</td>
      <td>330778</td>
      <td>Black</td>
      <td>M</td>
      <td>Aged 25 to 34 years</td>
      <td>Not a youth</td>
      <td>52</td>
      <td>0</td>
      <td>1</td>
      <td>Assault</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>7</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2021</td>
      <td>Jan-Mar</td>
      <td>1050464</td>
      <td>6063477</td>
      <td>330778</td>
      <td>Black</td>
      <td>M</td>
      <td>Aged 25 to 34 years</td>
      <td>Not a youth</td>
      <td>XX</td>
      <td>0</td>
      <td>0</td>
      <td>Robbery/Theft</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>8</td>
    </tr>
  </tbody>
</table>
</div>
      <button class="colab-df-convert" onclick="convertToInteractive('df-af4767cd-2901-482e-99b1-93a71e27940b')"
              title="Convert this dataframe to an interactive table."
              style="display:none;">

  <svg xmlns="http://www.w3.org/2000/svg" height="24px"viewBox="0 0 24 24"
       width="24px">
    <path d="M0 0h24v24H0V0z" fill="none"/>
    <path d="M18.56 5.44l.94 2.06.94-2.06 2.06-.94-2.06-.94-.94-2.06-.94 2.06-2.06.94zm-11 1L8.5 8.5l.94-2.06 2.06-.94-2.06-.94L8.5 2.5l-.94 2.06-2.06.94zm10 10l.94 2.06.94-2.06 2.06-.94-2.06-.94-.94-2.06-.94 2.06-2.06.94z"/><path d="M17.41 7.96l-1.37-1.37c-.4-.4-.92-.59-1.43-.59-.52 0-1.04.2-1.43.59L10.3 9.45l-7.72 7.72c-.78.78-.78 2.05 0 2.83L4 21.41c.39.39.9.59 1.41.59.51 0 1.02-.2 1.41-.59l7.78-7.78 2.81-2.81c.8-.78.8-2.07 0-2.86zM5.41 20L4 18.59l7.72-7.72 1.47 1.35L5.41 20z"/>
  </svg>
      </button>

  <style>
    .colab-df-container {
      display:flex;
      flex-wrap:wrap;
      gap: 12px;
    }

    .colab-df-convert {
      background-color: #E8F0FE;
      border: none;
      border-radius: 50%;
      cursor: pointer;
      display: none;
      fill: #1967D2;
      height: 32px;
      padding: 0 0 0 0;
      width: 32px;
    }

    .colab-df-convert:hover {
      background-color: #E2EBFA;
      box-shadow: 0px 1px 2px rgba(60, 64, 67, 0.3), 0px 1px 3px 1px rgba(60, 64, 67, 0.15);
      fill: #174EA6;
    }

    [theme=dark] .colab-df-convert {
      background-color: #3B4455;
      fill: #D2E3FC;
    }

    [theme=dark] .colab-df-convert:hover {
      background-color: #434B5C;
      box-shadow: 0px 1px 3px 1px rgba(0, 0, 0, 0.15);
      filter: drop-shadow(0px 1px 2px rgba(0, 0, 0, 0.3));
      fill: #FFFFFF;
    }
  </style>

      <script>
        const buttonEl =
          document.querySelector('#df-af4767cd-2901-482e-99b1-93a71e27940b button.colab-df-convert');
        buttonEl.style.display =
          google.colab.kernel.accessAllowed ? 'block' : 'none';

        async function convertToInteractive(key) {
          const element = document.querySelector('#df-af4767cd-2901-482e-99b1-93a71e27940b');
          const dataTable =
            await google.colab.kernel.invokeFunction('convertToInteractive',
                                                     [key], {});
          if (!dataTable) return;

          const docLinkHtml = 'Like what you see? Visit the ' +
            '<a target="_blank" href=https://colab.research.google.com/notebooks/data_table.ipynb>data table notebook</a>'
            + ' to learn more about interactive tables.';
          element.innerHTML = '';
          dataTable['output_type'] = 'display_data';
          await google.colab.output.renderOutput(dataTable, element);
          const docLink = document.createElement('div');
          docLink.innerHTML = docLinkHtml;
          element.appendChild(docLink);
        }
      </script>
    </div>
  </div>




#### Pre-processing the data:
> I selected only the required columns for this analysis to reduce the computing power.
>
> To increase the readability and convenience, I have renamed some columns which had long names. I have used non-spatial information like age group, sex, etc. to do the analysis.
>
> Any rows from the arrests_data dataframe that contain missing values are removed using the *dropna()* method. The remaining data is then checked for missing values again using the *isnull()* method, which returns a boolean dataframe where *True* indicates that a value is missing and *False* indicates that a value is present. 
>
> The *sum()* method is then called on this boolean dataframe to count the number of missing values in each column. Since the first line removed all rows with missing values, the output of this code should show zeros for all columns, indicating that there are no missing values remaining in the dataset.


```python
# Selecting the required columns and renaming the columns with long names
arrests_data = arrests_data[['Arrest_Year','Arrest_Month','Perceived_Race','Sex','Age_group__at_arrest_','Occurrence_Category','Youth_at_arrest__under_18_years']]
arrests_data = arrests_data.rename(columns={'Age_group__at_arrest_': 'Age_group', 'Youth_at_arrest__under_18_years':'Youth'})
```


```python
# Drop rows null values and print to cross check if there are any null values
arrests_data = arrests_data.dropna()
print(arrests_data.isnull().sum())
```

    Arrest_Year            0
    Arrest_Month           0
    Perceived_Race         0
    Sex                    0
    Age_group              0
    Occurrence_Category    0
    Youth                  0
    dtype: int64



```python
# Group the data by occurrence hour and MCI, and count the number of occurrences
hour_crime_group = crime_data.groupby(['occurrencehour', 'mci_category']).size().reset_index(name='n')

# Plot a line graph to show the number of occurrences by crime type and hour of occurrence
fig, ax = plt.subplots(figsize=(10, 6))
for crime_type, group in hour_crime_group.groupby('mci_category'):
    ax.plot(group['occurrencehour'], group['n'], label=crime_type, linewidth=2)

# Set a legend with desired location and set title, x and y axes labels
ax.legend(title='Crime Categories', loc='upper left')
ax.set_title('Crime Types by Hour of Day in Toronto 2021 - 2022')
ax.set_xlabel('Hour (24-hour clock)')
ax.set_ylabel('Number of Occurrences')

# Plot the graph
plt.show()
```


    
![png](output_58_0.png)
    


#### **Discussion**
> The plot shows trend of different types of crimes across the day, and helps to identify peak hours when certain crimes are more likely to occur. 
>
> This data is valid for year 2021 till 2022.
> It's evident from the graph that most of the offences are more likely to occur during the night and early morning hours i.e. from 15:00 to 4:00.
> 
> Though, Assault and Auto Theft crimes are more common at evening which is the peak time for people going home. People using public transit, sidewalks, pedways etc. at these hours are more susceptible to Assault or theft.

> Creating two count plots using the *subplots()* function from matplotlib.  It shows the distribution of *Age_group* across different Sex categories in *arrests_data*.  The second subplot shows the distribution of *Age_group* across different *Arrest_Month* categories in *arrests_data*. The x-axis represents the *Arrest_Month* categories, and the bars are grouped by the *Age_group*.


```python
# Create a figure with two subplots
fig, axes = plt.subplots(1, 2, figsize=(18, 6))

# Plot the first countplot in the first subplot
sns.countplot(x='Sex', hue='Age_group', data=arrests_data, ax=axes[0])
axes[0].set_title('Distribution of Perceived Race by Sex in Toronto')

# Plot the second countplot in the second subplot
sns.countplot(x='Arrest_Month', hue='Age_group', data=arrests_data, ax=axes[1])#, legend=False)
axes[1].set_title('Distribution of Occurrence Category by Age Group in Toronto')

# Remove the legend from the second subplot
axes[1].legend([], [], frameon=False)

# Show the figure
plt.show()
```


    
![png](output_61_0.png)
    


**Discussion**
> The sex considered is biological gender. The dataset might vary if LGBTQ+ is considered.
>
> In the first subplot, it can be observed that the majority of arrests in the dataset are males aged 25-34.
>
> The second subplot shows that the number of arrests is relatively consistent across months, with a slight increase during the summer and fall months. 
>
> The count of arrests is highest for the 25-34 age group followed by the 35-44 age group in both the subplots. Overall, the plots give an idea of the distribution of arrests across age, sex and month categories in the dataset.

## References




* [Exploratory Data Analysis (EDA)](https://medium.com/analytics-vidhya/descriptive-predictive-and-feature-selection-on-time-series-data-813a202312b1)

* [Exploratory Analysis of Vancouver Crime Data](https://www.kaggle.com/code/agilesifaka/exploratory-analysis-of-vancouver-crime-data/notebook) 

* [Exploring, Clustering and Mapping Toronto’s Crimes](https://towardsdatascience.com/exploring-clustering-and-mapping-torontos-crimes-96336efe490f)

* [Toronto Crime and Folium](https://www.jiristodulka.com/post/toronto-crime/)

* [Exploratory Data Analysis (EDA), Feature Selection, and machine learning prediction on time series data]( https://medium.com/analytics-vidhya/descriptive-predictive-and-feature-selection-on-time-series-data-813a202312b1)

### Data

 * [Major Crime Indicators (MCI)](https://data.torontopolice.on.ca/datasets/TorontoPS::major-crime-indicators-1/about)

 * [Arrests and Strip Searches (RBDC-ARR-TBL-001](https://data.torontopolice.on.ca/datasets/TorontoPS::arrests-and-strip-searches-rbdc-arr-tbl-001/about)
